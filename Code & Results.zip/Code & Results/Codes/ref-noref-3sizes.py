import os
import cv2
import numpy as np
from skimage.metrics import peak_signal_noise_ratio as psnr, structural_similarity as ssim
from skimage import exposure
import matplotlib.pyplot as plt
from tqdm import tqdm
import pandas as pd
import seaborn as sns
from matplotlib.ticker import PercentFormatter
from sklearn.preprocessing import MinMaxScaler
from math import pi

# =============================================
# CONFIGURATION
# =============================================
INPUT_DIR = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET\eval15\low'
GT_DIR = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET\eval15\high'
OUTPUT_DIR = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET\resize_impact_results'
RESIZE_FACTORS = [1.0, 0.75, 0.50, 0.25]  # Original + 3 sizes
os.makedirs(OUTPUT_DIR, exist_ok=True)


# =============================================
# ENHANCEMENT TECHNIQUES
# =============================================
def histogram_equalization(img):
    if len(img.shape) == 2:
        return cv2.equalizeHist(img)
    else:
        img_yuv = cv2.cvtColor(img, cv2.COLOR_BGR2YUV)
        img_yuv[:, :, 0] = cv2.equalizeHist(img_yuv[:, :, 0])
        return cv2.cvtColor(img_yuv, cv2.COLOR_YUV2BGR)


def clahe_enhancement(img, clip_limit=2.0, grid_size=(8, 8)):
    if len(img.shape) == 2:
        clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=grid_size)
        return clahe.apply(img)
    else:
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=grid_size)
        l = clahe.apply(l)
        lab = cv2.merge((l, a, b))
        return cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)


def gamma_correction(img, gamma=1.0):
    inv_gamma = 1.0 / gamma
    table = np.array([((i / 255.0) ** inv_gamma) * 255 for i in np.arange(0, 256)]).astype("uint8")
    return cv2.LUT(img, table)


def contrast_stretching(img):
    if len(img.shape) == 2:
        min_val = np.min(img)
        max_val = np.max(img)
        stretched = (img - min_val) * (255.0 / (max_val - min_val))
        return stretched.astype(np.uint8)
    else:
        stretched = np.zeros_like(img)
        for i in range(3):
            min_val = np.min(img[:, :, i])
            max_val = np.max(img[:, :, i])
            stretched[:, :, i] = (img[:, :, i] - min_val) * (255.0 / (max_val - min_val))
        return stretched.astype(np.uint8)


def unsharp_mask(img, kernel_size=(5, 5), sigma=1.0, amount=1.0, threshold=0):
    blurred = cv2.GaussianBlur(img, kernel_size, sigma)
    sharpened = cv2.addWeighted(img, 1.0 + amount, blurred, -amount, 0)
    return sharpened


def bilateral_filtering(img, d=9, sigma_color=75, sigma_space=75):
    return cv2.bilateralFilter(img, d, sigma_color, sigma_space)


def edge_enhancement(img):
    kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
    return cv2.filter2D(img, -1, kernel)


def logarithmic_transformation(img, c=1.0):
    img_float = img.astype(np.float32) / 255.0
    log_transformed = c * np.log(1 + img_float) * 255.0
    return np.clip(log_transformed, 0, 255).astype(np.uint8)


def box_filtering(img, kernel_size=(3, 3)):
    return cv2.blur(img, kernel_size)


def denoise_image(img, h=10, template_window_size=7, search_window_size=21):
    return cv2.fastNlMeansDenoisingColored(img, None, h, h, template_window_size, search_window_size)


def hls_enhancement(img):
    hls = cv2.cvtColor(img, cv2.COLOR_BGR2HLS)
    hls[:, :, 1] = cv2.equalizeHist(hls[:, :, 1])
    return cv2.cvtColor(hls, cv2.COLOR_HLS2BGR)


ENHANCEMENTS = {
    'hist_eq': histogram_equalization,
    'clahe': clahe_enhancement,
    'gamma': gamma_correction,
    'contrast_stretch': contrast_stretching,
    'unsharp': unsharp_mask,
    'bilateral': bilateral_filtering,
    'edge_enhance': edge_enhancement,
    'log_trans': logarithmic_transformation,
    'box_filter': box_filtering,
    'denoise': denoise_image,
    'hls': hls_enhancement
}


# =============================================
# METRIC CALCULATION
# =============================================
def calculate_metrics(enhanced, gt):
    metrics = {}
    try:
        metrics['PSNR'] = np.clip(psnr(gt, enhanced, data_range=255), 0, 100)
        metrics['SSIM'] = np.clip(ssim(gt, enhanced, channel_axis=2, data_range=255), 0, 1)
        metrics['MSE'] = max(0, np.mean((gt - enhanced) ** 2))

        gray = cv2.cvtColor(enhanced, cv2.COLOR_BGR2GRAY)
        metrics['Sharpness'] = max(0, cv2.Laplacian(gray, cv2.CV_64F).var())

        hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
        hist = hist / (hist.sum() + 1e-7)
        metrics['Entropy'] = np.clip(-np.sum(hist * np.log2(hist + 1e-7)), 0, 8)
        metrics['Contrast'] = max(0, np.std(gray))
    except Exception as e:
        print(f"Metric calculation error: {str(e)}")
        return None
    return metrics


# =============================================
# VISUALIZATION SETTINGS
# =============================================
def set_plot_style():
    plt.style.use('seaborn-v0_8-whitegrid')
    sns.set_theme(context='paper', style='whitegrid', palette='husl', font_scale=0.9)
    plt.rcParams.update({
        'figure.dpi': 600,
        'font.family': 'sans-serif',
        'font.sans-serif': ['Arial', 'DejaVu Sans'],
        'axes.titlesize': 10,
        'axes.labelsize': 9,
        'xtick.labelsize': 8,
        'ytick.labelsize': 8,
        'legend.fontsize': 8,
        'legend.title_fontsize': 9,
        'figure.titlesize': 12,
        'figure.autolayout': True,
        'axes.grid': True,
        'grid.alpha': 0.3
    })


# =============================================
# VISUALIZATION FUNCTIONS
# =============================================
def plot_metric_trends(results_df, report_dir):
    set_plot_style()
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))

    # PSNR Plot
    sns.lineplot(
        data=results_df, x='Size', y='PSNR', hue='Method',
        style='Method', markers=True, dashes=False, ax=axes[0, 0],
        linewidth=1.5, markersize=6, err_style='band', errorbar='sd'
    )
    axes[0, 0].set_title('A) PSNR Trends', loc='left', weight='bold')
    axes[0, 0].set_ylabel('PSNR (dB)')
    axes[0, 0].set_ylim(10, 50)

    # SSIM Plot
    sns.lineplot(
        data=results_df, x='Size', y='SSIM', hue='Method',
        style='Method', markers=True, dashes=False, ax=axes[0, 1],
        linewidth=1.5, markersize=6, err_style='band', errorbar='sd'
    )
    axes[0, 1].set_title('B) SSIM Trends', loc='left', weight='bold')
    axes[0, 1].set_ylabel('SSIM')
    axes[0, 1].set_ylim(0, 1.05)

    # Sharpness Plot
    sns.lineplot(
        data=results_df, x='Size', y='Sharpness', hue='Method',
        style='Method', markers=True, dashes=False, ax=axes[1, 0],
        linewidth=1.5, markersize=6, err_style='band', errorbar='sd'
    )
    axes[1, 0].set_title('C) Sharpness Trends', loc='left', weight='bold')
    axes[1, 0].set_ylabel('Laplacian Variance')

    # MSE Plot
    sns.lineplot(
        data=results_df, x='Size', y='MSE', hue='Method',
        style='Method', markers=True, dashes=False, ax=axes[1, 1],
        linewidth=1.5, markersize=6, err_style='band', errorbar='sd'
    )
    axes[1, 1].set_title('D) MSE Trends', loc='left', weight='bold')
    axes[1, 1].set_ylabel('MSE')

    for ax in axes.flat:
        ax.set_xlabel('Resizing Factor')
        ax.legend(bbox_to_anchor=(1.05, 1), frameon=True)

    plt.savefig(os.path.join(report_dir, 'metric_trends.png'), bbox_inches='tight', dpi=600)
    plt.close()


def plot_performance_changes(change_df, report_dir):
    set_plot_style()
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8))

    # Absolute Changes
    sns.barplot(
        data=change_df, x='Size', y='PSNR_Change', hue='Method',
        ax=ax1, saturation=0.85, err_kws={'color': '.2', 'linewidth': 1.5},
        capsize=0.05, edgecolor='.2', linewidth=0.5
    )
    ax1.set_title('A) Absolute PSNR Change (ΔdB)', loc='left', weight='bold')
    ax1.set_ylabel('ΔPSNR (dB)')
    ax1.axhline(0, color='black', linewidth=0.8, linestyle='--')

    # Percentage Changes
    sns.barplot(
        data=change_df, x='Size', y='SSIM_PctChange', hue='Method',
        ax=ax2, saturation=0.85, err_kws={'color': '.2', 'linewidth': 1.5},
        capsize=0.05, edgecolor='.2', linewidth=0.5
    )
    ax2.set_title('B) Relative SSIM Change (%)', loc='left', weight='bold')
    ax2.set_ylabel('ΔSSIM (%)')
    ax2.yaxis.set_major_formatter(PercentFormatter(decimals=0))
    ax2.axhline(0, color='black', linewidth=0.8, linestyle='--')

    for ax in [ax1, ax2]:
        ax.set_xlabel('Resizing Factor')
        ax.legend(bbox_to_anchor=(1.05, 1), frameon=True)

    plt.savefig(os.path.join(report_dir, 'performance_changes.png'), bbox_inches='tight', dpi=600)
    plt.close()


def plot_metric_distribution(results_df, report_dir):
    set_plot_style()
    metrics = ['PSNR', 'SSIM', 'Sharpness', 'MSE']

    for metric in metrics:
        plt.figure(figsize=(10, 6))
        if metric == 'SSIM':
            y_range = (0, 1.05)
        elif metric == 'PSNR':
            y_range = (10, 50)
        else:
            y_range = (0, results_df[metric].max() * 1.1)

        sns.boxplot(data=results_df, x='Size', y=metric, hue='Method',
                    whis=[5, 95], showfliers=False)
        plt.title(f'{metric} Distribution Across Methods and Sizes', weight='bold')
        plt.ylim(y_range)
        plt.legend(bbox_to_anchor=(1.05, 1), title='Method')
        plt.savefig(os.path.join(report_dir, f'{metric}_distribution.png'),
                    bbox_inches='tight', dpi=600)
        plt.close()


def plot_radar_chart(results_df, report_dir):
    set_plot_style()
    metrics = ['PSNR', 'SSIM', 'Sharpness']
    methods = results_df['Method'].unique()
    sizes = results_df['Size'].unique()

    for size in sizes:
        plt.figure(figsize=(10, 10))
        df_size = results_df[results_df['Size'] == size]
        stats = df_size.groupby('Method')[metrics].mean()

        scaler = MinMaxScaler()
        stats_normalized = pd.DataFrame(scaler.fit_transform(stats),
                                        columns=stats.columns,
                                        index=stats.index)

        categories = list(stats_normalized.columns)
        N = len(categories)
        angles = [n / float(N) * 2 * pi for n in range(N)]
        angles += angles[:1]

        ax = plt.subplot(111, polar=True)
        ax.set_theta_offset(pi / 2)
        ax.set_theta_direction(-1)
        plt.xticks(angles[:-1], categories)
        ax.set_rlabel_position(0)
        plt.yticks([0.2, 0.4, 0.6, 0.8, 1], ["20%", "40%", "60%", "80%", "100%"])
        plt.ylim(0, 1)

        for method in methods:
            values = stats_normalized.loc[method].values.flatten().tolist()
            values += values[:1]
            ax.plot(angles, values, linewidth=2, linestyle='solid',
                    label=method, marker='o')
            ax.fill(angles, values, alpha=0.1)

        plt.title(f'Method Comparison at {size} Size', y=1.1, weight='bold')
        plt.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1))
        plt.savefig(os.path.join(report_dir, f'radar_{size}.png'),
                    bbox_inches='tight', dpi=600)
        plt.close()


def plot_violin_plots(results_df, report_dir):
    set_plot_style()
    metrics = ['PSNR', 'SSIM']

    for metric in metrics:
        plt.figure(figsize=(12, 6))
        if metric == 'SSIM':
            y_range = (0, 1.05)
        else:
            y_range = (10, 50)

        sns.violinplot(data=results_df, x='Size', y=metric, hue='Method',
                       split=True, inner="quart", palette="husl")
        plt.title(f'{metric} Distribution by Method and Size', weight='bold')
        plt.ylim(y_range)
        plt.legend(bbox_to_anchor=(1.05, 1), title='Method')
        plt.savefig(os.path.join(report_dir, f'{metric}_violin.png'),
                    bbox_inches='tight', dpi=600)
        plt.close()


def plot_scatter_matrix(results_df, report_dir):
    set_plot_style()
    metrics = ['PSNR', 'SSIM', 'Sharpness', 'MSE']

    g = sns.PairGrid(results_df[metrics + ['Method']], hue='Method',
                     palette='husl', height=2)
    g.map_upper(sns.scatterplot, s=15, alpha=0.7)
    g.map_lower(sns.kdeplot, fill=True)
    g.map_diag(sns.histplot, element='step', kde=True)
    g.add_legend(title='Method')
    plt.suptitle('Metric Relationships Across Methods', y=1.02, weight='bold')
    plt.savefig(os.path.join(report_dir, 'scatter_matrix.png'),
                bbox_inches='tight', dpi=600)
    plt.close()


def plot_performance_heatmap(results_df, report_dir):
    set_plot_style()
    avg_metrics = results_df.groupby(['Method', 'Size'])[['PSNR', 'SSIM']].mean().unstack()

    plt.figure(figsize=(12, 8))
    sns.heatmap(avg_metrics, annot=True, fmt=".2f", cmap="YlGnBu",
                cbar_kws={'label': 'Metric Value'})
    plt.title('Average Metric Values by Method and Size', weight='bold')
    plt.xlabel('Metric and Size')
    plt.ylabel('Method')
    plt.savefig(os.path.join(report_dir, 'performance_heatmap.png'),
                bbox_inches='tight', dpi=600)
    plt.close()


# =============================================
# MAIN PROCESSING PIPELINE
# =============================================
def process_images():
    results = []
    image_files = [f for f in os.listdir(INPUT_DIR) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]

    for img_file in tqdm(image_files, desc="Processing Images"):
        img_path = os.path.join(INPUT_DIR, img_file)
        gt_path = os.path.join(GT_DIR, img_file)

        if not os.path.exists(gt_path):
            continue

        orig_img = cv2.imread(img_path)
        orig_gt = cv2.imread(gt_path)

        if orig_img is None or orig_gt is None:
            continue

        for factor in RESIZE_FACTORS:
            if factor == 1.0:
                img, gt = orig_img.copy(), orig_gt.copy()
                size_label = "100% (Original)"
            else:
                h, w = orig_img.shape[:2]
                img = cv2.resize(orig_img, (int(w * factor), int(h * factor)), cv2.INTER_AREA)
                gt = cv2.resize(orig_gt, (int(w * factor), int(h * factor)), cv2.INTER_AREA)
                size_label = f"{int(factor * 100)}%"

            for method, func in ENHANCEMENTS.items():
                try:
                    enhanced = func(img.copy())
                    metrics = calculate_metrics(enhanced, gt)
                    if metrics:
                        results.append({
                            'Image': img_file,
                            'Method': method,
                            'Size': size_label,
                            'Size_Factor': factor,
                            **metrics
                        })
                except Exception as e:
                    print(f"Error processing {img_file} ({method} @ {size_label}): {str(e)}")

    return pd.DataFrame(results)


def generate_report(results_df, report_dir):
    numerical_cols = ['PSNR', 'SSIM', 'MSE', 'Sharpness']
    avg_metrics = results_df.groupby(['Method', 'Size'])[numerical_cols].agg(['mean', 'std']).round(3)

    original_vals = results_df[results_df['Size_Factor'] == 1.0].groupby('Method')[numerical_cols].mean()
    resized_metrics = results_df[results_df['Size_Factor'] != 1.0].groupby(['Method', 'Size'])[numerical_cols].mean()

    changes = []
    for (method, size), metrics in resized_metrics.groupby(['Method', 'Size']):
        record = {'Method': method, 'Size': size}
        for col in numerical_cols:
            original = original_vals.loc[method, col]
            resized = metrics[col].iloc[0]
            record[f'{col}_Change'] = resized - original
            record[f'{col}_PctChange'] = ((resized - original) / original) * 100
        changes.append(record)

    change_df = pd.DataFrame(changes)

    # Generate all visualizations
    plot_metric_trends(results_df, report_dir)
    plot_performance_changes(change_df, report_dir)
    plot_metric_distribution(results_df, report_dir)
    plot_radar_chart(results_df, report_dir)
    plot_violin_plots(results_df, report_dir)
    plot_scatter_matrix(results_df, report_dir)
    plot_performance_heatmap(results_df, report_dir)

    # Save numerical results
    avg_metrics.to_csv(os.path.join(report_dir, 'average_metrics.csv'))
    change_df.to_csv(os.path.join(report_dir, 'size_impact_changes.csv'))

    # Create interpretation guide
    with open(os.path.join(report_dir, 'interpretation_guide.txt'), 'w', encoding='utf-8') as f:
        f.write("=== METRIC INTERPRETATION GUIDE ===\n\n")
        f.write("1. PSNR (Peak Signal-to-Noise Ratio):\n")
        f.write("   - Range: 0 dB (worst) to infinity dB (best)\n")
        f.write("   - Excellent: >40 dB, Good: 30-40 dB, Poor: <30 dB\n\n")
        f.write("2. SSIM (Structural Similarity):\n")
        f.write("   - Range: 0 (worst) to 1 (best)\n")
        f.write("   - Excellent: >0.95, Good: 0.9-0.95, Poor: <0.9\n\n")
        f.write("3. Key Findings:\n")
        for size in ['75%', '50%', '25%']:
            avg_psnr_change = change_df[change_df['Size'] == size]['PSNR_PctChange'].mean()
            avg_ssim_change = change_df[change_df['Size'] == size]['SSIM_PctChange'].mean()
            f.write(f"   - At {size} size: PSNR ↓{abs(avg_psnr_change):.1f}%, SSIM ↓{abs(avg_ssim_change):.1f}%\n")
        f.write("\n=== VISUALIZATION GUIDE ===\n")
        f.write("1. Metric Trends: Line plots showing metric changes with size\n")
        f.write("2. Performance Changes: Bar plots of absolute/relative changes\n")
        f.write("3. Distribution Plots: Box/violin plots of metric distributions\n")
        f.write("4. Radar Charts: Method comparison at each size (normalized)\n")
        f.write("5. Scatter Matrix: Relationships between different metrics\n")
        f.write("6. Heatmap: Overview of average metric values\n")


if __name__ == "__main__":
    report_dir = os.path.join(OUTPUT_DIR, 'professional_results')
    os.makedirs(report_dir, exist_ok=True)

    print("Starting professional analysis pipeline...")
    results_df = process_images()
    generate_report(results_df, report_dir)

    print(f"\nAnalysis complete! Results saved to:\n{report_dir}")
    print("\nOutput Files:")
    print("- metric_trends.png : Quality metric trends")
    print("- performance_changes.png : Absolute/relative changes")
    print("- *_distribution.png : Box plots of metric distributions")
    print("- radar_*.png : Radar charts for method comparison")
    print("- *_violin.png : Violin plots of distributions")
    print("- scatter_matrix.png : Relationships between metrics")
    print("- performance_heatmap.png : Heatmap of average values")
    print("- average_metrics.csv : Detailed statistics")
    print("- interpretation_guide.txt : How to read the results")