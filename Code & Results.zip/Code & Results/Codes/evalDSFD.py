import os
import cv2
import numpy as np
from retinaface import RetinaFace
import matplotlib.pyplot as plt
from sklearn.metrics import precision_score, recall_score, f1_score, average_precision_score
from collections import defaultdict

# Directories
BASE_DIR = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET'
IMAGE_DIR = os.path.join(BASE_DIR, 'DarkFace_Train_2021', 'image')
LABEL_DIR = os.path.join(BASE_DIR, 'DarkFace_Train_2021', 'label')
RESULTS_DIR = os.path.join(BASE_DIR, 'results_y5f_comparison')

# Ensure the directories exist or create them
if not os.path.exists(IMAGE_DIR):
    raise FileNotFoundError(f"Error: The image directory {IMAGE_DIR} does not exist.")
if not os.path.exists(LABEL_DIR):
    raise FileNotFoundError(f"Error: The label directory {LABEL_DIR} does not exist.")
if not os.path.exists(RESULTS_DIR):
    os.makedirs(RESULTS_DIR)

# Enhancement techniques directory
ENHANCEMENT_DIRS = {
    'hist_eq': 'histogram_equalization',
    'clahe': 'clahe_enhancement',
    'gamma': 'gamma_correction',
    'contrast_stretch': 'contrast_stretching',
    'unsharp': 'unsharp_mask',
    'bilateral': 'bilateral_filtering',
    'edge_enhance': 'edge_enhancement',
    'log_trans': 'logarithmic_transformation',
    'box_filter': 'box_filtering',
    'denoise': 'denoise_image',
    'hls': 'hls_enhancement'
}

# Create directories for each enhancement technique
for technique in ENHANCEMENT_DIRS.values():
    os.makedirs(os.path.join(RESULTS_DIR, technique, "before_enhancement"), exist_ok=True)
    os.makedirs(os.path.join(RESULTS_DIR, technique, "after_enhancement"), exist_ok=True)
    os.makedirs(os.path.join(RESULTS_DIR, technique, "enhanced_images"), exist_ok=True)

# Detector initialization
detector = RetinaFace

# Define enhancement techniques
def histogram_equalization(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return cv2.cvtColor(cv2.equalizeHist(gray), cv2.COLOR_GRAY2BGR)

def clahe_enhancement(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    return cv2.cvtColor(clahe.apply(gray), cv2.COLOR_GRAY2BGR)

def gamma_correction(img, gamma=1.2):
    invGamma = 1.0 / gamma
    table = np.array([((i / 255.0) ** invGamma) * 255 for i in range(256)]).astype("uint8")
    return cv2.LUT(img, table)

def contrast_stretching(img):
    min_val = np.min(img)
    max_val = np.max(img)
    return np.uint8(255 * (img - min_val) / (max_val - min_val))

def unsharp_mask(img, sigma=1.0, strength=1.5):
    blurred = cv2.GaussianBlur(img, (5, 5), sigma)
    return cv2.addWeighted(img, 1 + strength, blurred, -strength, 0)

def bilateral_filtering(img):
    return cv2.bilateralFilter(img, d=9, sigmaColor=75, sigmaSpace=75)

def edge_enhancement(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 100, 200)
    return cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)

def logarithmic_transformation(img):
    c = 255 / np.log(1 + np.max(img))
    log_img = c * np.log(1 + img)
    return np.uint8(log_img)

def box_filtering(img):
    return cv2.blur(img, (5, 5))

def denoise_image(img):
    return cv2.fastNlMeansDenoisingColored(img, None, 10, 10, 7, 21)

def hls_enhancement(img):
    hls_img = cv2.cvtColor(img, cv2.COLOR_BGR2HLS)
    hls_img[:, :, 1] = cv2.equalizeHist(hls_img[:, :, 1])  # Equalize L (lightness)
    return cv2.cvtColor(hls_img, cv2.COLOR_HLS2BGR)

# Define the ENHANCEMENTS dictionary that maps enhancement names to their functions
ENHANCEMENTS = {
    'hist_eq': histogram_equalization,
    'clahe': clahe_enhancement,
    'gamma': gamma_correction,
    'contrast_stretch': contrast_stretching,
    'unsharp': unsharp_mask,
    'bilateral': bilateral_filtering,
    'edge_enhance': edge_enhancement,
    'log_trans': logarithmic_transformation,
    'box_filter': box_filtering,
    'denoise': denoise_image,
    'hls': hls_enhancement
}

# Function to calculate IoU (same as before)
def calculate_iou(boxA, boxB):
    xA, yA, xB, yB = boxA[0], boxA[1], boxA[0] + boxA[2], boxA[1] + boxA[3]
    xC, yC, xD, yD = boxB[0], boxB[1], boxB[0] + boxB[2], boxB[1] + boxB[3]
    interX = max(xA, xC)
    interY = max(yA, yC)
    interWidth = max(0, min(xB, xD) - interX)
    interHeight = max(0, min(yB, yD) - interY)
    intersection = interWidth * interHeight
    union = (boxA[2] * boxA[3]) + (boxB[2] * boxB[3]) - intersection
    return intersection / union if union > 0 else 0

# Function to evaluate performance (same as before)
def evaluate_performance(predicted_faces, ground_truth_faces, iou_threshold=0.5):
    y_true = []
    y_scores = []

    for gt in ground_truth_faces:
        matched = False
        for pred in predicted_faces:
            iou = calculate_iou(gt, pred[:4])
            if iou >= iou_threshold:
                matched = True
                y_true.append(1)
                y_scores.append(pred[4])
                break
        if not matched:
            y_true.append(1)
            y_scores.append(0)

    for pred in predicted_faces:
        matched = False
        for gt in ground_truth_faces:
            if calculate_iou(gt, pred[:4]) >= iou_threshold:
                matched = True
                break
        if not matched:
            y_true.append(0)
            y_scores.append(pred[4])

    if len(y_true) == 0:
        return 0, 0, 0, 0

    preds_binary = [1 if s >= 0.5 else 0 for s in y_scores]
    precision = precision_score(y_true, preds_binary, zero_division=0)
    recall = recall_score(y_true, preds_binary, zero_division=0)
    f1 = f1_score(y_true, preds_binary, zero_division=0)
    ap = average_precision_score(y_true, y_scores)
    return precision, recall, f1, ap

# Define the detect_faces function
def detect_faces(image_path, enhance_image=False, enhancement_func=None):
    # Load the image
    img = cv2.imread(image_path)
    if img is None:
        print(f"Error: Unable to read image {image_path}")
        return None, []

    # Apply enhancement if requested
    if enhance_image and enhancement_func:
        img = enhancement_func(img)  # Apply the enhancement method chosen

    # Detect faces using RetinaFace
    faces = detector.detect_faces(img)
    detected_faces = []
    for face in faces.values():
        x, y, w, h = face['facial_area']
        confidence = face['score']
        detected_faces.append([x, y, w, h, confidence])

    return img, detected_faces  # Return both the image and detected faces

# Visualize faces function
def visualize_faces(image_path, faces, save_path=None):
    """
    Visualize detected faces by drawing rectangles around them and saving the image.
    :param image_path: Path to the input image.
    :param faces: List of faces where each face is represented as [x, y, w, h, confidence].
    :param save_path: Path to save the visualized image.
    """
    img = cv2.imread(image_path)
    if img is None:
        print(f"Error: Unable to read image {image_path}")
        return

    for (x, y, w, h, conf) in faces:
        # Draw bounding box
        cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
        # Add confidence label
        cv2.putText(img, f"{conf:.2f}", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    if save_path:
        cv2.imwrite(save_path, img)  # Save the visualized image to the specified path

# Initialize the metrics dictionary
metrics = defaultdict(lambda: {'precision': [], 'recall': [], 'f1': [], 'ap': []})

# Main evaluation loop
for image_name in os.listdir(IMAGE_DIR):
    if image_name.endswith(('.jpg', '.png')):  # Ensuring we process only PNG or JPG files
        image_path = os.path.join(IMAGE_DIR, image_name)
        label_path = os.path.join(LABEL_DIR, image_name.rsplit('.', 1)[0] + '.txt')

        ground_truth_faces = []
        if os.path.exists(label_path):
            with open(label_path, 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) >= 4:
                        x, y, w, h = map(int, parts[:4])
                        ground_truth_faces.append([x, y, w, h])

        # Apply all enhancement techniques
        for technique_name, enhancement_func in ENHANCEMENTS.items():
            # Before Enhancement (Original Image)
            img_before, pred_faces_before = detect_faces(image_path, enhance_image=False)
            if pred_faces_before:
                visualize_faces(image_path, pred_faces_before, os.path.join(RESULTS_DIR, technique_name, "before_enhancement", f"detected_before_{image_name}"))
                p, r, f1, ap = evaluate_performance(pred_faces_before, ground_truth_faces)
                metrics[technique_name]['precision'].append(p)
                metrics[technique_name]['recall'].append(r)
                metrics[technique_name]['f1'].append(f1)
                metrics[technique_name]['ap'].append(ap)

            # After Enhancement
            img_after, pred_faces_after = detect_faces(image_path, enhance_image=True, enhancement_func=enhancement_func)
            if pred_faces_after:
                visualize_faces(image_path, pred_faces_after, os.path.join(RESULTS_DIR, technique_name, "after_enhancement", f"detected_after_{image_name}"))
                p, r, f1, ap = evaluate_performance(pred_faces_after, ground_truth_faces)
                metrics[technique_name]['precision'].append(p)
                metrics[technique_name]['recall'].append(r)
                metrics[technique_name]['f1'].append(f1)
                metrics[technique_name]['ap'].append(ap)

            # Save enhanced images (use the 'img_after' object which is the enhanced image)
            enhanced_image_path = os.path.join(RESULTS_DIR, technique_name, "enhanced_images", f"enhanced_{image_name}")
            if img_after is not None:
                # Ensure the directory exists before writing
                os.makedirs(os.path.dirname(enhanced_image_path), exist_ok=True)
                cv2.imwrite(enhanced_image_path, img_after)  # Save the enhanced image directly

            # Ensure that the directory exists before writing metrics
            os.makedirs(os.path.join(RESULTS_DIR, technique_name), exist_ok=True)
            with open(os.path.join(RESULTS_DIR, technique_name, f"metrics.txt"), "w") as f:
                f.write(f"Metrics for {technique_name} Enhancement\n")
                for metric, value in metrics[technique_name].items():
                    f.write(f"{metric.capitalize()}: {np.mean(value):.3f}\n")

# Plot comparison (precision, recall, F1, mAP)
plt.figure(figsize=(12, 8))
for technique, data in metrics.items():
    plt.plot(data['precision'], label=f"{technique} - Precision")
    plt.plot(data['recall'], label=f"{technique} - Recall")
    plt.plot(data['f1'], label=f"{technique} - F1")
    plt.plot(data['ap'], label=f"{technique} - mAP")

plt.title("Performance Comparison Before and After Enhancement")
plt.xlabel("Techniques")
plt.ylabel("Scores")
plt.legend(loc="upper left")
plt.tight_layout()
plt.savefig(os.path.join(RESULTS_DIR, "evaluation_comparison.png"))
plt.show()
