import os
import shutil
import random

# Path to original ExDark dataset
ORIG_DIR = r"E:\My_Papers\ExDark\all"  # all images in class folders
DATA_DIR = r"E:\My_Papers\ExDark"      # root for train/val

VAL_PERCENT = 0.15  # 15% for validation

# Create train/val directories
TRAIN_DIR = os.path.join(DATA_DIR, "train")
VAL_DIR   = os.path.join(DATA_DIR, "val")

os.makedirs(TRAIN_DIR, exist_ok=True)
os.makedirs(VAL_DIR, exist_ok=True)

# Loop over classes
for class_name in os.listdir(ORIG_DIR):
    class_path = os.path.join(ORIG_DIR, class_name)
    if not os.path.isdir(class_path):
        continue

    # Create class folders in train/val
    train_class_dir = os.path.join(TRAIN_DIR, class_name)
    val_class_dir = os.path.join(VAL_DIR, class_name)
    os.makedirs(train_class_dir, exist_ok=True)
    os.makedirs(val_class_dir, exist_ok=True)

    # Get all images and shuffle
    images = [f for f in os.listdir(class_path) if f.lower().endswith(('.png','.jpg','.jpeg','.bmp','.tiff'))]
    random.shuffle(images)

    val_count = max(1, int(len(images) * VAL_PERCENT))  # at least 1 image
    val_images = images[:val_count]
    train_images = images[val_count:]

    # Copy images
    for img in train_images:
        shutil.copy2(os.path.join(class_path, img), os.path.join(train_class_dir, img))
    for img in val_images:
        shutil.copy2(os.path.join(class_path, img), os.path.join(val_class_dir, img))

print("Dataset split complete!")