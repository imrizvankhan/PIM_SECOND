import os
import torch
from torch import nn, optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms, models
from tqdm import tqdm

# ----------------------------
# CONFIGURATION
# ----------------------------
DATA_DIR = r"E:\My_Papers\ExDark"  # root folder
TRAIN_DIR = os.path.join(DATA_DIR, "train")
VAL_DIR   = os.path.join(DATA_DIR, "val")

BATCH_SIZE = 16
NUM_CLASSES = 12
LR = 1e-4
EPOCHS = 30

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

# ----------------------------
# DATA TRANSFORMS
# ----------------------------
train_transforms = transforms.Compose([
    transforms.Resize((224,224)),
    transforms.RandomHorizontalFlip(),
    transforms.ColorJitter(brightness=0.2, contrast=0.2),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485,0.456,0.406],
                         std=[0.229,0.224,0.225])
])

val_transforms = transforms.Compose([
    transforms.Resize((224,224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485,0.456,0.406],
                         std=[0.229,0.224,0.225])
])

# ----------------------------
# DATASET & DATALOADER
# ----------------------------
train_dataset = datasets.ImageFolder(TRAIN_DIR, transform=train_transforms)
val_dataset   = datasets.ImageFolder(VAL_DIR, transform=val_transforms)

train_loader = DataLoader(
    train_dataset,
    batch_size=BATCH_SIZE,
    shuffle=True,
    num_workers=0,      # safe for Windows
    pin_memory=True     # speeds up GPU transfer
)

val_loader = DataLoader(
    val_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=0,
    pin_memory=True
)

print(f"Train samples: {len(train_dataset)}, Val samples: {len(val_dataset)}")

# ----------------------------
# MODEL SETUP
# ----------------------------
model = models.resnet50(pretrained=True)
model.fc = nn.Linear(model.fc.in_features, NUM_CLASSES)
model = model.to(DEVICE)

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=LR)

# ----------------------------
# TRAINING & VALIDATION
# ----------------------------
best_val_acc = 0.0

for epoch in range(1, EPOCHS+1):
    # --- Training ---
    model.train()
    total_train, correct_train, train_loss = 0, 0, 0.0

    loop = tqdm(train_loader, desc=f"Epoch {epoch}/{EPOCHS} [Train]")
    for images, labels in loop:
        images, labels = images.to(DEVICE, non_blocking=True), labels.to(DEVICE, non_blocking=True)
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        train_loss += loss.item() * images.size(0)
        _, preds = torch.max(outputs, 1)
        correct_train += torch.sum(preds == labels).item()
        total_train += labels.size(0)

        loop.set_postfix(train_loss=train_loss/total_train,
                         train_acc=100*correct_train/total_train)

    # --- Validation ---
    model.eval()
    total_val, correct_val, val_loss = 0, 0, 0.0

    with torch.no_grad():
        for images, labels in val_loader:
            images, labels = images.to(DEVICE, non_blocking=True), labels.to(DEVICE, non_blocking=True)
            outputs = model(images)
            loss = criterion(outputs, labels)
            val_loss += loss.item() * images.size(0)
            _, preds = torch.max(outputs,1)
            correct_val += torch.sum(preds == labels).item()
            total_val += labels.size(0)

    val_acc = 100*correct_val/total_val
    print(f"Epoch {epoch}: Train Loss={train_loss/len(train_dataset):.4f}, "
          f"Train Acc={100*correct_train/total_train:.2f}%, "
          f"Val Loss={val_loss/len(val_dataset):.4f}, Val Acc={val_acc:.2f}%")

    # Save best model
    if val_acc > best_val_acc:
        best_val_acc = val_acc
        torch.save(model.state_dict(), "best_resnet50_exdark.pth")
        print(f"→ Saved best model with Val Acc: {val_acc:.2f}%")

print(f"Training complete. Best Validation Accuracy: {best_val_acc:.2f}%")