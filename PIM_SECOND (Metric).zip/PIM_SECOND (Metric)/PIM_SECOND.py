"""
================================================================================
PERCEPTUAL INTEGRITY METRIC (PIM) -
================================================================================
Author: Riz
Version: 1.0
Description:
    No-reference image quality metric. Evaluates exposure, contrast, detail,
    sharpness, noise, colourfulness, texture, and conditionally penalises
    underwater/haze degradations. 
    Outputs per-image scores and summary for multiple images
Usage:
    python pim_final.py "Path\to\your\data" (Provide your data_path)

    It is proposed for adaptive adjustments as per user-specific/Machine-Vision application optimization
================================================================================
"""

import cv2
import numpy as np
from pathlib import Path
import time
import warnings
from datetime import datetime
from typing import Dict, Tuple, List

warnings.filterwarnings('ignore')

# Optional imports for extended output
try:
    import matplotlib.pyplot as plt
    HAS_PLT = True
except ImportError:
    HAS_PLT = False

try:
    import pandas as pd
    HAS_PD = True
except ImportError:
    HAS_PD = False


class PerceptualIntegrityMetric:
    """Perceptual Integrity Metric (PIM) v1.2 - No reference image quality assessment."""

    def __init__(self):
        self.version = "1.2"

    # --------------------------------------------------------------------------
    # Core processing helpers
    # --------------------------------------------------------------------------
    def _extract_luminance(self, image: np.ndarray) -> np.ndarray:
        if len(image.shape) == 2:
            bgr = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        else:
            bgr = image
        lab = cv2.cvtColor(bgr, cv2.COLOR_BGR2LAB)
        return lab[:, :, 0].astype(np.float32)

    def _to_grayscale(self, image: np.ndarray) -> np.ndarray:
        if len(image.shape) == 2:
            return image.astype(np.uint8)
        return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # --------------------------------------------------------------------------
    # Environmental condition detection (used only for penalty)
    # --------------------------------------------------------------------------
    def _has_underwater_cast(self, image: np.ndarray) -> Tuple[bool, float]:
        if len(image.shape) != 3:
            return False, 0.0
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        r = np.mean(rgb[:, :, 0].astype(np.float32))
        g = np.mean(rgb[:, :, 1].astype(np.float32))
        b = np.mean(rgb[:, :, 2].astype(np.float32))
        total = r + g + b
        if total > 0:
            rn, gn, bn = r / total, g / total, b / total
        else:
            rn, gn, bn = 0.33, 0.33, 0.33
        is_uw = (bn > 0.35 and gn > 0.30 and rn < 0.30)
        severity = min(1.0, 3.0 * np.sqrt((rn - 0.33)**2 + (gn - 0.33)**2 + (bn - 0.33)**2))
        return is_uw, severity

    def _has_haze(self, image: np.ndarray) -> Tuple[bool, float]:
        gray = self._to_grayscale(image)
        lap = cv2.Laplacian(gray, cv2.CV_64F, ksize=3)
        edge_var = np.var(lap)
        norm_edge = min(1.0, edge_var / 200.0)
        kernel = np.ones((15, 15), np.uint8)
        dark = cv2.erode(gray, kernel).astype(np.float32) / 255.0
        mean_dark = np.mean(dark)
        is_haze = (mean_dark > 0.4 and norm_edge < 0.3)
        severity = np.clip((mean_dark - 0.3) * 1.5 + (0.3 - norm_edge), 0.0, 1.0)
        return is_haze, severity

    def _has_restricted_gamut(self, image: np.ndarray) -> Tuple[bool, float]:
        if len(image.shape) != 3:
            return False, 0.0
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        sat = hsv[:, :, 1].astype(np.float32) / 255.0
        mean_sat = np.mean(sat)
        std_sat = np.std(sat)
        is_restricted = (mean_sat < 0.35 and std_sat < 0.15)
        severity = np.clip((0.35 - mean_sat) * 2.0 + (0.15 - std_sat) * 2.0, 0.0, 1.0)
        return is_restricted, severity
    
    def _environmental_penalty(self, image: np.ndarray, base_score: float) -> float:
        uw, uw_sev = self._has_underwater_cast(image)
        hz, hz_sev = self._has_haze(image)
        rg, rg_sev = self._has_restricted_gamut(image)
        cnt = sum([uw, hz, rg])
        if cnt >= 2:
            severity = 0.3 * uw_sev + 0.4 * hz_sev + 0.3 * rg_sev
            if base_score > 40:
                return base_score - severity * 25.0
            else:
                return base_score - severity * 25.0 * 0.3
        return base_score
    
    # --------------------------------------------------------------------------
    # Core quality components
    # ------------------------------------------------------------------------------

    def _exposure_score(self, image: np.ndarray) -> float:
        L = self._extract_luminance(image)
        mL = np.mean(L)
        if mL <= 50:
            score = (mL / 50.0) ** 1.5 * 100.0
        else:
            score = 100.0 - ((mL - 50.0) / 50.0) ** 1.2 * 30.0
        dark_pct = np.sum(L < 20) / L.size * 100.0
        if dark_pct > 5.0:
            score -= min(20.0, (dark_pct - 5.0) * 0.6)
        p99 = np.percentile(L, 99)
        if p99 < 245 and 40 < mL < 70:
            score = min(100.0, score + 3.0)
        return np.clip(score, 0.0, 100.0)

    def _contrast_score(self, image: np.ndarray) -> float:
        gray = self._to_grayscale(image).astype(np.float32) / 255.0
        mu = np.mean(gray)
        rms = np.sqrt(np.mean((gray - mu) ** 2))
        if rms < 0.05:
            s = rms * 300.0
        elif rms < 0.12:
            s = 15.0 + (rms - 0.05) * 357.0
        elif rms < 0.20:
            s = 40.0 + (rms - 0.12) * 312.0
        elif rms < 0.30:
            s = 65.0 + (rms - 0.20) * 200.0
        else:
            s = 85.0 + min(13.0, (rms - 0.30) * 100.0)
        return np.clip(s, 0.0, 100.0)

    def _detail_score(self, image: np.ndarray) -> float:
        gray = self._to_grayscale(image)
        grads = []
        for scale in [1, 2, 4]:
            if scale > 1:
                h, w = gray.shape
                small = cv2.resize(gray, (w // scale, h // scale))
            else:
                small = gray
            sx = cv2.Sobel(small, cv2.CV_64F, 1, 0, ksize=3)
            sy = cv2.Sobel(small, cv2.CV_64F, 0, 1, ksize=3)
            grad = np.sqrt(sx**2 + sy**2)
            grads.append(np.median(grad))
        g = 0.6 * grads[0] + 0.3 * grads[1] + 0.1 * grads[2]
        if g < 2:
            s = g * 5.0
        elif g < 4:
            s = 10.0 + (g - 2) * 7.5
        elif g < 7:
            s = 25.0 + (g - 4) * 6.67
        elif g < 11:
            s = 45.0 + (g - 7) * 5.0
        else:
            s = 65.0 + min(33.0, (g - 11) * 3.33)
        return np.clip(s, 0.0, 100.0)

    def _sharpness_score(self, image: np.ndarray) -> float:
        gray = self._to_grayscale(image)
        laps = []
        for ksize in [3, 5]:
            lap = cv2.Laplacian(gray, cv2.CV_64F, ksize=ksize)
            laps.append(np.sqrt(np.var(lap)))
        l = 0.7 * laps[0] + 0.3 * laps[1]
        if l < 5:
            s = l * 2.0
        elif l < 9:
            s = 10.0 + (l - 5) * 5.0
        elif l < 14:
            s = 30.0 + (l - 9) * 5.0
        elif l < 20:
            s = 55.0 + (l - 14) * 3.33
        elif l < 28:
            s = 75.0 + (l - 20) * 1.875
        else:
            s = 90.0 + min(8.0, (l - 28) * 1.0)
        return np.clip(s, 0.0, 100.0)

    def _noise_score(self, image: np.ndarray) -> float:
        gray = self._to_grayscale(image).astype(np.float32)
        blurred = cv2.GaussianBlur(gray, (5, 5), 1.5)
        noise = np.median(np.abs(gray - blurred))
        if noise < 2:
            s = 95.0
        elif noise < 5:
            s = 95.0 - (noise - 2) * 8.0
        elif noise < 10:
            s = 71.0 - (noise - 5) * 4.0
        else:
            s = 51.0 - min(20.0, (noise - 10) * 2.0)
        return np.clip(s, 25.0, 98.0)

    def _color_score(self, image: np.ndarray) -> float:
        if len(image.shape) != 3:
            return 50.0
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB).astype(np.float32)
        R, G, B = rgb[:, :, 0], rgb[:, :, 1], rgb[:, :, 2]
        rg = np.abs(R - G)
        by = np.abs((R + G) / 2 - B)
        c = np.std(rg) + 0.3 * np.mean(rg) + np.std(by) + 0.3 * np.mean(by)
        if c < 15:
            s = 30.0 + c
        elif c < 35:
            s = 45.0 + (c - 15) * 1.25
        elif c < 55:
            s = 70.0 + (c - 35) * 0.75
        else:
            s = 85.0 + min(13.0, (c - 55) * 0.4)
        return np.clip(s, 30.0, 98.0)

    def _texture_score(self, image: np.ndarray) -> float:
        gray = self._to_grayscale(image).astype(np.float32) / 255.0
        sx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        sy = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        grad = np.sqrt(sx**2 + sy**2)
        hist, _ = np.histogram(grad, bins=32, range=(0, 0.3))
        hist = hist / (hist.sum() + 1e-6)
        entropy = -np.sum(hist * np.log2(hist + 1e-6))
        if entropy < 2.5:
            s = entropy * 8.0
        elif entropy < 4:
            s = 20.0 + (entropy - 2.5) * 16.0
        elif entropy < 5.5:
            s = 44.0 + (entropy - 4) * 13.33
        else:
            s = 64.0 + min(34.0, (entropy - 5.5) * 10.0)
        return np.clip(s, 15.0, 98.0)

    # --------------------------------------------------------------------------
    # Main compute SECOND_Feature_Set
    # --------------------------------------------------------------------------
    def compute(self, image: np.ndarray) -> Tuple[float, Dict[str, float]]:
        if image is None or image.size == 0:
            return 0.0, {'error': 'Invalid image'}

        E = self._exposure_score(image)
        C = self._contrast_score(image)
        D = self._detail_score(image)
        S = self._sharpness_score(image)
        N = self._noise_score(image)
        K = self._color_score(image)
        T = self._texture_score(image)

        L = self._extract_luminance(image)
        mL = np.mean(L)

        if mL < 40:
            w = (0.35, 0.20, 0.15, 0.10, 0.15, 0.02, 0.03)
        elif mL < 65:
            w = (0.20, 0.15, 0.20, 0.20, 0.10, 0.05, 0.10)
        else:
            w = (0.10, 0.10, 0.25, 0.30, 0.05, 0.10, 0.10)

        base = (w[0]*E + w[1]*C + w[2]*D + w[3]*S + w[4]*N + w[5]*K + w[6]*T)
        final = self._environmental_penalty(image, base)
        final = np.clip(final, 0.0, 100.0)

        if final >= 88:
            qual = "Excellent"
        elif final >= 76:
            qual = "Very Good"
        elif final >= 62:
            qual = "Good"
        elif final >= 45:
            qual = "Fair"
        elif final >= 28:
            qual = "Poor"
        else:
            qual = "Very Poor"

        details = {
            'exposure': round(E, 1),
            'contrast': round(C, 1),
            'detail': round(D, 1),
            'sharpness': round(S, 1),
            'noise_free': round(N, 1),
            'color': round(K, 1),
            'texture': round(T, 1),
            'pim_score': round(final, 1),
            'quality': qual
        }
        return final, details


# ------------------------------------------------------------------------------
# Batch processing with clean output (no synthetic tests)
# ------------------------------------------------------------------------------
def process_folder(folder_path: str, save_csv=True, save_plot=True):
    folder = Path(folder_path)
    if not folder.exists():
        print(f"Error: Folder not found: {folder_path}")
        return

    # Find images
    exts = ['*.jpg', '*.jpeg', '*.png', '*.bmp']
    images = []
    for e in exts:
        images.extend(folder.glob(e))
        images.extend(folder.glob(e.upper()))
    # deduplicate
    seen = set()
    unique = []
    for p in images:
        if p.name not in seen:
            seen.add(p.name)
            unique.append(p)
    images = unique

    if not images:
        print(f"No images found in {folder_path}")
        return

    metric = PerceptualIntegrityMetric()
    results = []

    print(f"\nProcessing {len(images)} image(s) from: {folder_path}")
    print("-" * 70)
    for idx, p in enumerate(images, 1):
        img = cv2.imread(str(p))
        if img is None:
            print(f"  [{idx:3d}/{len(images)}] SKIP: {p.name}")
            continue
        score, det = metric.compute(img)
        results.append({
            'filename': p.name,
            'score': score,
            'quality': det['quality'],
            'exposure': det['exposure'],
            'contrast': det['contrast'],
            'detail': det['detail'],
            'sharpness': det['sharpness'],
            'noise': det['noise_free'],
            'color': det['color'],
            'texture': det['texture']
        })
        if score >= 88:
            mark = "✨"
        elif score >= 76:
            mark = "⭐"
        elif score >= 62:
            mark = "☀️"
        elif score >= 45:
            mark = "🌤️"
        elif score >= 28:
            mark = "🌑"
        else:
            mark = "⚫"
        print(f"  {mark} [{idx:3d}/{len(images)}] {score:6.1f}  {det['quality']:10s}  {p.name[:50]}")

    if not results:
        return

    scores = [r['score'] for r in results]
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print(f"  Total images   : {len(results)}")
    print(f"  Mean score     : {np.mean(scores):.2f}")
    print(f"  Median score   : {np.median(scores):.2f}")
    print(f"  Std deviation  : {np.std(scores):.2f}")
    print(f"  Min / Max      : {min(scores):.2f} / {max(scores):.2f}")

    # Distribution
    dist = {
        'Excellent (88-100)': sum(1 for x in scores if x >= 88),
        'Very Good (76-87)': sum(1 for x in scores if 76 <= x < 88),
        'Good (62-75)': sum(1 for x in scores if 62 <= x < 76),
        'Fair (45-61)': sum(1 for x in scores if 45 <= x < 62),
        'Poor (28-44)': sum(1 for x in scores if 28 <= x < 45),
        'Very Poor (0-27)': sum(1 for x in scores if x < 28)
    }
    print("\n  Quality Distribution:")
    for label, cnt in dist.items():
        if cnt > 0:
            pct = cnt / len(results) * 100
            bar = "█" * int(pct / 2) + "░" * (50 - int(pct / 2))
            print(f"    {label:<18} : {cnt:3d} ({pct:5.1f}%) {bar}")

    # Top and bottom 5
    sorted_res = sorted(results, key=lambda x: x['score'], reverse=True)
    print("\n  Top 5 Highest Quality:")
    for i, r in enumerate(sorted_res[:5], 1):
        print(f"    {i}. {r['score']:6.1f} - {r['quality']:10s} - {r['filename'][:45]}")
    print("\n  Bottom 5 Lowest Quality:")
    for i, r in enumerate(sorted_res[-5:][::-1], 1):
        print(f"    {i}. {r['score']:6.1f} - {r['quality']:10s} - {r['filename'][:45]}")

    # Save CSV
    if save_csv and HAS_PD:
        df = pd.DataFrame(results)
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        csv_path = folder / f"PIM_results_{ts}.csv"
        df.to_csv(csv_path, index=False)
        print(f"\n  CSV saved: {csv_path.name}")

    # Plot histogram
    if save_plot and HAS_PLT:
        plt.figure(figsize=(10, 6))
        plt.hist(scores, bins=20, color='steelblue', edgecolor='black', alpha=0.7)
        plt.xlabel('PIM Score')
        plt.ylabel('Number of Images')
        plt.title(f'Quality Score Distribution (N={len(results)})')
        plt.axvline(np.mean(scores), color='red', linestyle='--', label=f'Mean = {np.mean(scores):.1f}')
        plt.axvline(np.median(scores), color='green', linestyle='--', label=f'Median = {np.median(scores):.1f}')
        plt.legend()
        plt.grid(True, linestyle='--', alpha=0.5)
        plot_path = folder / f"PIM_histogram_{ts}.png"
        plt.savefig(plot_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"  Histogram saved: {plot_path.name}")

    print("\n" + "=" * 70)


# ------------------------------------------------------------------------------
# Main entry point (User can change the Folder_path for own data)
# ------------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        target_folder = sys.argv[1]
    else:
        # Default folder – change to your own if needed
        target_folder = r"E:\My_Papers\data\our485\low"
        print(f"No folder argument provided. Using default: {target_folder}")

    process_folder(target_folder, save_csv=True, save_plot=True)