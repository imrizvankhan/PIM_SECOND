import os
import cv2
import numpy as np
from retinaface import RetinaFace
import matplotlib.pyplot as plt
from sklearn.metrics import precision_score, recall_score, f1_score, average_precision_score

# Directories
IMAGE_DIR = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET\DarkFace_Train_2021\image'
LABEL_DIR = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET\DarkFace_Train_2021\label'
RESULTS_DIR = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET\results_y5f_comparison'
os.makedirs(RESULTS_DIR, exist_ok=True)

detector = RetinaFace

def histogram_equalization(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return cv2.cvtColor(cv2.equalizeHist(gray), cv2.COLOR_GRAY2BGR)

def detect_faces(image_path, enhance_image=False):
    img = cv2.imread(image_path)
    if img is None:
        print(f"Error: Unable to read image {image_path}")
        return []
    if enhance_image:
        img = histogram_equalization(img)

    faces = detector.detect_faces(img)
    detected_faces = []
    for face in faces.values():
        x, y, w, h = face['facial_area']
        confidence = face['score']
        detected_faces.append([x, y, w, h, confidence])
    return detected_faces

def visualize_faces(image_path, faces, save_path=None):
    img = cv2.imread(image_path)
    if img is None:
        print(f"Error: Unable to read image {image_path}")
        return
    for (x, y, w, h, conf) in faces:
        cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(img, f"{conf:.2f}", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
    if save_path:
        cv2.imwrite(save_path, img)

def calculate_iou(boxA, boxB):
    xA, yA, xB, yB = boxA[0], boxA[1], boxA[0]+boxA[2], boxA[1]+boxA[3]
    xC, yC, xD, yD = boxB[0], boxB[1], boxB[0]+boxB[2], boxB[1]+boxB[3]
    interX = max(xA, xC)
    interY = max(yA, yC)
    interWidth = max(0, min(xB, xD) - interX)
    interHeight = max(0, min(yB, yD) - interY)
    intersection = interWidth * interHeight
    union = (boxA[2]*boxA[3]) + (boxB[2]*boxB[3]) - intersection
    return intersection / union if union > 0 else 0

def evaluate_performance(predicted_faces, ground_truth_faces, iou_threshold=0.5):
    y_true = []
    y_scores = []

    for gt in ground_truth_faces:
        matched = False
        for pred in predicted_faces:
            iou = calculate_iou(gt, pred[:4])
            if iou >= iou_threshold:
                matched = True
                y_true.append(1)
                y_scores.append(pred[4])
                break
        if not matched:
            y_true.append(1)
            y_scores.append(0)

    for pred in predicted_faces:
        matched = False
        for gt in ground_truth_faces:
            if calculate_iou(gt, pred[:4]) >= iou_threshold:
                matched = True
                break
        if not matched:
            y_true.append(0)
            y_scores.append(pred[4])

    if len(y_true) == 0:
        return 0, 0, 0, 0

    preds_binary = [1 if s >= 0.5 else 0 for s in y_scores]
    precision = precision_score(y_true, preds_binary, zero_division=0)
    recall = recall_score(y_true, preds_binary, zero_division=0)
    f1 = f1_score(y_true, preds_binary, zero_division=0)
    ap = average_precision_score(y_true, y_scores)
    return precision, recall, f1, ap

# Metric holders
metrics_before = {'precision': [], 'recall': [], 'f1': [], 'ap': []}
metrics_after = {'precision': [], 'recall': [], 'f1': [], 'ap': []}

# Main evaluation loop
for image_name in os.listdir(IMAGE_DIR):
    if image_name.endswith(('.jpg', '.png')):
        image_path = os.path.join(IMAGE_DIR, image_name)
        label_path = os.path.join(LABEL_DIR, image_name.rsplit('.', 1)[0] + '.txt')

        ground_truth_faces = []
        if os.path.exists(label_path):
            with open(label_path, 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) >= 4:
                        x, y, w, h = map(int, parts[:4])
                        ground_truth_faces.append([x, y, w, h])

        pred_faces_before = detect_faces(image_path, enhance_image=False)
        if pred_faces_before:
            visualize_faces(image_path, pred_faces_before,
                            os.path.join(RESULTS_DIR, f"detected_before_{image_name}"))
            p, r, f1, ap = evaluate_performance(pred_faces_before, ground_truth_faces)
            metrics_before['precision'].append(p)
            metrics_before['recall'].append(r)
            metrics_before['f1'].append(f1)
            metrics_before['ap'].append(ap)

        pred_faces_after = detect_faces(image_path, enhance_image=True)
        if pred_faces_after:
            visualize_faces(image_path, pred_faces_after,
                            os.path.join(RESULTS_DIR, f"detected_after_{image_name}"))
            p, r, f1, ap = evaluate_performance(pred_faces_after, ground_truth_faces)
            metrics_after['precision'].append(p)
            metrics_after['recall'].append(r)
            metrics_after['f1'].append(f1)
            metrics_after['ap'].append(ap)

# Averages
avg_metrics_before = {k: np.mean(v) for k, v in metrics_before.items()}
avg_metrics_after = {k: np.mean(v) for k, v in metrics_after.items()}

# Print results
print("\n=== Final Comparison ===")
print(f"Before Enhancement:\n Precision: {avg_metrics_before['precision']:.3f}, Recall: {avg_metrics_before['recall']:.3f}, F1: {avg_metrics_before['f1']:.3f}, mAP: {avg_metrics_before['ap']:.3f}")
print(f"After Enhancement:\n Precision: {avg_metrics_after['precision']:.3f}, Recall: {avg_metrics_after['recall']:.3f}, F1: {avg_metrics_after['f1']:.3f}, mAP: {avg_metrics_after['ap']:.3f}")

# Save results
with open(os.path.join(RESULTS_DIR, "final_metrics.txt"), "w") as f:
    f.write("=== Metrics Comparison ===\n")
    f.write(f"Before Enhancement:\n Precision: {avg_metrics_before['precision']:.3f}, Recall: {avg_metrics_before['recall']:.3f}, F1: {avg_metrics_before['f1']:.3f}, mAP: {avg_metrics_before['ap']:.3f}\n")
    f.write(f"After Enhancement:\n Precision: {avg_metrics_after['precision']:.3f}, Recall: {avg_metrics_after['recall']:.3f}, F1: {avg_metrics_after['f1']:.3f}, mAP: {avg_metrics_after['ap']:.3f}\n")

# Plotting comparison
labels = ['Precision', 'Recall', 'F1 Score', 'mAP']
before_vals = [avg_metrics_before['precision'], avg_metrics_before['recall'], avg_metrics_before['f1'], avg_metrics_before['ap']]
after_vals = [avg_metrics_after['precision'], avg_metrics_after['recall'], avg_metrics_after['f1'], avg_metrics_after['ap']]

x = np.arange(len(labels))
width = 0.35

plt.figure(figsize=(10, 6))
plt.bar(x - width/2, before_vals, width, label='Before', color='skyblue')
plt.bar(x + width/2, after_vals, width, label='After', color='salmon')
plt.ylabel('Score')
plt.title('Metric Comparison Before and After Enhancement')
plt.xticks(x, labels)
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig(os.path.join(RESULTS_DIR, "metric_comparison_bar_chart.png"))
plt.show()
