import os
import cv2
import shutil
from tqdm import tqdm
from pathlib import Path

# =============================================
# CONFIGURATION
# =============================================
INPUT_DIR = r'E:\My_Papers\data\dataset2'  # Main directory containing low and high folders
OUTPUT_DIR = r'E:\My_Papers\dataset2_resized'  # Directory for resized images

# Resize percentages (as decimals)
RESIZE_FACTORS = {
    0.75: '75_percent',
    0.50: '50_percent',
    0.25: '25_percent'
}


# Create output directory structure
def create_directory_structure():
    """Create folders for resized images"""
    folders = ['low', 'high']
    sizes = ['original', '75_percent', '50_percent', '25_percent']

    for folder in folders:
        for size in sizes:
            dir_path = os.path.join(OUTPUT_DIR, folder, size)
            os.makedirs(dir_path, exist_ok=True)
            print(f"Created directory: {dir_path}")


def resize_and_save_image(img_path, output_path, factor):
    """Resize image and save to output path"""
    try:
        # Read image
        img = cv2.imread(img_path)
        if img is None:
            print(f"Warning: Could not read {img_path}")
            return False

        # Calculate new dimensions
        h, w = img.shape[:2]
        new_w = int(w * factor)
        new_h = int(h * factor)

        # Resize image
        resized_img = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_AREA)

        # Save resized image
        cv2.imwrite(output_path, resized_img)
        return True
    except Exception as e:
        print(f"Error processing {img_path}: {str(e)}")
        return False


def copy_original_images():
    """Copy original images to original folder in output directory"""
    for folder in ['low', 'high']:
        source_dir = os.path.join(INPUT_DIR, folder)
        target_dir = os.path.join(OUTPUT_DIR, folder, 'original')

        if not os.path.exists(source_dir):
            print(f"Warning: Source directory {source_dir} does not exist!")
            continue

        # Get all image files
        image_files = [f for f in os.listdir(source_dir)
                       if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]

        print(f"\nCopying {len(image_files)} original images from {folder} folder...")

        for img_file in tqdm(image_files, desc=f"Copying {folder} originals"):
            src_path = os.path.join(source_dir, img_file)
            dst_path = os.path.join(target_dir, img_file)
            shutil.copy2(src_path, dst_path)


def process_resizing():
    """Process all images and create resized versions"""

    # Process low and high folders
    for folder in ['low', 'high']:
        source_dir = os.path.join(INPUT_DIR, folder)

        if not os.path.exists(source_dir):
            print(f"Warning: Source directory {source_dir} does not exist!")
            continue

        # Get all image files
        image_files = [f for f in os.listdir(source_dir)
                       if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]

        if len(image_files) == 0:
            print(f"No image files found in {source_dir}")
            continue

        print(f"\n{'=' * 60}")
        print(f"Processing {folder.upper()} folder")
        print(f"Found {len(image_files)} images")
        print(f"{'=' * 60}")

        # Process each resize factor
        for factor, size_name in RESIZE_FACTORS.items():
            print(f"\nResizing to {size_name} ({int(factor * 100)}% of original)...")

            # Output directory for this size
            output_dir = os.path.join(OUTPUT_DIR, folder, size_name)

            success_count = 0
            fail_count = 0

            # Process each image
            for img_file in tqdm(image_files, desc=f"Resizing to {size_name}"):
                src_path = os.path.join(source_dir, img_file)
                dst_path = os.path.join(output_dir, img_file)

                if resize_and_save_image(src_path, dst_path, factor):
                    success_count += 1
                else:
                    fail_count += 1

            print(f"✓ Resized {success_count} images to {size_name}")
            if fail_count > 0:
                print(f"✗ Failed: {fail_count} images")


def verify_results():
    """Verify that all images were processed correctly"""
    print("\n" + "=" * 60)
    print("VERIFICATION RESULTS")
    print("=" * 60)

    sizes = ['original', '75_percent', '50_percent', '25_percent']

    for folder in ['low', 'high']:
        print(f"\n{folder.upper()} folder:")
        for size in sizes:
            folder_path = os.path.join(OUTPUT_DIR, folder, size)
            if os.path.exists(folder_path):
                num_images = len([f for f in os.listdir(folder_path)
                                  if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))])
                print(f"  {size}: {num_images} images")
            else:
                print(f"  {size}: Folder not found")


def generate_summary_report():
    """Generate a summary report of the resizing operation"""
    report_path = os.path.join(OUTPUT_DIR, 'resizing_report.txt')

    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("=" * 60 + "\n")
        f.write("IMAGE RESIZING SUMMARY REPORT\n")
        f.write("=" * 60 + "\n\n")

        f.write(f"Source Directory: {INPUT_DIR}\n")
        f.write(f"Output Directory: {OUTPUT_DIR}\n\n")

        f.write("Resize Factors Applied:\n")
        f.write("  - 75% of original size\n")
        f.write("  - 50% of original size\n")
        f.write("  - 25% of original size\n\n")

        f.write("Directory Structure Created:\n")
        f.write("  ├── low/\n")
        f.write("  │   ├── original/\n")
        f.write("  │   ├── 75_percent/\n")
        f.write("  │   ├── 50_percent/\n")
        f.write("  │   └── 25_percent/\n")
        f.write("  └── high/\n")
        f.write("      ├── original/\n")
        f.write("      ├── 75_percent/\n")
        f.write("      ├── 50_percent/\n")
        f.write("      └── 25_percent/\n\n")

        # Get statistics
        for folder in ['low', 'high']:
            f.write(f"{folder.upper()} Folder Statistics:\n")
            for size in ['original', '75_percent', '50_percent', '25_percent']:
                folder_path = os.path.join(OUTPUT_DIR, folder, size)
                if os.path.exists(folder_path):
                    num_images = len([f for f in os.listdir(folder_path)
                                      if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))])
                    f.write(f"  {size}: {num_images} images\n")
            f.write("\n")

        f.write("=" * 60 + "\n")
        f.write("RESIZING COMPLETE\n")
        f.write("=" * 60 + "\n")

    print(f"\n✓ Summary report saved to: {report_path}")


def main():
    """Main function to orchestrate the resizing process"""
    print("=" * 60)
    print("IMAGE RESIZING TOOL")
    print("=" * 60)
    print(f"\nInput Directory: {INPUT_DIR}")
    print(f"Output Directory: {OUTPUT_DIR}")
    print("\nResize Factors: 75%, 50%, and 25% of original size\n")

    # Check if input directories exist
    low_dir = os.path.join(INPUT_DIR, 'low')
    high_dir = os.path.join(INPUT_DIR, 'high')

    if not os.path.exists(low_dir):
        print(f"ERROR: Low folder not found at {low_dir}")
        return

    if not os.path.exists(high_dir):
        print(f"ERROR: High folder not found at {high_dir}")
        return

    # Create output directory structure
    print("Creating directory structure...")
    create_directory_structure()

    # Copy original images
    print("\n" + "=" * 60)
    print("COPYING ORIGINAL IMAGES")
    print("=" * 60)
    copy_original_images()

    # Process resizing
    print("\n" + "=" * 60)
    print("PROCESSING RESIZED IMAGES")
    print("=" * 60)
    process_resizing()

    # Verify results
    verify_results()

    # Generate summary report
    generate_summary_report()

    print("\n" + "=" * 60)
    print("RESIZING COMPLETE!")
    print("=" * 60)
    print(f"\nAll images have been resized and saved to:")
    print(f"{OUTPUT_DIR}")
    print("\nDirectory Structure:")
    print("  ├── low/")
    print("  │   ├── original/     (original size)")
    print("  │   ├── 75_percent/   (75% of original)")
    print("  │   ├── 50_percent/   (50% of original)")
    print("  │   └── 25_percent/   (25% of original)")
    print("  └── high/")
    print("      ├── original/     (original size)")
    print("      ├── 75_percent/   (75% of original)")
    print("      ├── 50_percent/   (50% of original)")
    print("      └── 25_percent/   (25% of original)")


if __name__ == "__main__":
    main()