import os
import cv2
import numpy as np
from skimage.metrics import peak_signal_noise_ratio as psnr
from skimage.metrics import structural_similarity as ssim
import pandas as pd
from tqdm import tqdm
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')

# Try BRISQUE with multiple options
BRISQUE_AVAILABLE = False
try:
    # Try imquality first (simpler)
    from imquality import brisque

    BRISQUE_AVAILABLE = True
    print("✅ BRISQUE loaded from imquality")
except:
    try:
        # Fallback to piq
        import torch
        from PIL import Image
        import piq

        BRISQUE_AVAILABLE = True
        print("✅ BRISQUE loaded from piq")


        def brisque_score(img_path):
            img = cv2.imread(img_path)
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img_pil = Image.fromarray(img_rgb)
            img_pil = img_pil.resize((224, 224))
            img_tensor = torch.from_numpy(np.array(img_pil)).permute(2, 0, 1).float() / 255.0
            img_tensor = img_tensor.unsqueeze(0)
            with torch.no_grad():
                score = piq.brisque(img_tensor, data_range=1.0)
            return score.item()
    except:
        print("⚠️ BRISQUE not available. Install: pip install imquality")
        BRISQUE_AVAILABLE = False

# =============================================
# CONFIGURATION
# =============================================
RESULTS_DIR = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET\Transformer\Results_DUBB'
GT_DIR = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET\Transformer\GT'
OUTPUT_DIR = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET\Transformer\Analysis_Results'

os.makedirs(OUTPUT_DIR, exist_ok=True)


# =============================================
# METRIC FUNCTIONS
# =============================================
def calculate_mse(img1, img2):
    """Mean Squared Error"""
    return np.mean((img1.astype(np.float32) - img2.astype(np.float32)) ** 2)


def calculate_sharpness(img):
    """Laplacian variance for sharpness"""
    if len(img.shape) == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img
    return cv2.Laplacian(gray, cv2.CV_64F).var()


def calculate_contrast(img):
    """Standard deviation as contrast measure"""
    if len(img.shape) == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img
    return gray.std()


def calculate_entropy(img):
    """Image entropy"""
    if len(img.shape) == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img
    hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
    hist = hist.ravel() / hist.sum()
    entropy = -np.sum([p * np.log2(p) for p in hist if p > 0])
    return entropy


def calculate_brisque_score(img_path):
    """Calculate BRISQUE score (lower is better)"""
    if not BRISQUE_AVAILABLE:
        return None
    try:
        # Try using imquality
        score = brisque.score(img_path)
        return score
    except:
        try:
            # Try using custom function
            img = cv2.imread(img_path)
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img_pil = Image.fromarray(img_rgb)
            img_pil = img_pil.resize((224, 224))
            img_tensor = torch.from_numpy(np.array(img_pil)).permute(2, 0, 1).float() / 255.0
            img_tensor = img_tensor.unsqueeze(0)
            with torch.no_grad():
                score = piq.brisque(img_tensor, data_range=1.0)
            return score.item()
        except:
            return None


def calculate_all_metrics(enhanced_img, gt_img, img_path=None):
    """Calculate all quality metrics"""
    # Ensure same size
    if enhanced_img.shape != gt_img.shape:
        h, w = gt_img.shape[:2]
        enhanced_img = cv2.resize(enhanced_img, (w, h), cv2.INTER_AREA)

    metrics = {
        'PSNR': psnr(gt_img, enhanced_img, data_range=255),
        'SSIM': ssim(gt_img, enhanced_img, channel_axis=2, data_range=255),
        'MSE': calculate_mse(gt_img, enhanced_img),
        'Sharpness': calculate_sharpness(enhanced_img),
        'Contrast': calculate_contrast(enhanced_img),
        'Entropy': calculate_entropy(enhanced_img)
    }

    # Add BRISQUE if available and path provided
    if img_path and BRISQUE_AVAILABLE:
        brisque_val = calculate_brisque_score(img_path)
        if brisque_val:
            metrics['BRISQUE'] = brisque_val

    return metrics


# =============================================
# PROCESS ALL FOLDERS
# =============================================
def process_all_folders():
    """Process all method folders and calculate metrics"""
    all_results = []

    # Get all folders in Results_DUBB
    folders = [f for f in os.listdir(RESULTS_DIR)
               if os.path.isdir(os.path.join(RESULTS_DIR, f))]

    print(f"\n📁 Found {len(folders)} method folders:")
    for f in folders:
        print(f"   - {f}")

    # Get all ground truth images
    gt_files = [f for f in os.listdir(GT_DIR)
                if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]
    print(f"\n📸 Found {len(gt_files)} ground truth images\n")

    # Process each folder
    for folder_name in folders:
        folder_path = os.path.join(RESULTS_DIR, folder_name)
        image_files = [f for f in os.listdir(folder_path)
                       if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]

        print(f"🔄 Processing {folder_name}: {len(image_files)} images")

        folder_results = []
        for img_file in tqdm(image_files, desc=f"   {folder_name}"):
            img_path = os.path.join(folder_path, img_file)

            # Find matching ground truth
            gt_path = os.path.join(GT_DIR, img_file)
            if not os.path.exists(gt_path):
                # Try to find by name without extension
                base_name = os.path.splitext(img_file)[0]
                for gt_file in gt_files:
                    if base_name in gt_file:
                        gt_path = os.path.join(GT_DIR, gt_file)
                        break

            if not os.path.exists(gt_path):
                continue

            # Read images
            enhanced_img = cv2.imread(img_path)
            gt_img = cv2.imread(gt_path)

            if enhanced_img is None or gt_img is None:
                continue

            # Calculate metrics
            metrics = calculate_all_metrics(enhanced_img, gt_img, img_path)

            folder_results.append({
                'Method': folder_name,
                'Image': img_file,
                **metrics
            })

        if folder_results:
            all_results.extend(folder_results)
            print(f"   ✅ Processed {len(folder_results)} images for {folder_name}")

    return pd.DataFrame(all_results)


# =============================================
# VISUALIZATION FUNCTIONS
# =============================================
def create_comprehensive_dashboard(df_results, output_dir):
    """Create comprehensive visualization dashboard"""

    metrics = ['PSNR', 'SSIM', 'Sharpness', 'Contrast', 'Entropy']
    if 'BRISQUE' in df_results.columns:
        metrics.append('BRISQUE')

    methods = df_results['Method'].unique()

    # Create figure with subplots
    fig = plt.figure(figsize=(20, 16))

    # 1. Bar plot for all metrics (normalized)
    ax1 = plt.subplot(3, 3, 1)
    normalized_data = []
    for method in methods:
        method_data = []
        for metric in metrics:
            mean_val = df_results[df_results['Method'] == method][metric].mean()
            if metric == 'BRISQUE':
                # For BRISQUE, lower is better, so invert for visualization
                method_data.append(100 - mean_val if mean_val <= 100 else mean_val)
            else:
                # Normalize other metrics to 0-100 scale
                max_val = df_results[metric].max()
                min_val = df_results[metric].min()
                if max_val != min_val:
                    method_data.append(100 * (mean_val - min_val) / (max_val - min_val))
                else:
                    method_data.append(50)
        normalized_data.append(method_data)

    x = np.arange(len(metrics))
    width = 0.8 / len(methods)
    for i, (method, data) in enumerate(zip(methods, normalized_data)):
        offset = (i - len(methods) / 2) * width
        bars = ax1.bar(x + offset, data, width, label=method, alpha=0.7)

    ax1.set_xlabel('Metrics', fontsize=12)
    ax1.set_ylabel('Normalized Score (0-100)', fontsize=12)
    ax1.set_title('A) Normalized Performance Comparison\n(Higher = Better)', weight='bold', fontsize=14)
    ax1.set_xticks(x)
    ax1.set_xticklabels(metrics, rotation=45)
    ax1.legend(loc='upper left', bbox_to_anchor=(1, 1), fontsize=9)
    ax1.grid(True, alpha=0.3, axis='y')

    # 2. PSNR Comparison
    ax2 = plt.subplot(3, 3, 2)
    psnr_means = df_results.groupby('Method')['PSNR'].mean().sort_values(ascending=False)
    colors = plt.cm.viridis(np.linspace(0.2, 0.8, len(psnr_means)))
    bars = ax2.bar(range(len(psnr_means)), psnr_means.values, color=colors, edgecolor='black')
    ax2.set_xticks(range(len(psnr_means)))
    ax2.set_xticklabels(psnr_means.index, rotation=45, ha='right', fontsize=9)
    ax2.set_ylabel('PSNR (dB)', fontsize=12)
    ax2.set_title('B) PSNR Comparison\n(Higher Better)', weight='bold', fontsize=14)
    ax2.grid(True, alpha=0.3, axis='y')
    for bar, val in zip(bars, psnr_means.values):
        ax2.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5,
                 f'{val:.1f}', ha='center', va='bottom', fontsize=9, fontweight='bold')

    # 3. SSIM Comparison
    ax3 = plt.subplot(3, 3, 3)
    ssim_means = df_results.groupby('Method')['SSIM'].mean().sort_values(ascending=False)
    bars = ax3.bar(range(len(ssim_means)), ssim_means.values, color=colors, edgecolor='black')
    ax3.set_xticks(range(len(ssim_means)))
    ax3.set_xticklabels(ssim_means.index, rotation=45, ha='right', fontsize=9)
    ax3.set_ylabel('SSIM', fontsize=12)
    ax3.set_title('C) SSIM Comparison\n(Higher Better)', weight='bold', fontsize=14)
    ax3.grid(True, alpha=0.3, axis='y')
    ax3.set_ylim(0, 1)
    for bar, val in zip(bars, ssim_means.values):
        ax3.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                 f'{val:.3f}', ha='center', va='bottom', fontsize=9, fontweight='bold')

    # 4. BRISQUE Comparison (if available)
    ax4 = plt.subplot(3, 3, 4)
    if 'BRISQUE' in df_results.columns:
        brisque_means = df_results.groupby('Method')['BRISQUE'].mean().sort_values()
        bars = ax4.bar(range(len(brisque_means)), brisque_means.values, color=colors, edgecolor='black')
        ax4.set_xticks(range(len(brisque_means)))
        ax4.set_xticklabels(brisque_means.index, rotation=45, ha='right', fontsize=9)
        ax4.set_ylabel('BRISQUE (lower better)', fontsize=12)
        ax4.set_title('D) BRISQUE Comparison\n(Lower Better)', weight='bold', fontsize=14)
        ax4.grid(True, alpha=0.3, axis='y')
        ax4.axhline(y=30, color='g', linestyle='--', alpha=0.5, linewidth=2, label='Good')
        ax4.axhline(y=50, color='orange', linestyle='--', alpha=0.5, linewidth=2, label='Poor')
        ax4.legend(fontsize=9)
        for bar, val in zip(bars, brisque_means.values):
            ax4.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1,
                     f'{val:.1f}', ha='center', va='bottom', fontsize=9, fontweight='bold')
    else:
        ax4.text(0.5, 0.5, 'BRISQUE Not Available', ha='center', va='center', fontsize=14)
        ax4.set_title('D) BRISQUE Not Available', weight='bold', fontsize=14)

    # 5. Sharpness Comparison
    ax5 = plt.subplot(3, 3, 5)
    sharpness_means = df_results.groupby('Method')['Sharpness'].mean().sort_values(ascending=False)
    bars = ax5.bar(range(len(sharpness_means)), sharpness_means.values, color=colors, edgecolor='black')
    ax5.set_xticks(range(len(sharpness_means)))
    ax5.set_xticklabels(sharpness_means.index, rotation=45, ha='right', fontsize=9)
    ax5.set_ylabel('Sharpness (Variance)', fontsize=12)
    ax5.set_title('E) Sharpness Comparison\n(Higher Better)', weight='bold', fontsize=14)
    ax5.grid(True, alpha=0.3, axis='y')

    # 6. PSNR Distribution
    ax6 = plt.subplot(3, 3, 6)
    data = [df_results[df_results['Method'] == m]['PSNR'].values for m in methods[:8]]
    bp = ax6.boxplot(data, labels=methods[:8], patch_artist=True, showmeans=True)
    for patch in bp['boxes']:
        patch.set_facecolor('lightblue')
        patch.set_alpha(0.7)
    ax6.set_title('F) PSNR Distribution by Method', weight='bold', fontsize=14)
    ax6.set_ylabel('PSNR (dB)', fontsize=12)
    ax6.tick_params(axis='x', rotation=45, labelsize=8)
    ax6.grid(True, alpha=0.3, axis='y')

    # 7. SSIM Distribution
    ax7 = plt.subplot(3, 3, 7)
    data = [df_results[df_results['Method'] == m]['SSIM'].values for m in methods[:8]]
    bp = ax7.boxplot(data, labels=methods[:8], patch_artist=True, showmeans=True)
    for patch in bp['boxes']:
        patch.set_facecolor('lightgreen')
        patch.set_alpha(0.7)
    ax7.set_title('G) SSIM Distribution by Method', weight='bold', fontsize=14)
    ax7.set_ylabel('SSIM', fontsize=12)
    ax7.tick_params(axis='x', rotation=45, labelsize=8)
    ax7.grid(True, alpha=0.3, axis='y')
    ax7.set_ylim(0, 1)

    # 8. PSNR vs SSIM Correlation
    ax8 = plt.subplot(3, 3, 8)
    for method in methods:
        method_data = df_results[df_results['Method'] == method]
        ax8.scatter(method_data['PSNR'], method_data['SSIM'],
                    label=method, alpha=0.6, s=30)
    all_psnr = df_results['PSNR'].values
    all_ssim = df_results['SSIM'].values
    z = np.polyfit(all_psnr, all_ssim, 1)
    p = np.poly1d(z)
    ax8.plot(np.sort(all_psnr), p(np.sort(all_psnr)), "r--", linewidth=2, alpha=0.8)
    corr = np.corrcoef(all_psnr, all_ssim)[0, 1]
    ax8.text(0.05, 0.95, f'Correlation: r = {corr:.3f}', transform=ax8.transAxes,
             fontsize=11, bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    ax8.set_xlabel('PSNR (dB)', fontsize=12)
    ax8.set_ylabel('SSIM', fontsize=12)
    ax8.set_title('H) PSNR vs SSIM Correlation', weight='bold', fontsize=14)
    ax8.legend(bbox_to_anchor=(1.05, 1), fontsize=8)
    ax8.grid(True, alpha=0.3)

    # 9. Overall Ranking
    ax9 = plt.subplot(3, 3, 9)
    # Calculate ranking
    ranking_data = {}
    for metric in ['PSNR', 'SSIM']:
        ranking_data[metric] = df_results.groupby('Method')[metric].mean().rank(ascending=False)
    if 'BRISQUE' in df_results.columns:
        ranking_data['BRISQUE'] = df_results.groupby('Method')['BRISQUE'].mean().rank(ascending=True)

    rank_df = pd.DataFrame(ranking_data)
    rank_df['Overall'] = rank_df.mean(axis=1)
    rank_df = rank_df.sort_values('Overall')

    colors = ['gold' if i == 0 else 'silver' if i == 1 else '#CD7F32' if i == 2 else 'steelblue'
              for i in range(len(rank_df))]
    bars = ax9.barh(range(len(rank_df)), rank_df['Overall'].values, color=colors, edgecolor='black')
    ax9.set_yticks(range(len(rank_df)))
    ax9.set_yticklabels(rank_df.index, fontsize=10)
    ax9.set_xlabel('Average Rank (Lower Better)', fontsize=12)
    ax9.set_title('I) Overall Method Ranking', weight='bold', fontsize=14)
    ax9.invert_xaxis()

    for bar, val in zip(bars, rank_df['Overall'].values):
        ax9.text(bar.get_width() + 0.1, bar.get_y() + bar.get_height() / 2,
                 f'{val:.2f}', va='center', fontsize=9, fontweight='bold')

    plt.suptitle('TRANSFORMER IMAGE ENHANCEMENT - COMPREHENSIVE ANALYSIS DASHBOARD',
                 fontsize=18, weight='bold', y=0.98)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'COMPREHENSIVE_DASHBOARD.png'), bbox_inches='tight', dpi=300)
    plt.close()
    print("✅ Dashboard created")


def create_results_table(df_results, output_dir):
    """Create comprehensive results table"""

    metrics = ['PSNR', 'SSIM', 'Sharpness', 'Contrast', 'Entropy']
    if 'BRISQUE' in df_results.columns:
        metrics.append('BRISQUE')

    # Calculate statistics for each method
    stats_list = []
    for method in df_results['Method'].unique():
        method_data = df_results[df_results['Method'] == method]
        row = {'Method': method}

        for metric in metrics:
            row[f'{metric}_Mean'] = method_data[metric].mean()
            row[f'{metric}_Std'] = method_data[metric].std()

        stats_list.append(row)

    stats_df = pd.DataFrame(stats_list)

    # Calculate rankings
    for metric in metrics:
        if metric == 'BRISQUE':
            stats_df[f'{metric}_Rank'] = stats_df[f'{metric}_Mean'].rank(ascending=True).astype(int)
        else:
            stats_df[f'{metric}_Rank'] = stats_df[f'{metric}_Mean'].rank(ascending=False).astype(int)

    # Overall ranking
    rank_cols = [f'{m}_Rank' for m in metrics]
    stats_df['Overall_Rank_Score'] = stats_df[rank_cols].sum(axis=1)
    stats_df['Overall_Rank'] = stats_df['Overall_Rank_Score'].rank().astype(int)
    stats_df = stats_df.sort_values('Overall_Rank')

    # Performance classification
    def classify_performance(rank):
        if rank == 1:
            return '🏆 Best'
        elif rank == 2:
            return '🥈 Good'
        elif rank == 3:
            return '🥉 Average'
        else:
            return 'Standard'

    stats_df['Performance'] = stats_df['Overall_Rank'].apply(classify_performance)

    # Save to CSV
    stats_df.to_csv(os.path.join(output_dir, 'RESULTS_TABLE.csv'), index=False)

    # Create formatted text report
    with open(os.path.join(output_dir, 'ANALYSIS_REPORT.txt'), 'w', encoding='utf-8') as f:
        f.write("=" * 100 + "\n")
        f.write("TRANSFORMER IMAGE ENHANCEMENT - COMPLETE ANALYSIS REPORT\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("=" * 100 + "\n\n")

        # Dataset info
        f.write("DATASET INFORMATION:\n")
        f.write("-" * 50 + "\n")
        f.write(f"Total Methods Evaluated: {df_results['Method'].nunique()}\n")
        f.write(f"Total Images Processed: {df_results['Image'].nunique()}\n")
        f.write(f"Total Evaluations: {len(df_results)}\n")
        f.write(f"BRISQUE Status: {'Enabled' if BRISQUE_AVAILABLE else 'Disabled'}\n\n")

        # Top performers
        f.write("TOP PERFORMING METHODS:\n")
        f.write("-" * 50 + "\n")
        for i in range(min(3, len(stats_df))):
            row = stats_df.iloc[i]
            medal = ['🥇', '🥈', '🥉'][i]
            f.write(f"\n{medal} #{i + 1}: {row['Method']}\n")
            f.write(f"   • Overall Rank: {row['Overall_Rank']}\n")
            f.write(f"   • PSNR: {row['PSNR_Mean']:.2f} ± {row['PSNR_Std']:.2f} dB\n")
            f.write(f"   • SSIM: {row['SSIM_Mean']:.4f} ± {row['SSIM_Std']:.4f}\n")
            f.write(f"   • Sharpness: {row['Sharpness_Mean']:.1f} ± {row['Sharpness_Std']:.1f}\n")
            if 'BRISQUE' in df_results.columns:
                f.write(f"   • BRISQUE: {row['BRISQUE_Mean']:.2f} ± {row['BRISQUE_Std']:.2f}\n")

        # Complete table
        f.write("\n\nCOMPLETE RESULTS TABLE:\n")
        f.write("-" * 100 + "\n")
        header = f"{'Method':<20} {'PSNR (dB)':<18} {'SSIM':<12} {'Sharpness':<12}"
        if 'BRISQUE' in df_results.columns:
            header += f"{'BRISQUE':<12}"
        header += f"{'Rank':<8} {'Performance':<12}\n"
        f.write(header)
        f.write("-" * 100 + "\n")

        for _, row in stats_df.iterrows():
            line = f"{row['Method']:<20} "
            line += f"{row['PSNR_Mean']:.2f}±{row['PSNR_Std']:.2f}  "
            line += f"{row['SSIM_Mean']:.4f}±{row['SSIM_Std']:.4f}  "
            line += f"{row['Sharpness_Mean']:.0f}±{row['Sharpness_Std']:.0f}  "
            if 'BRISQUE' in df_results.columns:
                line += f"{row['BRISQUE_Mean']:.2f}±{row['BRISQUE_Std']:.2f}  "
            line += f"{row['Overall_Rank']:<8} {row['Performance']:<12}\n"
            f.write(line)

        # Statistical analysis
        f.write("\n\nSTATISTICAL ANALYSIS:\n")
        f.write("-" * 50 + "\n")

        # Best and worst performers
        best_psnr = stats_df.loc[stats_df['PSNR_Mean'].idxmax(), 'Method']
        best_ssim = stats_df.loc[stats_df['SSIM_Mean'].idxmax(), 'Method']
        f.write(f"\n• Highest PSNR: {best_psnr}\n")
        f.write(f"• Highest SSIM: {best_ssim}\n")

        if 'BRISQUE' in df_results.columns:
            best_brisque = stats_df.loc[stats_df['BRISQUE_Mean'].idxmin(), 'Method']
            f.write(f"• Best BRISQUE (lower is better): {best_brisque}\n")

        # Correlation analysis
        psnr_ssim_corr = df_results['PSNR'].corr(df_results['SSIM'])
        f.write(f"\n• Correlation between PSNR and SSIM: {psnr_ssim_corr:.3f}\n")

        if 'BRISQUE' in df_results.columns:
            psnr_brisque_corr = df_results['PSNR'].corr(df_results['BRISQUE'])
            f.write(f"• Correlation between PSNR and BRISQUE: {psnr_brisque_corr:.3f}\n")

        # Interpretation guide
        f.write("\n\nINTERPRETATION GUIDE:\n")
        f.write("-" * 50 + "\n")
        f.write("• PSNR (Peak Signal-to-Noise Ratio): Higher is better\n")
        f.write("  - Excellent: >40 dB, Good: 30-40 dB, Poor: <30 dB\n")
        f.write("• SSIM (Structural Similarity): Higher is better (range 0-1)\n")
        f.write("  - Excellent: >0.95, Good: 0.90-0.95, Poor: <0.90\n")
        if 'BRISQUE' in df_results.columns:
            f.write("• BRISQUE (Blind/Referenceless Image Quality): Lower is better\n")
            f.write("  - Excellent: <30, Good: 30-50, Poor: >50\n")
        f.write("• Sharpness: Higher values indicate clearer edges\n")
        f.write("• Contrast: Higher values indicate better dynamic range\n")
        f.write("• Entropy: Higher values indicate more information content\n")

        f.write("\n" + "=" * 100 + "\n")

    print("✅ Results table created")
    return stats_df


# =============================================
# MAIN EXECUTION
# =============================================
def main():
    print("=" * 80)
    print("TRANSFORMER IMAGE ENHANCEMENT ANALYSIS SYSTEM")
    print("Comprehensive Quality Assessment")
    print("=" * 80)

    if not BRISQUE_AVAILABLE:
        print("\n⚠️ BRISQUE not available. Run: pip install imquality")
        print("   Continuing with PSNR, SSIM and other metrics only.\n")
    else:
        print("\n✅ BRISQUE enabled - No-reference quality assessment active\n")

    # Process all images
    print("🖼️ Processing images...")
    results_df = process_all_folders()

    if len(results_df) == 0:
        print("\n❌ ERROR: No results generated. Please check paths and files.")
        return

    print(f"\n✅ Successfully processed {len(results_df)} image-method combinations")
    print(f"   Methods: {', '.join(results_df['Method'].unique())}")
    print(f"   Images per method: {results_df.groupby('Method').size().iloc[0]}")

    # Create output directory
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Generate visualizations and reports
    print("\n📊 Generating visualizations...")
    create_comprehensive_dashboard(results_df, OUTPUT_DIR)

    print("\n📋 Creating results table...")
    stats_df = create_results_table(results_df, OUTPUT_DIR)

    # Save raw data
    results_df.to_csv(os.path.join(OUTPUT_DIR, 'raw_metrics_data.csv'), index=False)

    # Final summary
    print("\n" + "=" * 80)
    print("🎉 ANALYSIS COMPLETE!")
    print("=" * 80)
    print(f"\n📁 Results saved to: {OUTPUT_DIR}")
    print("\n📊 Generated Files:")
    print("   ⭐ COMPREHENSIVE_DASHBOARD.png - Complete visual analysis")
    print("   ⭐ RESULTS_TABLE.csv - Numerical results with rankings")
    print("   ⭐ ANALYSIS_REPORT.txt - Detailed text report")
    print("   ⭐ raw_metrics_data.csv - Raw data for further analysis")

    print("\n🏆 FINAL RANKINGS:")
    for i in range(min(3, len(stats_df))):
        row = stats_df.iloc[i]
        medals = ["🥇 FIRST", "🥈 SECOND", "🥉 THIRD"][i]
        print(f"   {medals}: {row['Method']} (PSNR: {row['PSNR_Mean']:.2f}dB, SSIM: {row['SSIM_Mean']:.3f})")

    print("\n" + "=" * 80)
    print("✅ Analysis ready for paper inclusion")
    print("=" * 80)


if __name__ == "__main__":
    main()