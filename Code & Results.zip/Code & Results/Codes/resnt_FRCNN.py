import os
import torch
import random
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from torch.utils.data import Dataset, DataLoader, random_split
import torchvision.transforms as transforms
import torchvision
from torchvision.models.detection import fasterrcnn_resnet50_fpn
from torchvision.ops import box_iou
from sklearn.metrics import precision_score, recall_score, f1_score

# === CONFIG ===
SEED = 42
torch.manual_seed(SEED)
random.seed(SEED)
np.random.seed(SEED)

IMAGE_DIR = 'C:/Users/imriz/OneDrive/Desktop/REVIEW LLIE DATASET/DarkFace_Train_2021/image'
LABEL_DIR = 'C:/Users/imriz/OneDrive/Desktop/REVIEW LLIE DATASET/DarkFace_Train_2021/label'
NUM_CLASSES = 2  # face + background
BATCH_SIZE = 4
EPOCHS = 10
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# === DATASET ===
# === DATASET ===
class DarkFaceDataset(Dataset):
    def __init__(self, image_dir, label_dir, transforms=None):
        self.image_dir = image_dir
        self.label_dir = label_dir
        self.transforms = transforms
        self.image_files = sorted([f for f in os.listdir(image_dir) if f.endswith(('.jpg', '.png'))])

    def __getitem__(self, idx):
        image_name = self.image_files[idx]
        img_path = os.path.join(self.image_dir, image_name)
        label_path = os.path.join(self.label_dir, os.path.splitext(image_name)[0] + '.txt')

        img = Image.open(img_path).convert("RGB")

        boxes = []
        if os.path.exists(label_path):
            with open(label_path, 'r') as f:
                lines = f.readlines()
                if lines:
                    try:
                        num_boxes = int(lines[0])
                        for line in lines[1:1+num_boxes]:
                            x1, y1, x2, y2 = map(int, line.strip().split())
                            if x2 > x1 and y2 > y1:  # filter invalid boxes
                                boxes.append([x1, y1, x2, y2])
                    except:
                        pass  # skip broken annotations

        if len(boxes) == 0:
            # Add a dummy box outside image area so model doesn't crash
            boxes = torch.tensor([[0, 0, 1, 1]], dtype=torch.float32)
            labels = torch.zeros((1,), dtype=torch.int64)  # background label (0)
        else:
            boxes = torch.as_tensor(boxes, dtype=torch.float32)
            labels = torch.ones((len(boxes),), dtype=torch.int64)  # all valid boxes as class 1

        target = {'boxes': boxes, 'labels': labels}
        if self.transforms:
            img = self.transforms(img)
        return img, target

    def __len__(self):
        return len(self.image_files)

# === TRANSFORMS ===
transform = transforms.Compose([transforms.ToTensor()])

# === LOAD DATASET AND SPLIT ===
full_dataset = DarkFaceDataset(IMAGE_DIR, LABEL_DIR, transforms=transform)
train_size = int(0.8 * len(full_dataset))
test_size = len(full_dataset) - train_size
train_dataset, test_dataset = random_split(full_dataset, [train_size, test_size])
train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, collate_fn=lambda x: tuple(zip(*x)))
test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False, collate_fn=lambda x: tuple(zip(*x)))

# === MODEL ===
model = fasterrcnn_resnet50_fpn(pretrained=True)
in_features = model.roi_heads.box_predictor.cls_score.in_features
model.roi_heads.box_predictor = torchvision.models.detection.faster_rcnn.FastRCNNPredictor(in_features, NUM_CLASSES)
model.to(DEVICE)

optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)

# === TRAIN FUNCTION ===
train_losses = []

def train_one_epoch():
    model.train()
    epoch_loss = 0
    for images, targets in train_loader:
        images = [img.to(DEVICE) for img in images]
        targets = [{k: v.to(DEVICE) for k, v in t.items()} for t in targets]
        loss_dict = model(images, targets)
        loss = sum(loss for loss in loss_dict.values())
        epoch_loss += loss.item()
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    avg_loss = epoch_loss / len(train_loader)
    print(f"Train Loss: {avg_loss:.4f}")
    train_losses.append(avg_loss)

# === EVALUATION FUNCTION ===
def evaluate(model, test_loader, iou_threshold=0.5):
    model.eval()
    all_preds = []
    all_targets = []

    with torch.no_grad():
        for images, targets in test_loader:
            images = [img.to(DEVICE) for img in images]
            outputs = model(images)
            for output, target in zip(outputs, targets):
                true_boxes = target['boxes'].to(DEVICE)
                pred_boxes = output['boxes']
                scores = output['scores']
                keep = scores > 0.5
                pred_boxes = pred_boxes[keep]

                ious = box_iou(pred_boxes, true_boxes)
                if ious.numel() == 0:
                    all_preds.append(0)
                    all_targets.append(1)
                    continue

                matched = (ious > iou_threshold).any(dim=1).int().cpu().numpy()
                preds = np.ones_like(matched)
                all_preds.extend(preds)
                all_targets.extend(matched)

    precision = precision_score(all_targets, all_preds, zero_division=0)
    recall = recall_score(all_targets, all_preds, zero_division=0)
    f1 = f1_score(all_targets, all_preds, zero_division=0)
    print(f"Precision: {precision:.4f}, Recall: {recall:.4f}, F1: {f1:.4f}")
    return precision, recall, f1

# === TRAINING LOOP ===
metrics = []
for epoch in range(EPOCHS):
    print(f"\nEpoch {epoch+1}/{EPOCHS}")
    train_one_epoch()
    precision, recall, f1 = evaluate(model, test_loader)
    metrics.append((precision, recall, f1))

# === PLOT LOSS AND METRICS ===
epochs = list(range(1, EPOCHS+1))
precisions, recalls, f1s = zip(*metrics)

plt.figure(figsize=(12, 4))
plt.subplot(1, 2, 1)
plt.plot(epochs, train_losses, label='Train Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training Loss')
plt.grid(True)
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(epochs, precisions, label='Precision')
plt.plot(epochs, recalls, label='Recall')
plt.plot(epochs, f1s, label='F1 Score')
plt.xlabel('Epoch')
plt.ylabel('Score')
plt.title('Evaluation Metrics')
plt.grid(True)
plt.legend()

plt.tight_layout()
plt.show()
