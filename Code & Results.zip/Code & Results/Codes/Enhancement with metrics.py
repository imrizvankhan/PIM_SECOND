import os
import cv2
import numpy as np
from skimage.metrics import peak_signal_noise_ratio as psnr, structural_similarity as ssim
import matplotlib.pyplot as plt
from tqdm import tqdm
import pandas as pd
import seaborn as sns
from matplotlib.ticker import PercentFormatter
from sklearn.preprocessing import MinMaxScaler
from math import pi
from datetime import datetime
from PIL import Image
import torch
from scipy.stats import pearsonr, spearmanr, kendalltau, f_oneway
from scipy.cluster.hierarchy import dendrogram, linkage
import warnings

warnings.filterwarnings('ignore')

# Fix OpenMP error
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

# Try to import piq for BRISQUE
try:
    import piq

    PIQ_AVAILABLE = True
    print("✅ PIQ library loaded successfully")
except ImportError:
    print("⚠️ Installing PIQ...")
    os.system("pip install piq torch torchvision pillow -q")
    try:
        import piq

        PIQ_AVAILABLE = True
        print("✅ PIQ installed successfully")
    except:
        PIQ_AVAILABLE = False
        print("❌ PIQ not available. BRISQUE disabled.")

# =============================================
# CONFIGURATION
# =============================================
INPUT_DIR = r'E:\My_Papers\dataset2_resized\low'
GT_DIR = r'E:\My_Papers\dataset2_resized\high'
OUTPUT_DIR = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET\resize_impact_results_N'
RESIZE_FACTORS = [1.0, 0.75, 0.50, 0.25]
os.makedirs(OUTPUT_DIR, exist_ok=True)


# =============================================
# BRISQUE METRIC
# =============================================
def calculate_brisque_piq(image):
    """Calculate BRISQUE score (lower = better quality, range 0-100)"""
    if not PIQ_AVAILABLE:
        return None
    try:
        if len(image.shape) == 3:
            img_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        else:
            img_rgb = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)

        img_pil = Image.fromarray(img_rgb)
        img_pil = img_pil.resize((224, 224), Image.Resampling.LANCZOS)
        img_tensor = torch.from_numpy(np.array(img_pil)).permute(2, 0, 1).float() / 255.0
        img_tensor = img_tensor.unsqueeze(0)

        with torch.no_grad():
            score = piq.brisque(img_tensor, data_range=1.0)
        return max(0, min(100, score.item()))
    except:
        return None


# =============================================
# ENHANCEMENT TECHNIQUES
# =============================================
def histogram_equalization(img):
    if len(img.shape) == 2:
        return cv2.equalizeHist(img)
    else:
        img_yuv = cv2.cvtColor(img, cv2.COLOR_BGR2YUV)
        img_yuv[:, :, 0] = cv2.equalizeHist(img_yuv[:, :, 0])
        return cv2.cvtColor(img_yuv, cv2.COLOR_YUV2BGR)


def clahe_enhancement(img, clip_limit=2.0, grid_size=(8, 8)):
    if len(img.shape) == 2:
        clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=grid_size)
        return clahe.apply(img)
    else:
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=grid_size)
        l = clahe.apply(l)
        lab = cv2.merge((l, a, b))
        return cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)


def gamma_correction(img, gamma=1.2):
    inv_gamma = 1.0 / gamma
    table = np.array([((i / 255.0) ** inv_gamma) * 255 for i in np.arange(0, 256)]).astype("uint8")
    return cv2.LUT(img, table)


def contrast_stretching(img):
    if len(img.shape) == 2:
        min_val, max_val = np.min(img), np.max(img)
        return ((img - min_val) * (255.0 / (max_val - min_val))).astype(np.uint8)
    else:
        stretched = np.zeros_like(img)
        for i in range(3):
            min_val, max_val = np.min(img[:, :, i]), np.max(img[:, :, i])
            stretched[:, :, i] = ((img[:, :, i] - min_val) * (255.0 / (max_val - min_val))).astype(np.uint8)
        return stretched


def unsharp_mask(img, kernel_size=(5, 5), sigma=1.0, amount=1.0):
    blurred = cv2.GaussianBlur(img, kernel_size, sigma)
    return cv2.addWeighted(img, 1.0 + amount, blurred, -amount, 0)


def bilateral_filtering(img, d=9, sigma_color=75, sigma_space=75):
    return cv2.bilateralFilter(img, d, sigma_color, sigma_space)


def edge_enhancement(img):
    kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
    return cv2.filter2D(img, -1, kernel)


def logarithmic_transformation(img, c=1.0):
    img_float = img.astype(np.float32) / 255.0
    log_transformed = c * np.log(1 + img_float) * 255.0
    return np.clip(log_transformed, 0, 255).astype(np.uint8)


def box_filtering(img, kernel_size=(3, 3)):
    return cv2.blur(img, kernel_size)


def denoise_image(img, h=10):
    return cv2.fastNlMeansDenoisingColored(img, None, h, h, 7, 21)


def hls_enhancement(img):
    hls = cv2.cvtColor(img, cv2.COLOR_BGR2HLS)
    hls[:, :, 1] = cv2.equalizeHist(hls[:, :, 1])
    return cv2.cvtColor(hls, cv2.COLOR_HLS2BGR)


ENHANCEMENTS = {
    'Histogram EQ': histogram_equalization,
    'CLAHE': clahe_enhancement,
    'Gamma': gamma_correction,
    'Contrast Stretch': contrast_stretching,
    'Unsharp Mask': unsharp_mask,
    'Bilateral': bilateral_filtering,
    'Edge Enhance': edge_enhancement,
    'Log Transform': logarithmic_transformation,
    'Box Filter': box_filtering,
    'Denoise': denoise_image,
    'HLS Enhance': hls_enhancement
}


# =============================================
# METRIC CALCULATION
# =============================================
def calculate_metrics(enhanced, gt):
    """Calculate all quality metrics"""
    metrics = {}
    try:
        # Full-reference metrics
        metrics['PSNR'] = np.clip(psnr(gt, enhanced, data_range=255), 0, 100)
        metrics['SSIM'] = np.clip(ssim(gt, enhanced, channel_axis=2, data_range=255), 0, 1)
        metrics['MSE'] = np.mean((gt - enhanced) ** 2)

        # No-reference metrics
        gray = cv2.cvtColor(enhanced, cv2.COLOR_BGR2GRAY)
        metrics['Sharpness'] = cv2.Laplacian(gray, cv2.CV_64F).var()

        hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
        hist = hist / (hist.sum() + 1e-7)
        metrics['Entropy'] = -np.sum(hist * np.log2(hist + 1e-7))
        metrics['Contrast'] = np.std(gray)

        # BRISQUE
        if PIQ_AVAILABLE:
            brisque_score = calculate_brisque_piq(enhanced)
            if brisque_score is not None:
                metrics['BRISQUE'] = brisque_score

    except Exception as e:
        return None
    return metrics


# =============================================
# DATA CLEANING FUNCTION
# =============================================
def clean_dataframe(df):
    """Remove NaN, Inf, and invalid values from dataframe"""
    df = df.replace([np.inf, -np.inf], np.nan)
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    df_clean = df.dropna(subset=numeric_cols)
    for col in numeric_cols:
        df_clean = df_clean[df_clean[col].notna()]
        df_clean = df_clean[np.isfinite(df_clean[col])]
    print(f"   Data cleaning: Removed {len(df) - len(df_clean)} rows with invalid values")
    return df_clean


# =============================================
# ENHANCED VISUALIZATION SETTINGS (LARGER FONTS FOR PAPERS)
# =============================================
def set_plot_style():
    plt.style.use('seaborn-v0_8-whitegrid')
    sns.set_palette("husl")
    plt.rcParams.update({
        'figure.dpi': 300,
        'font.family': 'sans-serif',
        'font.sans-serif': ['Arial', 'DejaVu Sans'],
        'axes.titlesize': 14,  # Increased from 10
        'axes.labelsize': 12,  # Increased from 9
        'xtick.labelsize': 10,  # Increased from 8
        'ytick.labelsize': 10,  # Increased from 8
        'legend.fontsize': 10,  # Increased from 8
        'legend.title_fontsize': 11,
        'figure.titlesize': 16,
        'figure.autolayout': True,
        'axes.grid': True,
        'grid.alpha': 0.3
    })


# =============================================
# MASTER DASHBOARD (ENHANCED WITH LARGER FONTS)
# =============================================
def create_master_dashboard(results_df, report_dir):
    """Create comprehensive dashboard with larger fonts for paper readability"""
    set_plot_style()
    results_df = clean_dataframe(results_df)

    metrics = ['PSNR', 'SSIM', 'Sharpness', 'Contrast', 'Entropy']
    if 'BRISQUE' in results_df.columns:
        metrics.append('BRISQUE')

    # Larger figure size for better readability
    fig = plt.figure(figsize=(24, 20))
    gs = fig.add_gridspec(4, 3, hspace=0.35, wspace=0.35)

    # 1. Heatmap of average metrics by method
    ax1 = fig.add_subplot(gs[0, 0])
    avg_by_method = results_df.groupby('Method')[metrics].mean()
    sns.heatmap(avg_by_method, annot=True, fmt='.2f', cmap='YlOrRd', ax=ax1,
                cbar_kws={'label': 'Value', 'shrink': 0.8}, annot_kws={'size': 9})
    ax1.set_title('A) Method Performance Heatmap', weight='bold', fontsize=14)
    ax1.set_xlabel('Metrics', fontsize=12)
    ax1.set_ylabel('Methods', fontsize=12)
    ax1.tick_params(axis='x', rotation=45, labelsize=10)
    ax1.tick_params(axis='y', labelsize=10)

    # 2. Radar chart for top 5 methods
    ax2 = fig.add_subplot(gs[0, 1], projection='polar')
    if 'BRISQUE' in avg_by_method.columns:
        avg_for_radar = avg_by_method.copy()
        avg_for_radar['BRISQUE'] = 100 - avg_for_radar['BRISQUE']
    else:
        avg_for_radar = avg_by_method

    overall_score = avg_for_radar.mean(axis=1)
    top_methods = overall_score.nlargest(5).index
    plot_radar_on_axis(avg_for_radar.loc[top_methods], metrics, ax2)
    ax2.set_title('B) Top 5 Methods Comparison', weight='bold', fontsize=14, pad=25)

    # 3. Correlation matrix
    ax3 = fig.add_subplot(gs[0, 2])
    corr_matrix = results_df[metrics].corr()
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
    sns.heatmap(corr_matrix, mask=mask, annot=True, fmt='.2f', cmap='RdBu_r',
                center=0, vmin=-1, vmax=1, ax=ax3, square=True, annot_kws={'size': 9})
    ax3.set_title('C) Metric Correlation Matrix', weight='bold', fontsize=14)
    ax3.set_xlabel('Metrics', fontsize=12)
    ax3.set_ylabel('Metrics', fontsize=12)
    ax3.tick_params(labelsize=10)

    # 4. Size impact on PSNR
    ax4 = fig.add_subplot(gs[1, 0])
    size_factors = sorted(results_df['Size_Factor'].unique())
    for method in results_df['Method'].unique()[:8]:
        method_data = results_df[results_df['Method'] == method]
        means = [method_data[method_data['Size_Factor'] == sf]['PSNR'].mean() for sf in size_factors]
        ax4.plot(size_factors, means, marker='o', label=method, linewidth=2, markersize=6)
    ax4.set_xlabel('Resize Factor', fontsize=12)
    ax4.set_ylabel('PSNR (dB)', fontsize=12)
    ax4.set_title('D) PSNR vs Image Size', weight='bold', fontsize=14)
    ax4.legend(bbox_to_anchor=(1.05, 1), fontsize=9)
    ax4.grid(True, alpha=0.3)
    ax4.tick_params(labelsize=10)

    # 5. Size impact on BRISQUE
    ax5 = fig.add_subplot(gs[1, 1])
    if 'BRISQUE' in results_df.columns:
        for method in results_df['Method'].unique()[:8]:
            method_data = results_df[results_df['Method'] == method]
            means = [method_data[method_data['Size_Factor'] == sf]['BRISQUE'].mean() for sf in size_factors]
            ax5.plot(size_factors, means, marker='o', label=method, linewidth=2, markersize=6)
        ax5.set_xlabel('Resize Factor', fontsize=12)
        ax5.set_ylabel('BRISQUE (lower better)', fontsize=12)
        ax5.set_title('E) BRISQUE vs Image Size', weight='bold', fontsize=14)
        ax5.axhline(y=30, color='g', linestyle='--', alpha=0.5, linewidth=2, label='Good threshold')
        ax5.axhline(y=50, color='orange', linestyle='--', alpha=0.5, linewidth=2, label='Poor threshold')
        ax5.legend(fontsize=10)
        ax5.grid(True, alpha=0.3)
        ax5.tick_params(labelsize=10)

    # 6. Method ranking bar chart
    ax6 = fig.add_subplot(gs[1, 2])
    ranking = calculate_method_ranking(results_df, metrics)
    top_10 = ranking.head(10)
    colors = ['gold' if i == 0 else 'silver' if i == 1 else '#CD7F32' if i == 2 else 'steelblue'
              for i in range(len(top_10))]
    ax6.barh(range(len(top_10)), top_10.values, color=colors, edgecolor='black', height=0.7)
    ax6.set_yticks(range(len(top_10)))
    ax6.set_yticklabels(top_10.index, fontsize=10)
    ax6.set_xlabel('Average Rank (Lower Better)', fontsize=12)
    ax6.set_title('F) Overall Method Ranking', weight='bold', fontsize=14)
    ax6.invert_xaxis()
    ax6.tick_params(labelsize=10)

    # 7. PSNR Distribution
    ax7 = fig.add_subplot(gs[2, 0])
    methods_subset = results_df['Method'].unique()[:8]
    psnr_data = [results_df[results_df['Method'] == m]['PSNR'].values for m in methods_subset]
    bp = ax7.boxplot(psnr_data, labels=methods_subset, patch_artist=True)
    for patch in bp['boxes']:
        patch.set_facecolor('lightblue')
        patch.set_alpha(0.7)
    ax7.set_title('G) PSNR Distribution by Method', weight='bold', fontsize=14)
    ax7.set_ylabel('PSNR (dB)', fontsize=12)
    ax7.tick_params(axis='x', rotation=45, labelsize=9)
    ax7.tick_params(labelsize=10)
    ax7.grid(True, alpha=0.3, axis='y')

    # 8. SSIM Distribution
    ax8 = fig.add_subplot(gs[2, 1])
    ssim_data = [results_df[results_df['Method'] == m]['SSIM'].values for m in methods_subset]
    bp2 = ax8.boxplot(ssim_data, labels=methods_subset, patch_artist=True)
    for patch in bp2['boxes']:
        patch.set_facecolor('lightgreen')
        patch.set_alpha(0.7)
    ax8.set_title('H) SSIM Distribution by Method', weight='bold', fontsize=14)
    ax8.set_ylabel('SSIM', fontsize=12)
    ax8.tick_params(axis='x', rotation=45, labelsize=9)
    ax8.tick_params(labelsize=10)
    ax8.grid(True, alpha=0.3, axis='y')

    # 9. Scatter PSNR vs BRISQUE
    ax9 = fig.add_subplot(gs[2, 2])
    if 'BRISQUE' in results_df.columns:
        scatter = ax9.scatter(results_df['PSNR'], results_df['BRISQUE'],
                              c=results_df['Size_Factor'], cmap='viridis',
                              alpha=0.6, s=30)
        ax9.set_xlabel('PSNR (dB)', fontsize=12)
        ax9.set_ylabel('BRISQUE (lower better)', fontsize=12)
        ax9.set_title('I) PSNR vs BRISQUE Correlation', weight='bold', fontsize=14)
        cbar = plt.colorbar(scatter, ax=ax9)
        cbar.set_label('Resize Factor', fontsize=10)
        ax9.grid(True, alpha=0.3)
        ax9.tick_params(labelsize=10)

        corr = results_df['PSNR'].corr(results_df['BRISQUE'])
        ax9.text(0.05, 0.95, f'Correlation: r = {corr:.3f}', transform=ax9.transAxes,
                 fontsize=11, bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))

    # 10. Metrics by size summary
    ax10 = fig.add_subplot(gs[3, :])
    size_metrics = results_df.groupby('Size_Factor')[['PSNR', 'SSIM', 'Sharpness']].mean()
    if 'BRISQUE' in results_df.columns:
        size_metrics['BRISQUE'] = results_df.groupby('Size_Factor')['BRISQUE'].mean()
        size_metrics['BRISQUE_Inv'] = 100 - size_metrics['BRISQUE']

    for col in size_metrics.columns:
        if col != 'BRISQUE' and size_metrics[col].iloc[0] != 0:
            size_metrics[col] = (size_metrics[col] / size_metrics[col].iloc[0]) * 100

    size_metrics[['PSNR', 'SSIM', 'Sharpness']].plot(marker='o', ax=ax10, linewidth=2.5, markersize=8)
    if 'BRISQUE_Inv' in size_metrics.columns:
        size_metrics['BRISQUE_Inv'].plot(marker='s', ax=ax10, linewidth=2.5, markersize=8, linestyle='--')

    ax10.set_xlabel('Resize Factor', fontsize=12)
    ax10.set_ylabel('Percentage of Original Quality (%)', fontsize=12)
    ax10.set_title('J) Metric Degradation with Image Resizing', weight='bold', fontsize=14)
    ax10.grid(True, alpha=0.3)
    ax10.legend(['PSNR', 'SSIM', 'Sharpness', 'BRISQUE (inverted)'], fontsize=10, loc='best')
    ax10.tick_params(labelsize=10)

    plt.suptitle('COMPREHENSIVE IMAGE ENHANCEMENT ANALYSIS DASHBOARD\n' +
                 'Full-Reference (PSNR, SSIM) & No-Reference (BRISQUE, Sharpness) Metrics',
                 fontsize=18, weight='bold', y=0.98)

    plt.savefig(os.path.join(report_dir, 'MASTER_DASHBOARD.png'), bbox_inches='tight', dpi=300)
    plt.close()
    print("✅ Master dashboard created with all metrics integrated")


def plot_radar_on_axis(data, metrics, ax):
    """Helper function to plot radar chart on existing axis"""
    categories = metrics
    N = len(categories)
    angles = [n / float(N) * 2 * pi for n in range(N)]
    angles += angles[:1]

    scaler = MinMaxScaler()
    data_normalized = pd.DataFrame(scaler.fit_transform(data),
                                   index=data.index, columns=data.columns)

    for idx, method in enumerate(data.index):
        values = data_normalized.loc[method].values.flatten().tolist()
        values += values[:1]
        ax.plot(angles, values, 'o-', linewidth=2, label=method, markersize=5)
        ax.fill(angles, values, alpha=0.1)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories, size=10)
    ax.set_ylim(0, 1)
    ax.set_yticks([0.2, 0.4, 0.6, 0.8, 1])
    ax.set_yticklabels(['20%', '40%', '60%', '80%', '100%'], size=9)
    ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0), fontsize=9)


def calculate_method_ranking(results_df, metrics):
    """Calculate overall method ranking"""
    rankings = []
    for metric in metrics:
        if metric == 'BRISQUE':
            ranking = results_df.groupby('Method')[metric].mean().rank(ascending=True)
        else:
            ranking = results_df.groupby('Method')[metric].mean().rank(ascending=False)
        rankings.append(ranking)

    ranking_df = pd.DataFrame(rankings).T
    ranking_df['Average_Rank'] = ranking_df.mean(axis=1)
    return ranking_df.sort_values('Average_Rank')['Average_Rank']


# =============================================
# COMPREHENSIVE CORRELATION ANALYSIS
# =============================================
def comprehensive_correlation_analysis(results_df, report_dir):
    """Perform and visualize all correlation analyses with proper NaN handling"""
    set_plot_style()
    results_df = clean_dataframe(results_df)

    metrics = ['PSNR', 'SSIM', 'Sharpness', 'Contrast', 'Entropy', 'MSE']
    if 'BRISQUE' in results_df.columns:
        metrics.append('BRISQUE')

    metrics = [m for m in metrics if m in results_df.columns]

    for metric in metrics:
        if results_df[metric].isna().any():
            print(f"   Warning: {metric} contains {results_df[metric].isna().sum()} NaN values")
            results_df = results_df[results_df[metric].notna()]

    pearson_corr = results_df[metrics].corr(method='pearson')
    spearman_corr = results_df[metrics].corr(method='spearman')

    pearson_p = pd.DataFrame(np.ones_like(pearson_corr), index=metrics, columns=metrics)
    for i, m1 in enumerate(metrics):
        for j, m2 in enumerate(metrics):
            if i != j:
                clean_data = results_df[[m1, m2]].dropna()
                if len(clean_data) > 2:
                    try:
                        _, p = pearsonr(clean_data[m1], clean_data[m2])
                        pearson_p.iloc[i, j] = p
                    except:
                        pearson_p.iloc[i, j] = 1.0

    fig, axes = plt.subplots(2, 3, figsize=(20, 14))

    # 1. Pearson correlation heatmap
    sns.heatmap(pearson_corr, annot=True, fmt='.3f', cmap='RdBu_r',
                center=0, vmin=-1, vmax=1, ax=axes[0, 0], square=True,
                annot_kws={'size': 10})
    axes[0, 0].set_title('Pearson Correlation (Linear)', weight='bold', fontsize=14)
    axes[0, 0].tick_params(labelsize=10)

    # 2. Spearman correlation heatmap
    sns.heatmap(spearman_corr, annot=True, fmt='.3f', cmap='RdBu_r',
                center=0, vmin=-1, vmax=1, ax=axes[0, 1], square=True,
                annot_kws={'size': 10})
    axes[0, 1].set_title('Spearman Correlation (Monotonic)', weight='bold', fontsize=14)
    axes[0, 1].tick_params(labelsize=10)

    # 3. Correlation with significance
    corr_sig = pearson_corr.copy()
    for i in range(len(metrics)):
        for j in range(len(metrics)):
            if pearson_p.iloc[i, j] < 0.001:
                corr_sig.iloc[i, j] = f"{pearson_corr.iloc[i, j]:.3f}***"
            elif pearson_p.iloc[i, j] < 0.01:
                corr_sig.iloc[i, j] = f"{pearson_corr.iloc[i, j]:.3f}**"
            elif pearson_p.iloc[i, j] < 0.05:
                corr_sig.iloc[i, j] = f"{pearson_corr.iloc[i, j]:.3f}*"
            else:
                corr_sig.iloc[i, j] = f"{pearson_corr.iloc[i, j]:.3f}"

    sns.heatmap(pearson_corr, annot=corr_sig, fmt='', cmap='RdBu_r',
                center=0, vmin=-1, vmax=1, ax=axes[0, 2], square=True,
                annot_kws={'size': 9})
    axes[0, 2].set_title('Correlation with Significance', weight='bold', fontsize=14)
    axes[0, 2].tick_params(labelsize=10)

    # 4. Hierarchical clustering dendrogram
    try:
        linkage_matrix = linkage(pearson_corr, method='ward')
        dendrogram(linkage_matrix, labels=metrics, ax=axes[1, 0], orientation='top',
                   leaf_rotation=45, leaf_font_size=10)
        axes[1, 0].set_title('Hierarchical Clustering of Metrics', weight='bold', fontsize=14)
        axes[1, 0].set_xlabel('Metrics', fontsize=12)
        axes[1, 0].set_ylabel('Distance', fontsize=12)
        axes[1, 0].tick_params(labelsize=10)
    except:
        axes[1, 0].text(0.5, 0.5, 'Clustering unavailable', ha='center', va='center', fontsize=12)
        axes[1, 0].set_title('Hierarchical Clustering Unavailable', weight='bold', fontsize=14)

    # 5. Scatter: PSNR vs SSIM
    ax_scatter1 = axes[1, 1]
    clean_psnr_ssim = results_df[['PSNR', 'SSIM']].dropna()
    if len(clean_psnr_ssim) > 2:
        ax_scatter1.scatter(clean_psnr_ssim['PSNR'], clean_psnr_ssim['SSIM'], alpha=0.5, s=30)
        z = np.polyfit(clean_psnr_ssim['PSNR'], clean_psnr_ssim['SSIM'], 1)
        p = np.poly1d(z)
        ax_scatter1.plot(sorted(clean_psnr_ssim['PSNR']), p(sorted(clean_psnr_ssim['PSNR'])), "r--", alpha=0.8,
                         linewidth=2)
        corr = clean_psnr_ssim['PSNR'].corr(clean_psnr_ssim['SSIM'])
        ax_scatter1.text(0.05, 0.95, f'r = {corr:.3f}', transform=ax_scatter1.transAxes,
                         fontsize=11, bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    ax_scatter1.set_xlabel('PSNR', fontsize=12)
    ax_scatter1.set_ylabel('SSIM', fontsize=12)
    ax_scatter1.set_title('PSNR vs SSIM', weight='bold', fontsize=14)
    ax_scatter1.grid(True, alpha=0.3)
    ax_scatter1.tick_params(labelsize=10)

    # 6. Scatter: PSNR vs BRISQUE
    ax_scatter2 = axes[1, 2]
    if 'BRISQUE' in results_df.columns:
        clean_psnr_brisque = results_df[['PSNR', 'BRISQUE']].dropna()
        if len(clean_psnr_brisque) > 2:
            ax_scatter2.scatter(clean_psnr_brisque['PSNR'], clean_psnr_brisque['BRISQUE'], alpha=0.5, s=30)
            z = np.polyfit(clean_psnr_brisque['PSNR'], clean_psnr_brisque['BRISQUE'], 1)
            p = np.poly1d(z)
            ax_scatter2.plot(sorted(clean_psnr_brisque['PSNR']), p(sorted(clean_psnr_brisque['PSNR'])), "r--",
                             alpha=0.8, linewidth=2)
            corr = clean_psnr_brisque['PSNR'].corr(clean_psnr_brisque['BRISQUE'])
            ax_scatter2.text(0.05, 0.95, f'r = {corr:.3f}', transform=ax_scatter2.transAxes,
                             fontsize=11, bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        ax_scatter2.set_xlabel('PSNR', fontsize=12)
        ax_scatter2.set_ylabel('BRISQUE', fontsize=12)
        ax_scatter2.set_title('PSNR vs BRISQUE', weight='bold', fontsize=14)
        ax_scatter2.grid(True, alpha=0.3)
        ax_scatter2.tick_params(labelsize=10)

    plt.suptitle('COMPREHENSIVE CORRELATION ANALYSIS\nRelationships Between Different Quality Metrics',
                 fontsize=16, weight='bold', y=1.02)
    plt.tight_layout()
    plt.savefig(os.path.join(report_dir, 'COMPREHENSIVE_CORRELATION.png'), bbox_inches='tight', dpi=300)
    plt.close()

    # Save correlation data
    pearson_corr.to_csv(os.path.join(report_dir, 'pearson_correlation.csv'))
    spearman_corr.to_csv(os.path.join(report_dir, 'spearman_correlation.csv'))
    pearson_p.to_csv(os.path.join(report_dir, 'correlation_pvalues.csv'))

    return pearson_corr, spearman_corr


# =============================================
# METHOD IMPACT ANALYSIS
# =============================================
def method_impact_analysis(results_df, report_dir):
    """Analyze and visualize the impact of different enhancement methods"""
    set_plot_style()
    results_df = clean_dataframe(results_df)

    metrics = ['PSNR', 'SSIM', 'Sharpness']
    if 'BRISQUE' in results_df.columns:
        metrics.append('BRISQUE')

    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    axes = axes.flatten()

    for idx, metric in enumerate(metrics):
        ax = axes[idx]
        methods = results_df['Method'].unique()
        data = []
        valid_methods = []

        for m in methods:
            m_data = results_df[results_df['Method'] == m][metric].dropna().values
            if len(m_data) > 0:
                data.append(m_data)
                valid_methods.append(m)

        if data:
            bp = ax.boxplot(data, labels=valid_methods, patch_artist=True, showmeans=True)
            colors = plt.cm.Set3(np.linspace(0, 1, len(valid_methods)))
            for patch, color in zip(bp['boxes'], colors):
                patch.set_facecolor(color)
                patch.set_alpha(0.7)

            means = results_df.groupby('Method')[metric].mean().sort_values(
                ascending=False if metric != 'BRISQUE' else True)
            for i, (method, mean_val) in enumerate(means.items()):
                if i < 3 and method in valid_methods:
                    pos = valid_methods.index(method) + 1
                    ax.text(pos, mean_val, f'★{mean_val:.2f}', ha='center', va='bottom', fontsize=10, fontweight='bold')

        ax.set_title(f'{metric} Distribution by Method\n' +
                     ('(Lower is Better)' if metric == 'BRISQUE' else '(Higher is Better)'),
                     weight='bold', fontsize=14)
        ax.set_ylabel(metric, fontsize=12)
        ax.tick_params(axis='x', rotation=45, labelsize=9)
        ax.tick_params(labelsize=10)
        ax.grid(True, alpha=0.3, axis='y')

        if metric == 'PSNR':
            ax.set_ylim(10, 50)
        elif metric == 'SSIM':
            ax.set_ylim(0, 1.05)
        elif metric == 'BRISQUE':
            ax.set_ylim(0, 100)
            ax.axhline(y=30, color='g', linestyle='--', alpha=0.5, linewidth=2, label='Good')
            ax.axhline(y=50, color='orange', linestyle='--', alpha=0.5, linewidth=2, label='Poor')
            ax.legend(fontsize=10)

    plt.suptitle('METHOD IMPACT ANALYSIS\nComparative Performance of Enhancement Techniques',
                 fontsize=16, weight='bold', y=1.02)
    plt.tight_layout()
    plt.savefig(os.path.join(report_dir, 'METHOD_IMPACT_ANALYSIS.png'), bbox_inches='tight', dpi=300)
    plt.close()

    # ANOVA test
    anova_results = []
    for metric in metrics:
        groups = []
        for m in results_df['Method'].unique():
            m_data = results_df[results_df['Method'] == m][metric].dropna().values
            if len(m_data) > 0:
                groups.append(m_data)

        if len(groups) >= 2:
            try:
                f_stat, p_value = f_oneway(*groups)
                anova_results.append({
                    'Metric': metric,
                    'F-statistic': f_stat,
                    'p-value': p_value,
                    'Significant': p_value < 0.05
                })
            except:
                anova_results.append({'Metric': metric, 'F-statistic': 0, 'p-value': 1, 'Significant': False})

    anova_df = pd.DataFrame(anova_results)
    anova_df.to_csv(os.path.join(report_dir, 'anova_analysis.csv'), index=False)
    return anova_df


# =============================================
# SIZE IMPACT ANALYSIS
# =============================================
def size_impact_analysis(results_df, report_dir):
    """Analyze how image resizing affects all metrics"""
    set_plot_style()
    results_df = clean_dataframe(results_df)

    metrics = ['PSNR', 'SSIM', 'Sharpness', 'Contrast']
    if 'BRISQUE' in results_df.columns:
        metrics.append('BRISQUE')

    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    axes = axes.flatten()

    for idx, metric in enumerate(metrics):
        ax = axes[idx]
        size_stats = results_df.groupby('Size_Factor')[metric].agg(['mean', 'std']).reset_index()
        size_stats = size_stats.dropna()

        if len(size_stats) > 0:
            ax.errorbar(size_stats['Size_Factor'], size_stats['mean'],
                        yerr=size_stats['std'], capsize=5, marker='o',
                        linewidth=2.5, markersize=8, color='steelblue', ecolor='gray')

            clean_data = results_df[['Size_Factor', metric]].dropna()
            if len(clean_data) > 2:
                corr, p_val = pearsonr(clean_data['Size_Factor'], clean_data[metric])
                z = np.polyfit(clean_data['Size_Factor'], clean_data[metric], 1)
                p = np.poly1d(z)
                x_trend = np.array([0.2, 1.0])
                ax.plot(x_trend, p(x_trend), "r--", linewidth=2.5, label=f'Trend (r={corr:.3f})')

            original_mean = size_stats[size_stats['Size_Factor'] == 1.0]['mean'].values[0] if 1.0 in size_stats[
                'Size_Factor'].values else size_stats['mean'].iloc[0]
            smallest_mean = size_stats[size_stats['Size_Factor'] == 0.25]['mean'].values[0] if 0.25 in size_stats[
                'Size_Factor'].values else size_stats['mean'].iloc[-1]
            change_pct = ((smallest_mean - original_mean) / original_mean) * 100 if original_mean != 0 else 0

            ax.set_xlabel('Resize Factor (1.0 = Original)', fontsize=12)
            ax.set_ylabel(metric, fontsize=12)

            if metric == 'PSNR':
                ax.set_title(f'{metric} vs Size\n{change_pct:+.1f}% change at 25%', weight='bold', fontsize=14)
                ax.set_ylim(10, 50)
            elif metric == 'SSIM':
                ax.set_title(f'{metric} vs Size\n{change_pct:+.1f}% change at 25%', weight='bold', fontsize=14)
                ax.set_ylim(0, 1.05)
            elif metric == 'BRISQUE':
                ax.set_title(f'{metric} vs Size\n{change_pct:+.1f}% degradation at 25%', weight='bold', fontsize=14)
                ax.set_ylim(0, 100)
                ax.axhline(y=30, color='g', linestyle=':', alpha=0.5, linewidth=2)
                ax.axhline(y=50, color='orange', linestyle=':', alpha=0.5, linewidth=2)
            else:
                ax.set_title(f'{metric} vs Size\n{change_pct:+.1f}% change at 25%', weight='bold', fontsize=14)

            ax.grid(True, alpha=0.3)
            ax.legend(fontsize=10)
            ax.tick_params(labelsize=10)

    if len(metrics) < 6:
        axes[-1].set_visible(False)

    plt.suptitle('IMAGE RESIZING IMPACT ANALYSIS\nHow Resolution Affects Quality Metrics',
                 fontsize=16, weight='bold', y=1.02)
    plt.tight_layout()
    plt.savefig(os.path.join(report_dir, 'SIZE_IMPACT_ANALYSIS.png'), bbox_inches='tight', dpi=300)
    plt.close()

    size_summary = results_df.groupby('Size_Factor')[metrics].agg(['mean', 'std']).round(3)
    size_summary.to_csv(os.path.join(report_dir, 'size_impact_summary.csv'))
    return size_summary


# =============================================
# COMPREHENSIVE RESULTS TABLE
# =============================================
def create_results_table(results_df, report_dir):
    """
    Create a comprehensive results table with all metrics averaged by method
    Includes ranking and performance summaries
    """
    print("\n📊 Creating comprehensive results table...")

    # Define metrics to include
    metrics = ['PSNR', 'SSIM', 'Sharpness', 'Contrast', 'Entropy']
    if 'BRISQUE' in results_df.columns:
        metrics.append('BRISQUE')

    # Calculate mean values for each method (averaged across all sizes)
    method_means = results_df.groupby('Method')[metrics].mean().round(3)

    # Calculate rankings for each metric
    ranking_data = {}
    for metric in metrics:
        if metric == 'BRISQUE':
            # Lower BRISQUE is better
            ranking_data[f'{metric}_Rank'] = method_means[metric].rank(ascending=True).astype(int)
        else:
            # Higher is better for other metrics
            ranking_data[f'{metric}_Rank'] = method_means[metric].rank(ascending=False).astype(int)

    ranking_df = pd.DataFrame(ranking_data)

    # Calculate overall rank (sum of individual ranks)
    rank_cols = [f'{m}_Rank' for m in metrics]
    ranking_df['Overall_Rank_Score'] = ranking_df[rank_cols].sum(axis=1)
    ranking_df['Overall_Rank'] = ranking_df['Overall_Rank_Score'].rank().astype(int)

    # Combine means and rankings
    final_table = method_means.copy()
    for metric in metrics:
        final_table[f'{metric}_Rank'] = ranking_df[f'{metric}_Rank']

    final_table['Overall_Rank'] = ranking_df['Overall_Rank']
    final_table = final_table.sort_values('Overall_Rank')

    # Add performance interpretation
    def get_performance_level(row):
        if row['Overall_Rank'] <= 3:
            return 'Excellent ★★★'
        elif row['Overall_Rank'] <= 6:
            return 'Good ★★'
        elif row['Overall_Rank'] <= 9:
            return 'Average ★'
        else:
            return 'Poor'

    final_table['Performance_Level'] = final_table.apply(get_performance_level, axis=1)

    # Save to CSV
    final_table.to_csv(os.path.join(report_dir, 'COMPREHENSIVE_RESULTS_TABLE.csv'))

    # Create formatted table for text output
    with open(os.path.join(report_dir, 'RESULTS_TABLE.txt'), 'w', encoding='utf-8') as f:
        f.write("=" * 120 + "\n")
        f.write("COMPREHENSIVE RESULTS TABLE: METHOD PERFORMANCE SUMMARY\n")
        f.write("=" * 120 + "\n\n")

        # Header
        f.write(f"{'Method':<20} ")
        for metric in metrics:
            f.write(f"{metric:<12} ")
        f.write(f"{'Rank':<6} ")
        f.write(f"{'Level':<15}\n")
        f.write("-" * 120 + "\n")

        # Data rows
        for method in final_table.index:
            f.write(f"{method:<20} ")
            for metric in metrics:
                f.write(f"{final_table.loc[method, metric]:<12.3f} ")
            f.write(f"{final_table.loc[method, 'Overall_Rank']:<6} ")
            f.write(f"{final_table.loc[method, 'Performance_Level']:<15}\n")

        f.write("\n" + "=" * 120 + "\n")
        f.write("INTERPRETATION GUIDE:\n")
        f.write("-" * 120 + "\n")
        f.write("• PSNR (dB): Higher is better | Excellent: >40, Good: 30-40, Poor: <30\n")
        f.write("• SSIM: Higher is better | Excellent: >0.95, Good: 0.9-0.95, Poor: <0.9\n")
        if 'BRISQUE' in results_df.columns:
            f.write("• BRISQUE: Lower is better | Excellent: <30, Good: 30-50, Poor: >50\n")
        f.write("• Sharpness: Higher indicates clearer edges and better detail preservation\n")
        f.write("• Contrast: Higher indicates better dynamic range\n")
        f.write("• Entropy: Higher indicates more information content\n")
        f.write("\nPERFORMANCE LEVELS:\n")
        f.write("• Excellent ★★★ : Top 3 performing methods\n")
        f.write("• Good ★★ : Rank 4-6\n")
        f.write("• Average ★ : Rank 7-9\n")
        f.write("• Poor : Rank 10+\n")
        f.write("=" * 120 + "\n")

    # Create a LaTeX table for paper inclusion
    with open(os.path.join(report_dir, 'RESULTS_TABLE_LATEX.txt'), 'w', encoding='utf-8') as f:
        f.write("% LaTeX Table - Copy this into your paper\n")
        f.write("% ==========================================\n\n")
        f.write("\\begin{table}[htbp]\n")
        f.write("\\centering\n")
        f.write("\\caption{Performance Comparison of Image Enhancement Methods}\n")
        f.write("\\label{tab:results}\n")
        f.write("\\begin{tabular}{l" + "c" * len(metrics) + "c}\n")
        f.write("\\hline\n")
        f.write("\\textbf{Method} & ")
        for metric in metrics:
            f.write(f"\\textbf{{{metric}}} ")
            if metric != metrics[-1]:
                f.write("& ")
        f.write("& \\textbf{Rank} \\\\\n")
        f.write("\\hline\n")

        for method in final_table.index:
            f.write(f"{method} & ")
            for metric in metrics:
                f.write(f"{final_table.loc[method, metric]:.3f} ")
                if metric != metrics[-1]:
                    f.write("& ")
            f.write(f"& {final_table.loc[method, 'Overall_Rank']} \\\\\n")

        f.write("\\hline\n")
        f.write("\\end{tabular}\n")
        f.write("\\end{table}\n")

    print(f"   ✅ Results table saved to {report_dir}")
    print(f"   📊 Top 3 Methods:")
    for i, method in enumerate(final_table.head(3).index, 1):
        print(f"      {i}. {method} (Overall Rank: {final_table.loc[method, 'Overall_Rank']})")

    return final_table


# =============================================
# MAIN PROCESSING PIPELINE
# =============================================
def process_images():
    """Process all images and calculate metrics"""
    results = []
    image_files = [f for f in os.listdir(INPUT_DIR) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]

    print(f"\n📸 Found {len(image_files)} images to process")
    print(f"🔧 Applying {len(ENHANCEMENTS)} enhancement methods")
    print(f"📏 Testing {len(RESIZE_FACTORS)} different sizes\n")

    for img_file in tqdm(image_files, desc="Processing images"):
        img_path = os.path.join(INPUT_DIR, img_file)
        gt_path = os.path.join(GT_DIR, img_file)

        if not os.path.exists(gt_path):
            continue

        orig_img = cv2.imread(img_path)
        orig_gt = cv2.imread(gt_path)

        if orig_img is None or orig_gt is None:
            continue

        for factor in RESIZE_FACTORS:
            if factor == 1.0:
                img, gt = orig_img.copy(), orig_gt.copy()
            else:
                h, w = orig_img.shape[:2]
                img = cv2.resize(orig_img, (int(w * factor), int(h * factor)), cv2.INTER_AREA)
                gt = cv2.resize(orig_gt, (int(w * factor), int(h * factor)), cv2.INTER_AREA)

            for method, func in ENHANCEMENTS.items():
                try:
                    enhanced = func(img.copy())
                    metrics = calculate_metrics(enhanced, gt)
                    if metrics:
                        results.append({
                            'Image': img_file,
                            'Method': method,
                            'Size_Factor': factor,
                            **metrics
                        })
                except Exception as e:
                    continue

    return pd.DataFrame(results)


# =============================================
# FINAL REPORT GENERATION
# =============================================
def generate_final_report(results_df, report_dir):
    """Generate all analysis and create final report"""

    print("\n" + "=" * 70)
    print("GENERATING COMPREHENSIVE ANALYSIS REPORT")
    print("=" * 70)

    os.makedirs(report_dir, exist_ok=True)

    print("\n🧹 Cleaning data...")
    results_df = clean_dataframe(results_df)

    print("\n📊 1. Creating Master Dashboard (All Metrics in One Diagram)...")
    create_master_dashboard(results_df, report_dir)

    print("\n🔬 2. Performing Comprehensive Correlation Analysis...")
    pearson_corr, spearman_corr = comprehensive_correlation_analysis(results_df, report_dir)

    print("\n📈 3. Analyzing Method Impact...")
    anova_results = method_impact_analysis(results_df, report_dir)

    print("\n📏 4. Analyzing Size Impact...")
    size_summary = size_impact_analysis(results_df, report_dir)

    print("\n📋 5. Creating Results Table...")
    results_table = create_results_table(results_df, report_dir)

    print("\n💾 6. Saving Complete Results...")
    results_df.to_csv(os.path.join(report_dir, 'complete_analysis_results.csv'), index=False)

    print("\n📝 7. Generating Statistical Summary...")
    generate_statistical_summary(results_df, pearson_corr, anova_results, results_table, report_dir)

    print("\n✅ Report generation complete!")
    return results_df


def generate_statistical_summary(results_df, pearson_corr, anova_results, results_table, report_dir):
    """Create comprehensive statistical summary with results table"""

    with open(os.path.join(report_dir, 'FINAL_STATISTICAL_SUMMARY.txt'), 'w', encoding='utf-8') as f:
        f.write("=" * 100 + "\n")
        f.write("FINAL STATISTICAL ANALYSIS SUMMARY\n")
        f.write("Image Enhancement Evaluation with BRISQUE\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("=" * 100 + "\n\n")

        # Dataset Overview
        f.write("1. DATASET OVERVIEW\n")
        f.write("-" * 50 + "\n")
        f.write(f"   Total Images: {results_df['Image'].nunique()}\n")
        f.write(f"   Enhancement Methods: {results_df['Method'].nunique()}\n")
        f.write(f"   Resize Factors: {results_df['Size_Factor'].nunique()}\n")
        f.write(f"   Total Observations: {len(results_df)}\n\n")

        # Results Table Summary
        f.write("2. TOP PERFORMING METHODS\n")
        f.write("-" * 50 + "\n")
        f.write("\n   Top 3 Methods:\n")
        for i, method in enumerate(results_table.head(3).index, 1):
            f.write(f"      {i}. {method}\n")
            f.write(f"         - PSNR: {results_table.loc[method, 'PSNR']:.2f} dB\n")
            f.write(f"         - SSIM: {results_table.loc[method, 'SSIM']:.3f}\n")
            if 'BRISQUE' in results_table.columns:
                f.write(f"         - BRISQUE: {results_table.loc[method, 'BRISQUE']:.1f}\n")
            f.write(f"         - Overall Rank: {results_table.loc[method, 'Overall_Rank']}\n")

        # Descriptive Statistics
        f.write("\n\n3. DESCRIPTIVE STATISTICS\n")
        f.write("-" * 50 + "\n")
        metrics = ['PSNR', 'SSIM', 'Sharpness', 'Contrast', 'Entropy', 'MSE']
        if 'BRISQUE' in results_df.columns:
            metrics.append('BRISQUE')

        for metric in metrics:
            if metric in results_df.columns:
                f.write(f"\n   {metric}:\n")
                f.write(f"      Mean: {results_df[metric].mean():.3f}\n")
                f.write(f"      Std:  {results_df[metric].std():.3f}\n")
                f.write(f"      Min:  {results_df[metric].min():.3f}\n")
                f.write(f"      Max:  {results_df[metric].max():.3f}\n")

        # Correlation Analysis
        f.write("\n\n4. KEY CORRELATIONS\n")
        f.write("-" * 50 + "\n")
        corr_pairs = []
        for i in range(len(pearson_corr.index)):
            for j in range(i + 1, len(pearson_corr.columns)):
                if not np.isnan(pearson_corr.iloc[i, j]):
                    corr_pairs.append({
                        'pair': f"{pearson_corr.index[i]} vs {pearson_corr.columns[j]}",
                        'correlation': pearson_corr.iloc[i, j]
                    })
        corr_pairs.sort(key=lambda x: abs(x['correlation']), reverse=True)

        f.write("\n   Top 3 Strongest Correlations:\n")
        for i, pair in enumerate(corr_pairs[:3], 1):
            f.write(f"      {i}. {pair['pair']}: r = {pair['correlation']:.3f}\n")

        # ANOVA Results
        f.write("\n\n5. STATISTICAL SIGNIFICANCE (ANOVA)\n")
        f.write("-" * 50 + "\n")
        for _, row in anova_results.iterrows():
            significance = "✓ SIGNIFICANT" if row['Significant'] else "✗ Not significant"
            f.write(f"\n   {row['Metric']}: F={row['F-statistic']:.2f}, p={row['p-value']:.4f} ({significance})\n")

        # Size Impact
        f.write("\n\n6. RESIZING IMPACT\n")
        f.write("-" * 50 + "\n")
        size_summary = results_df.groupby('Size_Factor')[['PSNR', 'SSIM']].mean()
        for size in size_summary.index:
            f.write(f"\n   {int(size * 100)}% Size:\n")
            f.write(f"      PSNR: {size_summary.loc[size, 'PSNR']:.2f} dB\n")
            f.write(f"      SSIM: {size_summary.loc[size, 'SSIM']:.3f}\n")

        if 'BRISQUE' in results_df.columns:
            brisque_by_size = results_df.groupby('Size_Factor')['BRISQUE'].mean()
            f.write(f"\n   BRISQUE Quality:\n")
            for size in brisque_by_size.index:
                quality = 'Poor' if brisque_by_size.loc[size] > 50 else 'Good' if brisque_by_size.loc[
                                                                                      size] < 30 else 'Medium'
                f.write(f"      {int(size * 100)}%: {brisque_by_size.loc[size]:.1f} ({quality})\n")

        # Key Insights
        f.write("\n\n7. KEY INSIGHTS & RECOMMENDATIONS\n")
        f.write("-" * 50 + "\n")

        best_method = results_table.head(1).index[0]
        f.write(f"\n   • Best Overall Method: {best_method}\n")

        if 'BRISQUE' in results_df.columns:
            best_brisque = results_df[results_df['Size_Factor'] == 1.0].groupby('Method')['BRISQUE'].mean().idxmin()
            f.write(f"   • Best Perceptual Quality: {best_brisque}\n")

        # Method with highest PSNR
        best_psnr = results_df[results_df['Size_Factor'] == 1.0].groupby('Method')['PSNR'].mean().idxmax()
        f.write(f"   • Best Reconstruction Quality (PSNR): {best_psnr}\n")

        f.write("\n" + "=" * 100 + "\n")
        f.write("END OF REPORT\n")
        f.write("=" * 100 + "\n")


# =============================================
# MAIN EXECUTION
# =============================================
if __name__ == "__main__":
    print("=" * 80)
    print("PROFESSIONAL IMAGE ENHANCEMENT ANALYSIS SYSTEM")
    print("Comprehensive Quality Assessment with BRISQUE")
    print("=" * 80)

    if not PIQ_AVAILABLE:
        print("\n⚠️  BRISQUE not available. Running with PSNR, SSIM, and other metrics only.")
        print("   Install with: pip install piq torch torchvision pillow\n")
    else:
        print("\n✅ BRISQUE enabled - No-reference perceptual quality assessment active\n")

    print("🖼️  Starting image processing pipeline...")
    results_df = process_images()

    if len(results_df) == 0:
        print("\n❌ ERROR: No results generated. Please check:")
        print("   - Input directory contains images")
        print("   - Ground truth directory contains matching images")
        print("   - Images can be read by OpenCV")
        exit()

    print(f"\n✅ Successfully processed {len(results_df)} combinations")

    report_dir = os.path.join(OUTPUT_DIR, 'FINAL_ANALYSIS_REPORT')
    final_results = generate_final_report(results_df, report_dir)

    print("\n" + "=" * 80)
    print("🎉 ANALYSIS COMPLETE!")
    print("=" * 80)
    print(f"\n📁 All results saved to: {report_dir}")
    print("\n📊 Generated Analysis Files:")
    print("   ⭐ MASTER_DASHBOARD.png - All metrics in one comprehensive diagram")
    print("   ⭐ COMPREHENSIVE_CORRELATION.png - Full correlation analysis")
    print("   ⭐ METHOD_IMPACT_ANALYSIS.png - Method comparison with statistics")
    print("   ⭐ SIZE_IMPACT_ANALYSIS.png - Resolution effect analysis")
    print("   ⭐ COMPREHENSIVE_RESULTS_TABLE.csv - Method performance table")
    print("   ⭐ RESULTS_TABLE.txt - Formatted results with rankings")
    print("   ⭐ RESULTS_TABLE_LATEX.txt - LaTeX table for papers")
    print("   ⭐ FINAL_STATISTICAL_SUMMARY.txt - Complete numerical results")
    print("   ⭐ complete_analysis_results.csv - Raw data for further analysis")

    if PIQ_AVAILABLE:
        print("\n🎯 BRISQUE Analysis Included:")
        print("   ✓ No-reference perceptual quality scores")
        print("   ✓ Quality classification (Excellent/Good/Poor)")
        print("   ✓ Correlation with PSNR and SSIM")

    print("\n" + "=" * 80)
    print("✅ SYSTEM READY - Analysis Complete")
    print("=" * 80)