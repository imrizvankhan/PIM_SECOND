# We used matlab to calcualte metrics - As no - ref original models are in Matlab:
# import os
# import cv2
# import time
# import numpy as np
# import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn as sns
# from matplotlib.ticker import FuncFormatter
#
# # ============================
# # CONFIGURATION
# # ============================
# INPUT_ROOT = r"C:\Users\imriz\OneDrive\Desktop\AIR_R2\eval15_resized\low"
# OUTPUT_ROOT = r"C:\Users\imriz\OneDrive\Desktop\AIR_R2\eval15_enhanced_low"
# os.makedirs(OUTPUT_ROOT, exist_ok=True)
#
# IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff")
# SCALES = ["scale_1.0", "scale_0.75", "scale_0.5", "scale_0.25"]
# SCALE_LABELS = {"scale_1.0": "100%", "scale_0.75": "75%", "scale_0.5": "50%", "scale_0.25": "25%"}
#
# # ============================
# # ENHANCEMENT METHODS (11 methods)
# # ============================
# def hist_eq(img):
#     return cv2.equalizeHist(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))
#
# def clahe(img):
#     lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
#     l, a, b = cv2.split(lab)
#     l = cv2.createCLAHE(2.0, (8 ,8)).apply(l)
#     return cv2.cvtColor(cv2.merge([l, a, b]), cv2.COLOR_LAB2BGR)
#
# def gamma(img):
#     inv_gamma = 1. 0 /1.2
#     table = np.array([(( i /255.0 )* *inv_gamma ) *255 for i in range(256)]).astype(np.uint8)
#     return cv2.LUT(img, table)
#
# def contrast(img):
#     return cv2.convertScaleAbs(img, alpha=1.3, beta=10)
#
# def unsharp(img):
#     blur = cv2.GaussianBlur(img, (5 ,5), 1)
#     return cv2.addWeighted(img, 1.5, blur, -0.5, 0)
#
# def bilateral(img):
#     return cv2.bilateralFilter(img, 9, 75, 75)
#
# def edge(img):
#     return cv2.Canny(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), 100, 200)
#
# def log_transform(img):
#     img_float = img.astype(np.float32)
#     c = 255 / np.log(1 + np.max(img_float))
#     return (c * np.log(1 + img_float)).astype(np.uint8)
#
# def box_blur(img):
#     return cv2.blur(img, (5 ,5))
#
# def denoise(img):
#     return cv2.fastNlMeansDenoisingColored(img, None, 10, 10, 7, 21)
#
# def hls_equalize(img):
#     hls = cv2.cvtColor(img, cv2.COLOR_BGR2HLS)
#     h, l, s = cv2.split(hls)
#     l = cv2.equalizeHist(l)
#     return cv2.cvtColor(cv2.merge([h, l, s]), cv2.COLOR_HLS2BGR)
#
# METHODS = {
#     "hist_eq": hist_eq,
#     "clahe": clahe,
#     "gamma": gamma,
#     "contrast": contrast,
#     "unsharp": unsharp,
#     "bilateral": bilateral,
#     "edge": edge,
#     "log": log_transform,
#     "box": box_blur,
#     "denoise": denoise,
#     "hls": hls_equalize
# }
#
# # Color mapping for methods
# METHOD_COLORS = {
#     "hist_eq": "#1f77b4", "clahe": "#ff7f0e", "gamma": "#2ca02c",
#     "contrast": "#d62728", "unsharp": "#9467bd", "bilateral": "#8c564b",
#     "edge": "#e377c2", "log": "#7f7f7f", "box": "#bcbd22",
#     "denoise": "#17becf", "hls": "#ff6f91"
# }
#
# # ============================
# # PROCESS & TIME
# # ============================
# all_records = []
#
# print("\n" + "= " *70)
# print("PROCESSING IMAGES WITH TIME TRACKING")
# print("= " *70)
#
# for scale in SCALES:
#     scale_path = os.path.join(INPUT_ROOT, scale)
#     if not os.path.exists(scale_path):
#         print(f"⚠️  Skipping {scale} - path not found")
#         continue
#
#     images = [f for f in os.listdir(scale_path) if f.lower().endswith(IMAGE_EXTS)]
#     print(f"\n📁 {SCALE_LABELS[scale]} Scale: {len(images)} images")
#
#     for img_name in images:
#         img_path = os.path.join(scale_path, img_name)
#         img = cv2.imread(img_path)
#
#         if img is None:
#             print(f"  ❌ Failed: {img_name}")
#             continue
#
#         # Process each method and time
#         for method_name, method_func in METHODS.items():
#             # Warm-up run (to stabilize)
#             _ = method_func(img)
#
#             # Actual timing (3 runs for accuracy)
#             times = []
#             for _ in range(3):
#                 start = time.perf_counter()
#                 _ = method_func(img)
#                 elapsed_ms = (time.perf_counter() - start) * 1000
#                 times.append(elapsed_ms)
#
#             # Use median time for stability
#             final_time = np.median(times)
#
#             all_records.append({
#                 "scale": scale,
#                 "scale_label": SCALE_LABELS[scale],
#                 "image": img_name,
#                 "method": method_name,
#                 "time_ms": final_time,
#                 "time_min": min(times),
#                 "time_max": max(times)
#             })
#
#         print(f"  ✅ {img_name}")
#
# print(f"\n✅ Total measurements: {len(all_records)}")
#
# # ============================
# # CREATE DATAFRAME
# # ============================
# df = pd.DataFrame(all_records)
#
# # ============================
# # SAVE REPORTS
# # ============================
# report_dir = os.path.join(OUTPUT_ROOT, "reports")
# os.makedirs(report_dir, exist_ok=True)
#
# # 1. RAW DATA
# df.to_csv(os.path.join(report_dir, "timing_data.csv"), index=False)
# print(f"\n📊 Raw data saved")
#
# # 2. PER-IMAGE DETAILED REPORT (TEXT)
# for scale in SCALES:
#     scale_df = df[df["scale"] == scale]
#     if len(scale_df) == 0:
#         continue
#
#     report_file = os.path.join(report_dir, f"per_image_{scale}.txt")
#     with open(report_file, 'w') as f:
#         f.write(f"{'= ' *100}\n")
#         f.write(f"PER-IMAGE PROCESSING TIME - {SCALE_LABELS[scale]} SCALE\n")
#         f.write(f"{'= ' *100}\n\n")
#
#         # Header with all methods
#         f.write(f"{'Image':<35}")
#         for method in METHODS.keys():
#             f.write(f"{method[:10]:>12}")
#         f.write(f"{'TOTAL':>10}\n")
#         f.write("- " *100 + "\n")
#
#         # Per image data
#         for img in sorted(scale_df["image"].unique()):
#             img_data = scale_df[scale_df["image"] == img]
#             f.write(f"{img:<35}")
#
#             total = 0
#             for method in METHODS.keys():
#                 time_val = img_data[img_data["method"] == method]["time_ms"].values
#                 if len(time_val) > 0:
#                     f.write(f"{time_val[0]:>12.3f}")
#                     total += time_val[0]
#                 else:
#                     f.write(f"{'N/A':>12}")
#             f.write(f"{total:>10.3f}\n")
#
#         # Method statistics
#         f.write("\n" + "= " *100 + "\n")
#         f.write("METHOD STATISTICS (ms)\n")
#         f.write("= " *100 + "\n\n")
#
#         f.write(f"{'Method':<20} {'Mean':>12} {'Std':>12} {'Min':>12} {'Max':>12} {'Median':>12}\n")
#         f.write("- " *100 + "\n")
#
#         for method in METHODS.keys():
#             method_data = scale_df[scale_df["method"] == method]
#             if len(method_data) > 0:
#                 mean_val = method_data["time_ms"].mean()
#                 std_val = method_data["time_ms"].std()
#                 min_val = method_data["time_ms"].min()
#                 max_val = method_data["time_ms"].max()
#                 med_val = method_data["time_ms"].median()
#                 f.write \
#                     (f"{method:<20} {mean_val:>12.3f} {std_val:>12.3f} {min_val:>12.3f} {max_val:>12.3f} {med_val:>12.3f}\n")
#
#         # Overall statistics
#         total_per_image = scale_df.groupby("image")["time_ms"].sum()
#         f.write("\n" + "= " *100 + "\n")
#         f.write("OVERALL STATISTICS (Total time per image)\n")
#         f.write("= " *100 + "\n")
#         f.write(f"  Mean total time:    {total_per_image.mean():.3f} ms\n")
#         f.write(f"  Std deviation:      {total_per_image.std():.3f} ms\n")
#         f.write(f"  Min total time:     {total_per_image.min():.3f} ms\n")
#         f.write(f"  Max total time:     {total_per_image.max():.3f} ms\n")
#         f.write(f"  Median total time:  {total_per_image.median():.3f} ms\n")
#
#         # Fastest and slowest methods
#         method_means = scale_df.groupby("method")["time_ms"].mean()
#         f.write(f"\n  Fastest method:     {method_means.idxmin()} ({method_means.min():.3f} ms)\n")
#         f.write(f"  Slowest method:     {method_means.idxmax()} ({method_means.max():.3f} ms)\n")
#
#     print(f"📄 Report saved: {report_file}")
#
# # 3. AGGREGATED CSV REPORTS
# summary_df = df.groupby(["scale_label", "method"])["time_ms"].agg(["mean", "std", "min", "max", "median"]).reset_index()
# summary_df.to_csv(os.path.join(report_dir, "method_summary.csv"), index=False)
#
# scale_summary = df.groupby("scale_label")["time_ms"].agg(["mean", "std", "min", "max", "median"]).reset_index()
# scale_summary.to_csv(os.path.join(report_dir, "scale_summary.csv"), index=False)
#
# print(f"📊 Method summary saved")
# print(f"📊 Scale summary saved")
#
# # ============================
# # GENERATE PLOTS (With improved visibility)
# # ============================
# plot_dir = os.path.join(OUTPUT_ROOT, "plots")
# os.makedirs(plot_dir, exist_ok=True)
#
# # Set style
# plt.style.use('seaborn-v0_8-darkgrid')
# sns.set_palette("husl")
#
# # ============================================
# # PLOT 1: PER-IMAGE WITH LOGARITHMIC SCALE
# # ============================================
# for scale in SCALES:
#     scale_df = df[df["scale"] == scale]
#     if len(scale_df) == 0:
#         continue
#
#     # Create figure with two subplots
#     fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(18, 8))
#
#     # Get data for each image
#     images = sorted(scale_df["image"].unique())
#     methods = list(METHODS.keys())
#
#     # Prepare data for plotting
#     x_positions = np.arange(len(images))
#     width = 0.08  # Narrow width for 11 methods
#     colors = [METHOD_COLORS[m] for m in methods]
#
#     # Plot 1: Linear scale (shows slow methods clearly)
#     for i, method in enumerate(methods):
#         times = []
#         for img in images:
#             val = scale_df[(scale_df["image"] == img) & (scale_df["method"] == method)]["time_ms"].values
#             times.append(val[0] if len(val) > 0 else 0)
#
#         offset = (i - len(methods ) /2) * width + widt h /2
#         ax1.bar(x_positions + offset, times, width, label=method, color=colors[i],
#                 edgecolor='black', linewidth=0.3, alpha=0.8)
#
#     ax1.set_xlabel("Image Name", fontsize=12, fontweight='bold')
#     ax1.set_ylabel("Processing Time (ms)", fontsize=12, fontweight='bold')
#     ax1.set_title(f"{SCALE_LABELS[scale]} - Linear Scale", fontsize=14, fontweight='bold')
#     ax1.set_xticks(x_positions)
#     ax1.set_xticklabels(images, rotation=45, ha='right', fontsize=8)
#     ax1.legend(loc='upper left', bbox_to_anchor=(1, 1), fontsize=8)
#     ax1.grid(True, alpha=0.3, axis='y')
#
#     # Plot 2: Logarithmic scale (shows fast methods clearly)
#     for i, method in enumerate(methods):
#         times = []
#         for img in images:
#             val = scale_df[(scale_df["image"] == img) & (scale_df["method"] == method)]["time_ms"].values
#             times.append(max(val[0], 0.001) if len(val) > 0 else 0.001)  # Avoid log(0)
#
#         offset = (i - len(methods ) /2) * width + widt h /2
#         ax2.bar(x_positions + offset, times, width, label=method, color=colors[i],
#                 edgecolor='black', linewidth=0.3, alpha=0.8)
#
#     ax2.set_xlabel("Image Name", fontsize=12, fontweight='bold')
#     ax2.set_ylabel("Processing Time (ms) - Log Scale", fontsize=12, fontweight='bold')
#     ax2.set_title(f"{SCALE_LABELS[scale]} - Logarithmic Scale", fontsize=14, fontweight='bold')
#     ax2.set_xticks(x_positions)
#     ax2.set_xticklabels(images, rotation=45, ha='right', fontsize=8)
#     ax2.set_yscale('log')
#     ax2.legend(loc='upper left', bbox_to_anchor=(1, 1), fontsize=8)
#     ax2.grid(True, alpha=0.3, which='both')
#
#     plt.suptitle(f"Per-Image Processing Time - {SCALE_LABELS[scale]} Scale",
#                  fontsize=16, fontweight='bold', y=1.02)
#     plt.tight_layout()
#     plt.savefig(os.path.join(plot_dir, f"per_image_{scale}.png"), dpi=300, bbox_inches='tight')
#     plt.close()
#
# # ============================================
# # PLOT 2: GROUPED BAR CHART PER METHOD (4 scales)
# # ============================================
# fig, axes = plt.subplots(2, 2, figsize=(16, 12))
# axes = axes.flatten()
#
# for idx, scale in enumerate(SCALES):
#     scale_df = df[df["scale"] == scale]
#     if len(scale_df) == 0:
#         continue
#
#     # Calculate average time per method
#     method_avg = scale_df.groupby("method")["time_ms"].mean().sort_values(ascending=False)
#     method_std = scale_df.groupby("method")["time_ms"].std()
#
#     # Create color mapping
#     colors = [METHOD_COLORS[m] for m in method_avg.index]
#
#     # Bar chart with error bars
#     bars = axes[idx].bar(method_avg.index, method_avg.values,
#                          color=colors, edgecolor='black', linewidth=0.8,
#                          yerr=method_std[method_avg.index].values,
#                          capsize=3, error_kw={'elinewidth': 1.5, 'ecolor': 'red'})
#
#     # Add value labels
#     for bar in bars:
#         height = bar.get_height()
#         axes[idx].text(bar.get_x() + bar.get_width( ) /2., height + 0.5,
#                        f'{height:.2f}ms', ha='center', va='bottom',
#                        fontsize=8, fontweight='bold')
#
#     axes[idx].set_title(f"{SCALE_LABELS[scale]} Scale", fontsize=13, fontweight='bold')
#     axes[idx].set_ylabel("Average Time (ms)", fontsize=11)
#     axes[idx].set_xlabel("Method", fontsize=11)
#     axes[idx].tick_params(axis='x', rotation=45, labelsize=9)
#     axes[idx].grid(True, alpha=0.3, axis='y')
#
#     # Add stats
#     total_avg = scale_df.groupby("image")["time_ms"].sum().mean()
#     axes[idx].text(0.02, 0.98, f'Avg Total: {total_avg:.1f}ms',
#                    transform=axes[idx].transAxes, verticalalignment='top',
#                    bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))
#
# plt.suptitle("Method Performance Across Different Scales", fontsize=16, fontweight='bold', y=1.02)
# plt.tight_layout()
# plt.savefig(os.path.join(plot_dir, "four_scale_comparison.png"), dpi=300, bbox_inches='tight')
# plt.close()
#
# # ============================================
# # PLOT 3: TOTAL TIME PER IMAGE (with sorting)
# # ============================================
# fig, axes = plt.subplots(2, 2, figsize=(16, 12))
# axes = axes.flatten()
#
# for idx, scale in enumerate(SCALES):
#     scale_df = df[df["scale"] == scale]
#     if len(scale_df) == 0:
#         continue
#
#     total_times = scale_df.groupby("image")["time_ms"].sum().sort_values(ascending=False)
#     colors = plt.cm.plasma(np.linspace(0.2, 0.9, len(total_times)))[::-1]
#
#     bars = axes[idx].bar(range(len(total_times)), total_times.values,
#                          color=colors, edgecolor='black', linewidth=0.5)
#
#     # Add labels for top 5
#     for i, bar in enumerate(bars):
#         height = bar.get_height()
#         if i < 5 or i % 5 == 0:
#             axes[idx].text(bar.get_x() + bar.get_width( ) /2., height + 1,
#                            f'{height:.1f}', ha='center', va='bottom',
#                            fontsize=7, rotation=90)
#
#     axes[idx].set_title(f"{SCALE_LABELS[scale]} - Total Time", fontsize=13, fontweight='bold')
#     axes[idx].set_ylabel("Total Time (ms)", fontsize=11)
#     axes[idx].set_xlabel("Images (sorted)", fontsize=11)
#     axes[idx].set_xticks([])
#     axes[idx].grid(True, alpha=0.3, axis='y')
#
#     # Statistics box
#     mean_t = total_times.mean()
#     std_t = total_times.std()
#     med_t = total_times.median()
#     axes[idx].text(0.02, 0.98, f'Mean: {mean_t:.1f}ms\nStd: {std_t:.1f}ms\nMedian: {med_t:.1f}ms',
#                    transform=axes[idx].transAxes, verticalalignment='top',
#                    bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))
#
# plt.suptitle("Total Processing Time Per Image (All Methods Combined)", fontsize=16, fontweight='bold', y=1.02)
# plt.tight_layout()
# plt.savefig(os.path.join(plot_dir, "total_time_per_image.png"), dpi=300, bbox_inches='tight')
# plt.close()
#
# # ============================================
# # PLOT 4: HEATMAP (Scale vs Method)
# # ============================================
# fig, ax = plt.subplots(figsize=(14, 8))
# heatmap_data = df.groupby(["scale_label", "method"])["time_ms"].mean().unstack()
# heatmap_data = heatmap_data.reindex(METHODS.keys(), axis=1)
#
# sns.heatmap(heatmap_data, annot=True, fmt='.2f', cmap='YlOrRd',
#             linewidths=0.5, linecolor='white', ax=ax,
#             cbar_kws={'label': 'Time (ms)'},
#             annot_kws={'size': 10, 'weight': 'bold'})
#
# ax.set_title("Average Processing Time: Scale vs Method", fontsize=14, fontweight='bold', pad=20)
# ax.set_xlabel("Enhancement Method", fontsize=12, fontweight='bold')
# ax.set_ylabel("Scale", fontsize=12, fontweight='bold')
# plt.xticks(rotation=45, ha='right')
# plt.tight_layout()
# plt.savefig(os.path.join(plot_dir, "heatmap_scale_method.png"), dpi=300, bbox_inches='tight')
# plt.close()
#
# # ============================================
# # PLOT 5: BOXPLOT WITH LOG SCALE
# # ============================================
# fig, ax = plt.subplots(figsize=(16, 8))
#
# # Prepare data for boxplot
# boxplot_data = []
# method_names = []
# for method in METHODS.keys():
#     method_data = df[df["method"] == method]
#     boxplot_data.append(method_data["time_ms"])
#     method_names.append(method)
#
# bp = ax.boxplot(boxplot_data, labels=method_names, patch_artist=True,
#                 showmeans=True, meanline=True, showfliers=False)
#
# # Color boxes
# colors = [METHOD_COLORS[m] for m in method_names]
# for patch, color in zip(bp['boxes'], colors):
#     patch.set_facecolor(color)
#     patch.set_alpha(0.7)
#
# ax.set_ylabel('Processing Time (ms)', fontsize=12, fontweight='bold')
# ax.set_xlabel('Enhancement Method', fontsize=12, fontweight='bold')
# ax.set_title('Time Distribution by Method (Log Scale)', fontsize=14, fontweight='bold')
# ax.set_yscale('log')
# ax.tick_params(axis='x', rotation=45)
# ax.grid(True, alpha=0.3, axis='y')
#
# # Add legend
# from matplotlib.lines import Line2D
# legend_elements = [
#     Line2D([0], [0], color='red', linewidth=2, linestyle='-', label='Mean'),
#     Line2D([0], [0], color='orange', linewidth=2, linestyle='-', label='Median')
# ]
# ax.legend(handles=legend_elements, loc='upper right')
#
# plt.tight_layout()
# plt.savefig(os.path.join(plot_dir, "time_distribution_boxplot.png"), dpi=300, bbox_inches='tight')
# plt.close()
#
# # ============================================
# # PLOT 6: FAST VS SLOW METHODS (Top/Bottom)
# # ============================================
# fig, axes = plt.subplots(1, 2, figsize=(16, 8))
#
# for idx, scale in enumerate([SCALES[0], SCALES[-1]]):  # Only 100% and 25%
#     scale_df = df[df["scale"] == scale]
#     if len(scale_df) == 0:
#         continue
#
#     method_avg = scale_df.groupby("method")["time_ms"].mean().sort_values()
#     colors = ['green' if i < 3 else 'red' if i > len(method_avg ) -4 else 'orange'
#               for i in range(len(method_avg))]
#
#     bars = axes[idx].barh(method_avg.index, method_avg.values, color=colors,
#                           edgecolor='black', linewidth=0.8)
#
#     # Add value labels
#     for bar in bars:
#         width = bar.get_width()
#         axes[idx].text(width + 0.5, bar.get_y() + bar.get_height( ) /2,
#                        f'{width:.2f}ms', va='center', fontsize=9, fontweight='bold')
#
#     axes[idx].set_title(f"{SCALE_LABELS[scale]} - Fastest to Slowest", fontsize=13, fontweight='bold')
#     axes[idx].set_xlabel("Average Time (ms)", fontsize=11)
#     axes[idx].grid(True, alpha=0.3, axis='x')
#     axes[idx].set_xlim(0, method_avg.max() * 1.15)
#
# plt.suptitle("Method Speed Ranking", fontsize=16, fontweight='bold', y=1.02)
# plt.tight_layout()
# plt.savefig(os.path.join(plot_dir, "method_speed_ranking.png"), dpi=300, bbox_inches='tight')
# plt.close()
#
# print(f"\n🖼️  Plots saved to: {plot_dir}")
#
# # ============================
# # CONSOLE QUICK STATS
# # ============================
# print("\n" + "= " *70)
# print("QUICK STATISTICS")
# print("= " *70)
#
# for scale in SCALES:
#     scale_df = df[df["scale"] == scale]
#     if len(scale_df) > 0:
#         total_per_img = scale_df.groupby("image")["time_ms"].sum()
#         method_means = scale_df.groupby("method")["time_ms"].mean()
#
#         print(f"\n📊 {SCALE_LABELS[scale]}:")
#         print(f"  Avg total per image: {total_per_img.mean():.2f} ms")
#         print(f"  Fastest method: {method_means.idxmin()} ({method_means.min():.3f} ms)")
#         print(f"  Slowest method: {method_means.idxmax()} ({method_means.max():.3f} ms)")
#         print(f"  Speed ratio: {method_means.max( ) /method_means.min():.1f}x")
#
# print("\n" + "= " *70)
# print("✅ ALL DONE!")
# print("= " *70)







import os
import cv2
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# =========================================================
# CONFIG
# =========================================================
INPUT_ROOT = r"C:\Users\imriz\OneDrive\Desktop\AIR_R2\eval15_resized\low"
SCALES = ["scale_1.0", "scale_0.75", "scale_0.5", "scale_0.25"]
IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff")

# =========================================================
# METHODS (11 STANDARD ENHANCEMENTS)
# =========================================================
def hist_eq(img):
    return cv2.equalizeHist(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))

def clahe(img):
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l = cv2.createCLAHE(2.0, (8, 8)).apply(l)
    return cv2.cvtColor(cv2.merge([l, a, b]), cv2.COLOR_LAB2BGR)

def gamma(img):
    inv = 1.0 / 1.2
    table = np.array([((i / 255.0) ** inv) * 255 for i in range(256)]).astype(np.uint8)
    return cv2.LUT(img, table)

def contrast(img):
    return cv2.convertScaleAbs(img, alpha=1.3, beta=10)

def unsharp(img):
    blur = cv2.GaussianBlur(img, (5, 5), 1)
    return cv2.addWeighted(img, 1.5, blur, -0.5, 0)

def bilateral(img):
    return cv2.bilateralFilter(img, 9, 75, 75)

def edge(img):
    return cv2.Canny(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), 100, 200)

def log_transform(img):
    img = img.astype(np.float32)
    c = 255 / np.log(1 + np.max(img))
    return (c * np.log(1 + img)).astype(np.uint8)

def box(img):
    return cv2.blur(img, (5, 5))

def denoise(img):
    return cv2.fastNlMeansDenoisingColored(img, None, 10, 10, 7, 21)

def hls(img):
    x = cv2.cvtColor(img, cv2.COLOR_BGR2HLS)
    h, l, s = cv2.split(x)
    l = cv2.equalizeHist(l)
    return cv2.cvtColor(cv2.merge([h, l, s]), cv2.COLOR_HLS2BGR)

METHODS = {
    "hist_eq": hist_eq,
    "clahe": clahe,
    "gamma": gamma,
    "contrast": contrast,
    "unsharp": unsharp,
    "bilateral": bilateral,
    "edge": edge,
    "log": log_transform,
    "box": box,
    "denoise": denoise,
    "hls": hls
}

# =========================================================
# STORAGE
# =========================================================
records = []

# =========================================================
# BENCHMARK LOOP (CLEAN + CORRECT)
# =========================================================
for scale in SCALES:

    folder = os.path.join(INPUT_ROOT, scale)
    if not os.path.isdir(folder):
        continue

    images = [f for f in os.listdir(folder) if f.lower().endswith(IMAGE_EXTS)]

    for img_name in images:

        img = cv2.imread(os.path.join(folder, img_name))
        if img is None:
            continue

        for method_name, func in METHODS.items():

            # ---- warm-up (NOT measured)
            _ = func(img)

            # ---- stable repeated measurement
            times = []
            for _ in range(5):
                start = time.perf_counter()
                _ = func(img)
                times.append((time.perf_counter() - start) * 1000)

            records.append({
                "scale": scale,
                "image": img_name,
                "method": method_name,
                "mean_ms": float(np.mean(times)),
                "std_ms": float(np.std(times))
            })

# =========================================================
# DATAFRAME
# =========================================================
df = pd.DataFrame(records)

if df.empty:
    raise RuntimeError("No data collected. Check dataset path.")

# =========================================================
# METHOD AGGREGATION (FINAL SCORE)
# =========================================================
summary = df.groupby("method")[["mean_ms", "std_ms"]].mean().reset_index()

# Rank = lower time = better
summary = summary.sort_values("mean_ms", ascending=True).reset_index(drop=True)
summary["rank"] = summary.index + 1

# Human-readable label
summary["label"] = summary["rank"].astype(str) + ". " + summary["method"]

# =========================================================
# SAVE TABLE
# =========================================================
output_dir = r"C:\Users\imriz\OneDrive\Desktop\AIR_R2\FINAL_RANK_OUTPUT"
os.makedirs(output_dir, exist_ok=True)

summary.to_csv(os.path.join(output_dir, "method_ranking.csv"), index=False)

print("\n===== FINAL RANKING TABLE =====\n")
print(summary)

# =========================================================
# PLOT (FINAL CLEAN VISUAL)
# =========================================================
plt.figure(figsize=(10, 6))

plt.barh(summary["label"], summary["mean_ms"])

plt.xlabel("Mean Processing Time (ms)")
plt.title("Final Ranking of Enhancement Methods (Fast → Slow)")

plt.gca().invert_yaxis()

for i, v in enumerate(summary["mean_ms"]):
    plt.text(v + 0.5, i, f"{v:.2f}", va="center")

plt.tight_layout()

plot_path = os.path.join(output_dir, "method_ranking.png")
plt.savefig(plot_path, dpi=300)
plt.show()

print("\nSaved to:", output_dir)