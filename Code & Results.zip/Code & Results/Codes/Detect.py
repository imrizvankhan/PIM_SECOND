import os
import cv2
import numpy as np
from retinaface import RetinaFace
import matplotlib.pyplot as plt
from sklearn.metrics import precision_score, recall_score, f1_score, average_precision_score
from collections import defaultdict
from tabulate import tabulate
import logging

# Setup logging
logging.basicConfig(filename='face_detection.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
console = logging.StreamHandler()
console.setLevel(logging.INFO)
logging.getLogger('').addHandler(console)

# Directories
BASE_DIR = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET'
IMAGE_DIR = os.path.join(BASE_DIR, 'DarkFace_Train_2021', 'image')
LABEL_DIR = os.path.join(BASE_DIR, 'DarkFace_Train_2021', 'label')
RESULTS_DIR = os.path.join(BASE_DIR, 'results_y5f_comparison')

# Ensure directories exist
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(os.path.join(RESULTS_DIR, 'original_detections'), exist_ok=True)


# Enhancement functions
def histogram_equalization(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return cv2.cvtColor(cv2.equalizeHist(gray), cv2.COLOR_GRAY2BGR)


def clahe_enhancement(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    return cv2.cvtColor(clahe.apply(gray), cv2.COLOR_GRAY2BGR)


def gamma_correction(img, gamma=1.2):
    invGamma = 1.0 / gamma
    table = np.array([((i / 255.0) ** invGamma) * 255 for i in range(256)]).astype("uint8")
    return cv2.LUT(img, table)


def contrast_stretching(img):
    min_val = np.min(img)
    max_val = np.max(img)
    return np.uint8(255 * (img - min_val) / (max_val - min_val))


def unsharp_mask(img, sigma=1.0, strength=1.5):
    blurred = cv2.GaussianBlur(img, (5, 5), sigma)
    return cv2.addWeighted(img, 1 + strength, blurred, -strength, 0)


def bilateral_filtering(img):
    return cv2.bilateralFilter(img, d=9, sigmaColor=75, sigmaSpace=75)


def edge_enhancement(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 100, 200)
    return cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)


def logarithmic_transformation(img):
    c = 255 / np.log(1 + np.max(img))
    log_img = c * np.log(1 + img)
    return np.uint8(log_img)


def box_filtering(img):
    return cv2.blur(img, (5, 5))


def denoise_image(img):
    return cv2.fastNlMeansDenoisingColored(img, None, 10, 10, 7, 21)


def hls_enhancement(img):
    hls_img = cv2.cvtColor(img, cv2.COLOR_BGR2HLS)
    hls_img[:, :, 1] = cv2.equalizeHist(hls_img[:, :, 1])
    return cv2.cvtColor(hls_img, cv2.COLOR_HLS2BGR)


# Enhancement techniques mapping
ENHANCEMENTS = {
    'hist_eq': histogram_equalization,
    'clahe': clahe_enhancement,
    'gamma': gamma_correction,
    'contrast_stretch': contrast_stretching,
    'unsharp': unsharp_mask,
    'bilateral': bilateral_filtering,
    'edge_enhance': edge_enhancement,
    'log_trans': logarithmic_transformation,
    'box_filter': box_filtering,
    'denoise': denoise_image,
    'hls': hls_enhancement
}


# Helper functions
def calculate_iou(boxA, boxB):
    xA, yA, xB, yB = boxA[0], boxA[1], boxA[0] + boxA[2], boxA[1] + boxA[3]
    xC, yC, xD, yD = boxB[0], boxB[1], boxB[0] + boxB[2], boxB[1] + boxB[3]
    interX = max(xA, xC)
    interY = max(yA, yC)
    interWidth = max(0, min(xB, xD) - interX)
    interHeight = max(0, min(yB, yD) - interY)
    intersection = interWidth * interHeight
    union = (boxA[2] * boxA[3]) + (boxB[2] * boxB[3]) - intersection
    return intersection / union if union > 0 else 0


def load_ground_truth(label_path):
    """Load ground truth faces from label file"""
    gt_faces = []
    if os.path.exists(label_path):
        with open(label_path, 'r') as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 4:
                    x, y, w, h = map(float, parts[:4])
                    gt_faces.append([x, y, w, h])
    return gt_faces


def detect_faces(image_path):
    """Detect faces in an image using RetinaFace"""
    try:
        img = cv2.imread(image_path)
        if img is None:
            logging.error(f"Could not read image: {image_path}")
            return None, []

        faces = RetinaFace.detect_faces(img)
        detected_faces = []

        if isinstance(faces, dict):
            for face in faces.values():
                x, y, w, h = face['facial_area']
                confidence = face['score']
                detected_faces.append([x, y, w, h, confidence])
            logging.info(f"Detected {len(detected_faces)} faces in {image_path}")
        else:
            logging.warning(f"No faces detected in {image_path}")

        return img, detected_faces
    except Exception as e:
        logging.error(f"Face detection failed for {image_path}: {str(e)}")
        return None, []


def evaluate_performance(predicted_faces, ground_truth_faces, iou_threshold=0.5):
    """Evaluate detection performance metrics"""
    if not ground_truth_faces or not predicted_faces:
        return 0.0, 0.0, 0.0, 0.0

    # Initialize counters
    true_positives = 0
    false_positives = 0
    matched_gt = set()

    # Sort predictions by confidence (descending)
    predicted_faces.sort(key=lambda x: x[4], reverse=True)

    # Prepare for precision-recall calculation
    y_true = []
    y_scores = []

    for pred in predicted_faces:
        pred_box = pred[:4]
        best_iou = 0
        best_gt_idx = -1

        # Find best matching ground truth
        for gt_idx, gt in enumerate(ground_truth_faces):
            if gt_idx in matched_gt:
                continue
            iou = calculate_iou(pred_box, gt)
            if iou > best_iou:
                best_iou = iou
                best_gt_idx = gt_idx

        # Check if match meets threshold
        if best_iou >= iou_threshold:
            true_positives += 1
            matched_gt.add(best_gt_idx)
            y_true.append(1)
        else:
            false_positives += 1
            y_true.append(0)

        y_scores.append(pred[4])

    false_negatives = len(ground_truth_faces) - len(matched_gt)

    # Calculate metrics
    precision = true_positives / (true_positives + false_positives) if (true_positives + false_positives) > 0 else 0
    recall = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) > 0 else 0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0

    # For AP, we need to ensure equal lengths
    if len(y_true) != len(y_scores):
        min_len = min(len(y_true), len(y_scores))
        y_true = y_true[:min_len]
        y_scores = y_scores[:min_len]

    ap = average_precision_score(y_true, y_scores) if len(y_true) > 0 else 0

    return precision, recall, f1, ap


def process_original_images():
    """Process original images and evaluate performance"""
    all_metrics = defaultdict(lambda: {
        'precision': [], 'recall': [], 'f1': [], 'ap': []
    })

    for image_name in sorted(os.listdir(IMAGE_DIR)):
        if not image_name.lower().endswith(('.jpg', '.jpeg', '.png')):
            continue

        image_path = os.path.join(IMAGE_DIR, image_name)
        label_path = os.path.join(LABEL_DIR, os.path.splitext(image_name)[0] + '.txt')

        # Load ground truth
        ground_truth_faces = load_ground_truth(label_path)
        if not ground_truth_faces:
            logging.warning(f"No ground truth faces for {image_name}")
            continue

        # Detect faces
        img, pred_faces = detect_faces(image_path)
        if img is None:
            continue

        # Evaluate performance
        precision, recall, f1, ap = evaluate_performance(pred_faces, ground_truth_faces)

        # Store metrics
        all_metrics['original']['precision'].append(precision)
        all_metrics['original']['recall'].append(recall)
        all_metrics['original']['f1'].append(f1)
        all_metrics['original']['ap'].append(ap)

        # Save original detection visualization
        orig_detection_path = os.path.join(RESULTS_DIR, 'original_detections', f'detected_{image_name}')
        visualize_faces(img, pred_faces, orig_detection_path)

    return all_metrics


def process_enhanced_images(all_metrics):
    """Apply enhancements and evaluate performance on enhanced images"""
    for tech_name, enhance_func in ENHANCEMENTS.items():
        tech_dir = os.path.join(RESULTS_DIR, tech_name)
        os.makedirs(os.path.join(tech_dir, 'enhanced_images'), exist_ok=True)
        os.makedirs(os.path.join(tech_dir, 'detections'), exist_ok=True)
        os.makedirs(os.path.join(tech_dir, 'metrics'), exist_ok=True)

        # Initialize metrics for this technique
        all_metrics[tech_name] = {
            'precision': [], 'recall': [], 'f1': [], 'ap': []
        }

        for image_name in sorted(os.listdir(IMAGE_DIR)):
            if not image_name.lower().endswith(('.jpg', '.jpeg', '.png')):
                continue

            image_path = os.path.join(IMAGE_DIR, image_name)
            label_path = os.path.join(LABEL_DIR, os.path.splitext(image_name)[0] + '.txt')

            # Load ground truth (same as original)
            ground_truth_faces = load_ground_truth(label_path)
            if not ground_truth_faces:
                continue

            # Load and enhance image
            img = cv2.imread(image_path)
            if img is None:
                continue

            enhanced_img = enhance_func(img)
            enhanced_path = os.path.join(tech_dir, 'enhanced_images', f'enhanced_{image_name}')
            cv2.imwrite(enhanced_path, enhanced_img)

            # Detect faces on enhanced image
            _, pred_faces = detect_faces(enhanced_path)

            # Evaluate performance
            precision, recall, f1, ap = evaluate_performance(pred_faces, ground_truth_faces)

            # Store metrics
            all_metrics[tech_name]['precision'].append(precision)
            all_metrics[tech_name]['recall'].append(recall)
            all_metrics[tech_name]['f1'].append(f1)
            all_metrics[tech_name]['ap'].append(ap)

            # Save detection visualization
            detection_path = os.path.join(tech_dir, 'detections', f'detected_{image_name}')
            visualize_faces(enhanced_img, pred_faces, detection_path)

    return all_metrics


def visualize_faces(image, faces, save_path):
    """Draw face bounding boxes on image and save"""
    if image is None:
        return

    img_draw = image.copy()
    for face in faces:
        if len(face) >= 5:  # Check if confidence score is present
            x, y, w, h, conf = face[:5]
            cv2.rectangle(img_draw, (int(x), int(y)), (int(x + w), int(y + h)), (0, 255, 0), 2)
            cv2.putText(img_draw, f"{conf:.2f}", (int(x), int(y - 10)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        elif len(face) >= 4:  # Just coordinates without confidence
            x, y, w, h = face[:4]
            cv2.rectangle(img_draw, (int(x), int(y)), (int(x + w), int(y + h)), (0, 255, 0), 2)
    cv2.imwrite(save_path, img_draw)


def save_results(all_metrics):
    """Save metrics and generate comparison plots"""
    # Save overall metrics summary
    summary_file = os.path.join(RESULTS_DIR, 'overall_metrics_summary.txt')

    techniques = ['original'] + list(ENHANCEMENTS.keys())
    metrics = ['precision', 'recall', 'f1', 'ap']

    # Prepare detailed table
    headers = ["Technique", "Metric", "Average Value"]
    table = []

    for tech in techniques:
        for metric in metrics:
            avg_value = np.mean(all_metrics[tech][metric]) if all_metrics[tech][metric] else 0
            table.append([
                tech,
                metric.upper(),
                f"{avg_value:.4f}"
            ])
        table.append(["", "", ""])  # Empty row

    # Add best performing techniques
    table.append(["", "", ""])
    table.append(["BEST PERFORMING TECHNIQUES", "", ""])

    for metric in metrics:
        best_tech = max(
            [(tech, np.mean(all_metrics[tech][metric]))
             for tech in techniques if tech != 'original'],
            key=lambda x: x[1],
            default=("None", 0)
        )
        table.append([
            f"Best {metric.upper()}",
            best_tech[0],
            f"{best_tech[1]:.4f}"
        ])

    with open(summary_file, 'w') as f:
        f.write("COMPREHENSIVE PERFORMANCE SUMMARY\n")
        f.write("=================================\n\n")
        f.write(tabulate(table, headers=headers, tablefmt="grid"))
        f.write("\n\n")

        f.write("Interpretation:\n")
        f.write("- Values show average performance across all images\n")
        f.write("- Higher values indicate better performance\n")

    # Generate comparison plots
    generate_comparison_plots(all_metrics)


def generate_comparison_plots(all_metrics):
    """Generate comparison plots for all metrics"""
    techniques = list(ENHANCEMENTS.keys())
    metrics = ['precision', 'recall', 'f1', 'ap']

    # Create a figure with subplots
    fig, axes = plt.subplots(2, 2, figsize=(18, 12))
    axes = axes.ravel()

    original_avgs = {m: np.mean(all_metrics['original'][m]) for m in metrics}

    for i, metric in enumerate(metrics):
        # Prepare data
        tech_names = []
        tech_values = []

        for tech in techniques:
            if all_metrics[tech][metric]:
                avg_value = np.mean(all_metrics[tech][metric])
                tech_names.append(tech)
                tech_values.append(avg_value)

        # Add original as baseline
        tech_names.insert(0, 'original')
        tech_values.insert(0, original_avgs[metric])

        # Create bars
        x = np.arange(len(tech_names))
        axes[i].bar(x, tech_values, color=['blue'] + ['green'] * (len(tech_names) - 1))

        # Add values on top of bars
        for j, val in enumerate(tech_values):
            axes[i].text(j, val + 0.01, f"{val:.3f}", ha='center')

        axes[i].set_title(f'{metric.upper()} Comparison')
        axes[i].set_xticks(x)
        axes[i].set_xticklabels(tech_names, rotation=45)
        axes[i].set_ylim(0, 1.1)
        axes[i].grid(True, linestyle='--', alpha=0.6)

    plt.tight_layout()
    plot_path = os.path.join(RESULTS_DIR, 'metrics_comparison.png')
    plt.savefig(plot_path)
    plt.close()
    logging.info(f"Saved comparison plot to {plot_path}")


def main():
    """Main execution workflow"""
    logging.info("Starting face detection evaluation pipeline")

    # 1. Process original images
    logging.info("Evaluating original images...")
    all_metrics = process_original_images()

    # 2. Process enhanced images
    logging.info("Evaluating enhanced images...")
    all_metrics = process_enhanced_images(all_metrics)

    # 3. Save results and generate plots
    logging.info("Saving results...")
    save_results(all_metrics)

    logging.info("Processing completed successfully")


if __name__ == "__main__":
    main()