import os
import cv2
import numpy as np
from skimage.metrics import peak_signal_noise_ratio as psnr
from skimage.metrics import structural_similarity as ssim
from skimage import exposure, filters, color
import matplotlib.pyplot as plt
from tqdm import tqdm
import pandas as pd
import seaborn as sns

# Define paths
input_dir = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET\eval15\low'
gt_dir = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET\eval15\high'
output_base_dir = r'C:\Users\imriz\OneDrive\Desktop\REVIEW LLIE DATASET\enhancement_results'

# Create output directories if they don't exist
os.makedirs(output_base_dir, exist_ok=True)


# Enhancement techniques implementations
def histogram_equalization(img):
    if len(img.shape) == 2:  # Grayscale
        return cv2.equalizeHist(img)
    else:  # Color
        img_yuv = cv2.cvtColor(img, cv2.COLOR_BGR2YUV)
        img_yuv[:, :, 0] = cv2.equalizeHist(img_yuv[:, :, 0])
        return cv2.cvtColor(img_yuv, cv2.COLOR_YUV2BGR)


def clahe_enhancement(img, clip_limit=2.0, grid_size=(8, 8)):
    if len(img.shape) == 2:  # Grayscale
        clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=grid_size)
        return clahe.apply(img)
    else:  # Color
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=grid_size)
        l = clahe.apply(l)
        lab = cv2.merge((l, a, b))
        return cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)


def gamma_correction(img, gamma=1.5):
    inv_gamma = 1.0 / gamma
    table = np.array([((i / 255.0) ** inv_gamma) * 255 for i in np.arange(0, 256)]).astype("uint8")
    return cv2.LUT(img, table)


def contrast_stretching(img):
    p2, p98 = np.percentile(img, (2, 98))
    return exposure.rescale_intensity(img, in_range=(p2, p98))


def unsharp_mask(img, kernel_size=(5, 5), sigma=1.0, amount=1.0, threshold=0):
    blurred = cv2.GaussianBlur(img, kernel_size, sigma)
    sharpened = float(amount + 1) * img - float(amount) * blurred
    sharpened = np.maximum(sharpened, np.zeros(sharpened.shape))
    sharpened = np.minimum(sharpened, 255 * np.ones(sharpened.shape))
    sharpened = sharpened.round().astype(np.uint8)
    if threshold > 0:
        low_contrast_mask = np.absolute(img - blurred) < threshold
        np.copyto(sharpened, img, where=low_contrast_mask)
    return sharpened


def bilateral_filtering(img, d=9, sigma_color=75, sigma_space=75):
    return cv2.bilateralFilter(img, d, sigma_color, sigma_space)


def edge_enhancement(img):
    kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
    return cv2.filter2D(img, -1, kernel)


def logarithmic_transformation(img):
    c = 255 / (np.log(1 + np.max(img)) + 1e-10)  # Avoid division by zero
    log_image = c * (np.log(img.astype(np.float32) + 1))  # Avoid log(0)
    return np.clip(log_image, 0, 255).astype(np.uint8)


def box_filtering(img, kernel_size=3):
    return cv2.boxFilter(img, -1, (kernel_size, kernel_size))


def denoise_image(img, h=10, template_window_size=7, search_window_size=21):
    return cv2.fastNlMeansDenoisingColored(img, None, h, h, template_window_size, search_window_size)


def hls_enhancement(img):
    hls = cv2.cvtColor(img, cv2.COLOR_BGR2HLS)
    l_channel = hls[:, :, 1]
    l_channel = cv2.equalizeHist(l_channel)
    hls[:, :, 1] = l_channel
    return cv2.cvtColor(hls, cv2.COLOR_HLS2BGR)


# Enhancement techniques mapping
ENHANCEMENTS = {
    'hist_eq': histogram_equalization,
    'clahe': clahe_enhancement,
    'gamma': gamma_correction,
    'contrast_stretch': contrast_stretching,
    'unsharp': unsharp_mask,
    'bilateral': bilateral_filtering,
    'edge_enhance': edge_enhancement,
    'log_trans': logarithmic_transformation,
    'box_filter': box_filtering,
    'denoise': denoise_image,
    'hls': hls_enhancement
}


# Full-reference metrics with numerical stability
def calculate_full_reference_metrics(enhanced, gt, img_name):
    metrics = {'image': img_name}

    try:
        # Ensure same dimensions
        if enhanced.shape != gt.shape:
            print(f"Dimension mismatch for {img_name}")
            return metrics

        # Convert to float32
        enhanced = enhanced.astype(np.float32)
        gt = gt.astype(np.float32)

        # PSNR
        metrics['psnr'] = psnr(gt, enhanced, data_range=255)

        # SSIM
        if len(gt.shape) == 2:
            metrics['ssim'] = ssim(gt, enhanced, data_range=255)
        else:
            metrics['ssim'] = ssim(gt, enhanced, data_range=255, channel_axis=2)

        # MSE
        metrics['mse'] = np.mean((gt - enhanced) ** 2)

        # RMSE
        metrics['rmse'] = np.sqrt(metrics['mse'])

        # NCC with numerical stability
        gt_norm = gt - np.mean(gt)
        enhanced_norm = enhanced - np.mean(enhanced)
        numerator = np.sum(gt_norm * enhanced_norm)
        denominator = np.sqrt(np.sum(gt_norm ** 2) * np.sum(enhanced_norm ** 2))
        metrics['ncc'] = numerator / (denominator + 1e-10)

        # Absolute Difference
        metrics['abs_diff'] = np.mean(np.abs(gt - enhanced))

    except Exception as e:
        print(f"Error calculating metrics for {img_name}: {str(e)}")

    return metrics


# No-reference metrics
def calculate_no_reference_metrics(image, img_name):
    metrics = {'image': img_name}

    try:
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image

        # Variance of Laplacian (sharpness)
        metrics['laplacian_var'] = cv2.Laplacian(gray, cv2.CV_64F).var()

        # Entropy
        hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
        hist = hist / (hist.sum() + 1e-10)
        metrics['entropy'] = -np.sum(hist * np.log2(hist + 1e-7))

        # Brightness and contrast
        metrics['brightness'] = np.mean(gray)
        metrics['contrast'] = np.std(gray)

    except Exception as e:
        print(f"Error calculating no-ref metrics for {img_name}: {str(e)}")

    return metrics


def process_images():
    # Get and verify image pairs
    image_files = sorted([f for f in os.listdir(input_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
    print(f"Found {len(image_files)} input images")

    # Initialize results storage
    all_full_ref_metrics = {method: [] for method in ENHANCEMENTS.keys()}
    all_no_ref_metrics = {method: [] for method in ENHANCEMENTS.keys()}

    # Create directories for each enhancement method
    for method in ENHANCEMENTS.keys():
        method_dir = os.path.join(output_base_dir, method)
        os.makedirs(method_dir, exist_ok=True)

    # Process each image with ground truth verification
    for img_file in tqdm(image_files, desc="Processing images"):
        input_path = os.path.join(input_dir, img_file)
        gt_path = os.path.join(gt_dir, img_file)

        # Verify ground truth exists
        if not os.path.exists(gt_path):
            print(f"Skipping {img_file} - no ground truth found")
            continue

        # Load images
        img = cv2.imread(input_path)
        gt = cv2.imread(gt_path)

        if img is None or gt is None:
            print(f"Skipping {img_file} - could not load image or ground truth")
            continue

        # Verify dimensions match
        if img.shape != gt.shape:
            print(f"Skipping {img_file} - dimension mismatch with ground truth")
            continue

        # Apply each enhancement and calculate metrics
        for method, func in ENHANCEMENTS.items():
            try:
                # Apply enhancement
                enhanced = func(img.copy())

                # Save enhanced image
                output_path = os.path.join(output_base_dir, method, img_file)
                cv2.imwrite(output_path, enhanced)

                # Calculate metrics (using same GT for each enhanced version)
                full_ref_metrics = calculate_full_reference_metrics(enhanced, gt, img_file)
                no_ref_metrics = calculate_no_reference_metrics(enhanced, img_file)

                # Store results
                all_full_ref_metrics[method].append(full_ref_metrics)
                all_no_ref_metrics[method].append(no_ref_metrics)

            except Exception as e:
                print(f"Error processing {img_file} with {method}: {str(e)}")

    return all_full_ref_metrics, all_no_ref_metrics


def save_results_and_plots(full_ref_metrics, no_ref_metrics):
    # Convert metrics to DataFrames
    full_ref_dfs = {}
    no_ref_dfs = {}

    for method in ENHANCEMENTS.keys():
        full_ref_dfs[method] = pd.DataFrame(full_ref_metrics[method])
        no_ref_dfs[method] = pd.DataFrame(no_ref_metrics[method])

    # Save metrics to text files
    metrics_output_dir = os.path.join(output_base_dir, "metrics_results")
    os.makedirs(metrics_output_dir, exist_ok=True)

    # Save full reference metrics
    for method, df in full_ref_dfs.items():
        # Save detailed metrics
        txt_path = os.path.join(metrics_output_dir, f"{method}_full_ref_metrics.txt")
        with open(txt_path, 'w') as f:
            f.write(f"Full Reference Metrics for {method}\n")
            f.write("=" * 50 + "\n")
            f.write(df.to_string())

        # Save summary statistics
        summary_path = os.path.join(metrics_output_dir, f"{method}_full_ref_summary.txt")
        with open(summary_path, 'w') as f:
            f.write(f"Summary Statistics for {method}\n")
            f.write("=" * 50 + "\n")
            f.write(df.describe().to_string())

    # Save no reference metrics
    for method, df in no_ref_dfs.items():
        # Save detailed metrics
        txt_path = os.path.join(metrics_output_dir, f"{method}_no_ref_metrics.txt")
        with open(txt_path, 'w') as f:
            f.write(f"No Reference Metrics for {method}\n")
            f.write("=" * 50 + "\n")
            f.write(df.to_string())

        # Save summary statistics
        summary_path = os.path.join(metrics_output_dir, f"{method}_no_ref_summary.txt")
        with open(summary_path, 'w') as f:
            f.write(f"Summary Statistics for {method}\n")
            f.write("=" * 50 + "\n")
            f.write(df.describe().to_string())

    # Generate plots
    plot_dir = os.path.join(output_base_dir, "plots")
    os.makedirs(plot_dir, exist_ok=True)

    # Combine all results for plotting
    combined_full_ref = pd.concat(
        [df.assign(Method=method) for method, df in full_ref_dfs.items()],
        ignore_index=True
    )

    combined_no_ref = pd.concat(
        [df.assign(Method=method) for method, df in no_ref_dfs.items()],
        ignore_index=True
    )

    # 1. Box plots (as in original code)
    full_ref_metrics_to_plot = ['psnr', 'ssim', 'ncc']
    for metric in full_ref_metrics_to_plot:
        plt.figure(figsize=(12, 6))
        sns.boxplot(x='Method', y=metric, data=combined_full_ref)
        plt.title(f'Distribution of {metric.upper()} across methods')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(os.path.join(plot_dir, f'full_ref_{metric}_boxplot.png'), dpi=300)
        plt.close()

    no_ref_metrics_to_plot = ['laplacian_var', 'entropy', 'contrast']
    for metric in no_ref_metrics_to_plot:
        plt.figure(figsize=(12, 6))
        sns.boxplot(x='Method', y=metric, data=combined_no_ref)
        plt.title(f'Distribution of {metric.replace("_", " ").title()} across methods')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(os.path.join(plot_dir, f'no_ref_{metric}_boxplot.png'), dpi=300)
        plt.close()

    # 2. Grouped bar charts (replacing radar charts)
    plt.figure(figsize=(14, 8))
    fr_means = combined_full_ref.groupby('Method')[full_ref_metrics_to_plot].mean()
    x = np.arange(len(fr_means))
    width = 0.25

    for i, metric in enumerate(full_ref_metrics_to_plot):
        plt.bar(x + i * width, fr_means[metric], width, label=metric.upper())

    plt.xlabel('Enhancement Methods')
    plt.ylabel('Metric Value')
    plt.title('Average Full Reference Metrics by Method')
    plt.xticks(x + width, fr_means.index, rotation=45)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(plot_dir, 'full_ref_grouped_bars.png'), dpi=300)
    plt.close()

    # 3. Professional summary table
    summary_data = pd.DataFrame()
    summary_data['PSNR'] = fr_means['psnr']
    summary_data['SSIM'] = fr_means['ssim']
    summary_data['NCC'] = fr_means['ncc']

    nr_means = combined_no_ref.groupby('Method')[no_ref_metrics_to_plot].mean()
    summary_data['Sharpness'] = nr_means['laplacian_var']
    summary_data['Entropy'] = nr_means['entropy']
    summary_data['Contrast'] = nr_means['contrast']

    # Save summary table
    summary_path = os.path.join(metrics_output_dir, "summary_results.txt")
    with open(summary_path, 'w') as f:
        f.write("SUMMARY OF ALL METRICS\n")
        f.write("=" * 50 + "\n")
        f.write("All values are averages across all images\n\n")
        f.write(summary_data.round(4).to_string())

    # Save summary CSV
    summary_data.round(4).to_csv(os.path.join(output_base_dir, "summary_metrics.csv"))


if __name__ == "__main__":
    print("Starting image enhancement and evaluation pipeline")
    print(f"Input directory: {input_dir}")
    print(f"Ground truth directory: {gt_dir}")
    print(f"Output will be saved to: {output_base_dir}")

    full_ref_metrics, no_ref_metrics = process_images()
    save_results_and_plots(full_ref_metrics, no_ref_metrics)

    print("\nProcessing completed successfully!")
    print("Results include:")
    print("- Enhanced images for each method")
    print("- Detailed metrics in text files")
    print("- Box plots for metric distributions")
    print("- Grouped bar charts comparing methods")
    print("- Comprehensive summary tables")